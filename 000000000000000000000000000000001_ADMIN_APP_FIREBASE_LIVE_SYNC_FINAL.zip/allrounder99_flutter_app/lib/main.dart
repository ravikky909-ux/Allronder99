
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const AdminApp());
}

class AdminColors {
  static const bg = Color(0xFF061015);
  static const card = Color(0xFF17232C);
  static const cyan = Color(0xFF09C8FF);
  static const text = Color(0xFFEDEDF4);
  static const muted = Color(0xFF9BA7B2);
  static const line = Color(0xFF2F3C46);
  static const green = Color(0xFF25C06D);
  static const red = Color(0xFFE64040);
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Allrounder99 Admin',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AdminColors.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AdminColors.cyan, brightness: Brightness.dark, primary: AdminColors.cyan),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const AdminHome(),
    );
  }
}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  bool unlocked = false;
  final pinController = TextEditingController();

  @override
  void dispose() {
    pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AdminGradient(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.asset('assets/admin_icon.png', width: 58, height: 58, fit: BoxFit.cover)),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Allrounder99 Admin', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      SizedBox(height: 4),
                      Text('Live sync control panel', style: TextStyle(color: AdminColors.muted)),
                    ]),
                  ),
                  const Icon(Icons.admin_panel_settings, color: AdminColors.cyan, size: 30),
                ],
              ),
              const SizedBox(height: 18),
              if (!unlocked) _pinCard(context) else const AdminDashboard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pinCard(BuildContext context) {
    return AdminCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Admin Login', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AdminColors.cyan)),
          const SizedBox(height: 10),
          const Text('Enter admin PIN to open control panel.', style: TextStyle(color: AdminColors.muted)),
          const SizedBox(height: 18),
          TextField(
            controller: pinController,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Admin PIN',
              prefixIcon: const Icon(Icons.lock_outline),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AdminColors.cyan, width: 1.4)),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: AdminColors.cyan, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              onPressed: () {
                if (pinController.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter PIN')));
                  return;
                }
                setState(() => unlocked = true);
              },
              icon: const Icon(Icons.login),
              label: const Text('Open Admin Panel'),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Admin APK private rakho. Yahan se jo score update karoge, user app me live change hoga.', style: TextStyle(color: AdminColors.muted, height: 1.35)),
        ],
      ),
    );
  }
}

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = [
      AdminTool('Live Score Control', Icons.sports_cricket, 'Team, score, over, current ball aur result update karo.'),
      AdminTool('Match Notice', Icons.campaign_outlined, 'User app ke liye top notice / announcement save karo.'),
      AdminTool('App Settings', Icons.settings_outlined, 'Basic app settings page.'),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AdminCard(
          child: Row(children: const [
            Icon(Icons.cloud_done, color: AdminColors.green),
            SizedBox(width: 10),
            Expanded(child: Text('Firebase live sync ready. Save dabate hi user app me update show hoga.', style: TextStyle(fontWeight: FontWeight.w700))),
          ]),
        ),
        const SizedBox(height: 14),
        const Text('Dashboard', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        ...tools.map((t) => Padding(padding: const EdgeInsets.only(bottom: 10), child: AdminMenuTile(tool: t))),
      ],
    );
  }
}

class AdminTool {
  final String title;
  final IconData icon;
  final String subtitle;
  AdminTool(this.title, this.icon, this.subtitle);
}

class AdminMenuTile extends StatelessWidget {
  final AdminTool tool;
  const AdminMenuTile({super.key, required this.tool});

  @override
  Widget build(BuildContext context) {
    return AdminCard(
      onTap: () {
        if (tool.title == 'Live Score Control') {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const LiveScoreControlPage()));
        } else if (tool.title == 'Match Notice') {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const NoticeControlPage()));
        } else {
          Navigator.push(context, MaterialPageRoute(builder: (_) => ToolInfoPage(tool: tool)));
        }
      },
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Row(
        children: [
          Container(width: 44, height: 44, decoration: BoxDecoration(color: AdminColors.cyan.withOpacity(0.13), borderRadius: BorderRadius.circular(14)), child: Icon(tool.icon, color: AdminColors.cyan)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(tool.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            const SizedBox(height: 4),
            Text(tool.subtitle, style: const TextStyle(color: AdminColors.muted, fontSize: 12.5)),
          ])),
          const Icon(Icons.chevron_right, color: AdminColors.muted),
        ],
      ),
    );
  }
}

class LiveScoreControlPage extends StatefulWidget {
  const LiveScoreControlPage({super.key});

  @override
  State<LiveScoreControlPage> createState() => _LiveScoreControlPageState();
}

class _LiveScoreControlPageState extends State<LiveScoreControlPage> {
  final series = TextEditingController(text: 'Andhra Premier League 2026');
  final matchTitle = TextEditingController(text: '25th Match');
  final teamA = TextEditingController(text: 'CAMR');
  final teamB = TextEditingController(text: 'VJS');
  final teamAScore = TextEditingController(text: 'Bowling');
  final teamBScore = TextEditingController(text: '46-1');
  final overs = TextEditingController(text: '5.1 Over');
  final status = TextEditingController(text: 'Live');
  final currentRun = TextEditingController(text: '1 Run');
  final result = TextEditingController(text: 'VJS 46-1 (5.1) • Live now • 1 Run');
  final battingTeam = TextEditingController(text: 'VJS');
  final bowlingTeam = TextEditingController(text: 'CAMR');
  bool saving = false;

  DocumentReference<Map<String, dynamic>> get doc => FirebaseFirestore.instance.collection('allrounder99').doc('live_match');

  @override
  void initState() {
    super.initState();
    _loadCurrent();
  }

  Future<void> _loadCurrent() async {
    try {
      final snap = await doc.get();
      final d = snap.data();
      if (d == null) return;
      setState(() {
        series.text = '${d['series'] ?? series.text}';
        matchTitle.text = '${d['matchTitle'] ?? matchTitle.text}';
        teamA.text = '${d['teamA'] ?? teamA.text}';
        teamB.text = '${d['teamB'] ?? teamB.text}';
        teamAScore.text = '${d['teamAScore'] ?? teamAScore.text}';
        teamBScore.text = '${d['teamBScore'] ?? teamBScore.text}';
        overs.text = '${d['overs'] ?? overs.text}';
        status.text = '${d['status'] ?? status.text}';
        currentRun.text = '${d['currentRun'] ?? currentRun.text}';
        result.text = '${d['result'] ?? result.text}';
        battingTeam.text = '${d['battingTeam'] ?? battingTeam.text}';
        bowlingTeam.text = '${d['bowlingTeam'] ?? bowlingTeam.text}';
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    for (final c in [series, matchTitle, teamA, teamB, teamAScore, teamBScore, overs, status, currentRun, result, battingTeam, bowlingTeam]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => saving = true);
    try {
      await doc.set({
        'series': series.text.trim(),
        'matchTitle': matchTitle.text.trim(),
        'teamA': teamA.text.trim(),
        'teamB': teamB.text.trim(),
        'teamAScore': teamAScore.text.trim(),
        'teamBScore': teamBScore.text.trim(),
        'overs': overs.text.trim(),
        'status': status.text.trim(),
        'currentRun': currentRun.text.trim(),
        'result': result.text.trim(),
        'battingTeam': battingTeam.text.trim(),
        'bowlingTeam': bowlingTeam.text.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved ✅ User app me live update hoga.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Live Score Control'), backgroundColor: AdminColors.bg),
      body: AdminGradient(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AdminCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Update User App Live Match', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AdminColors.cyan)),
                const SizedBox(height: 8),
                const Text('Yahan jo save karoge, user app ke match card aur live header me update ho jayega.', style: TextStyle(color: AdminColors.muted, height: 1.35)),
                const SizedBox(height: 16),
                AdminTextBox(label: 'Series', controller: series),
                AdminTextBox(label: 'Match Title', controller: matchTitle),
                Row(children: [Expanded(child: AdminTextBox(label: 'Team A', controller: teamA)), const SizedBox(width: 10), Expanded(child: AdminTextBox(label: 'Team B', controller: teamB))]),
                Row(children: [Expanded(child: AdminTextBox(label: 'Team A Score', controller: teamAScore)), const SizedBox(width: 10), Expanded(child: AdminTextBox(label: 'Team B Score', controller: teamBScore))]),
                Row(children: [Expanded(child: AdminTextBox(label: 'Overs', controller: overs)), const SizedBox(width: 10), Expanded(child: AdminTextBox(label: 'Status', controller: status))]),
                Row(children: [Expanded(child: AdminTextBox(label: 'Current Ball Text', controller: currentRun)), const SizedBox(width: 10), Expanded(child: AdminTextBox(label: 'Batting Team', controller: battingTeam))]),
                AdminTextBox(label: 'Bowling Team', controller: bowlingTeam),
                AdminTextBox(label: 'Result / Bottom Line', controller: result, maxLines: 2),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: AdminColors.cyan, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                    onPressed: saving ? null : _save,
                    icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined),
                    label: Text(saving ? 'Saving...' : 'Save & Update User App'),
                  ),
                ),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class NoticeControlPage extends StatefulWidget {
  const NoticeControlPage({super.key});

  @override
  State<NoticeControlPage> createState() => _NoticeControlPageState();
}

class _NoticeControlPageState extends State<NoticeControlPage> {
  final title = TextEditingController(text: 'Welcome to Allrounder99');
  final body = TextEditingController(text: 'Scoring app for live cricket scores, scorecards and match history.');
  bool saving = false;

  @override
  void dispose() {
    title.dispose();
    body.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => saving = true);
    try {
      await FirebaseFirestore.instance.collection('allrounder99').doc('notice').set({
        'title': title.text.trim(),
        'body': body.text.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notice saved ✅')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Match Notice'), backgroundColor: AdminColors.bg),
      body: AdminGradient(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AdminCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('User App Notice', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AdminColors.cyan)),
            const SizedBox(height: 12),
            AdminTextBox(label: 'Title', controller: title),
            AdminTextBox(label: 'Message', controller: body, maxLines: 3),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: saving ? null : _save, icon: const Icon(Icons.save), label: Text(saving ? 'Saving...' : 'Save Notice'))),
          ])),
        ]),
      ),
    );
  }
}

class ToolInfoPage extends StatelessWidget {
  final AdminTool tool;
  const ToolInfoPage({super.key, required this.tool});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tool.title), backgroundColor: AdminColors.bg),
      body: AdminGradient(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AdminCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(tool.icon, color: AdminColors.cyan, size: 36),
            const SizedBox(height: 12),
            Text(tool.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AdminColors.cyan)),
            const SizedBox(height: 8),
            Text(tool.subtitle, style: const TextStyle(color: AdminColors.muted, height: 1.35)),
            const SizedBox(height: 12),
            const Text('Ye section next update me connect kar sakte hain.', style: TextStyle(color: AdminColors.muted)),
          ])),
        ]),
      ),
    );
  }
}

class AdminTextBox extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final int maxLines;
  const AdminTextBox({super.key, required this.label, required this.controller, this.maxLines = 1});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: const Color(0xFF0B141B),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AdminColors.line)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AdminColors.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AdminColors.cyan, width: 1.5)),
        ),
      ),
    );
  }
}

class AdminGradient extends StatelessWidget {
  final Widget child;
  const AdminGradient({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF050B10), Color(0xFF071B24), Color(0xFF061015)])),
      child: child,
    );
  }
}

class AdminCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const AdminCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Ink(
          padding: padding,
          decoration: BoxDecoration(
            color: AdminColors.card.withOpacity(0.95),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AdminColors.line),
            boxShadow: [BoxShadow(color: AdminColors.cyan.withOpacity(0.06), blurRadius: 18, offset: const Offset(0, 8))],
          ),
          child: child,
        ),
      ),
    );
  }
}
