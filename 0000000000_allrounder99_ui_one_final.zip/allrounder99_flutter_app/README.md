# Allrounder99 Premium UI

Black + blue cricket scoring app with splash, home, fixtures, series, match detail tabs, shorts, more, and manual scoring.
