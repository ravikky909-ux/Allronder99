import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Color(0xFF05080D),
    systemNavigationBarColor: Color(0xFF05080D),
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const Allrounder99App());
}

const bg = Color(0xFF05080D);
const panel = Color(0xFF101923);
const panel2 = Color(0xFF14202B);
const cyan = Color(0xFF00D7FF);
const blue = Color(0xFF1076FF);
const soft = Color(0xFF92A1AF);
const green = Color(0xFF26C06F);
const orange = Color(0xFFD8973C);
const red = Color(0xFFFF4B5C);

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Allrounder99',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        fontFamily: 'Roboto',
        colorScheme: const ColorScheme.dark(primary: cyan, secondary: blue, surface: panel),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 4500));
    _scale = Tween<double>(begin: .82, end: 1.08).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutExpo));
    _fade = Tween<double>(begin: .0, end: 1).animate(CurvedAnimation(parent: _controller, curve: const Interval(0, .45, curve: Curves.easeOut)));
    _controller.forward();
    Future.delayed(const Duration(milliseconds: 4500), () {
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
    });
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(center: Alignment.center, radius: 1.0, colors: [Color(0xFF073C47), bg]),
        ),
        child: Center(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (_, __) => Opacity(
              opacity: _fade.value,
              child: Transform.scale(
                scale: _scale.value,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: cyan.withOpacity(.35), blurRadius: 42, spreadRadius: 5)],
                      ),
                      child: Image.asset('assets/logo.png', width: 210, height: 210, fit: BoxFit.contain),
                    ),
                    const SizedBox(height: 20),
                    const Text('ALLROUNDER99', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
                    const SizedBox(height: 8),
                    const Text('Fast Cricket Scores • Smart Scoring', style: TextStyle(color: soft, fontSize: 14)),
                    const SizedBox(height: 30),
                    const SizedBox(width: 150, child: LinearProgressIndicator(minHeight: 4, color: cyan, backgroundColor: Color(0x2246DFFF))),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final screens = const [HomeScreen(), ShortsScreen(), FixturesScreen(), SeriesScreen(), MoreScreen()];
  final labels = const ['Home', 'Shorts', 'Fixtures', 'Series', 'More'];
  final icons = const [Icons.home_rounded, Icons.play_circle_outline_rounded, Icons.calendar_month_rounded, Icons.emoji_events_rounded, Icons.more_horiz_rounded];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[index],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: const Color(0xEE08111A), border: Border(top: BorderSide(color: Colors.white.withOpacity(.08))), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.45), blurRadius: 18)]),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 78,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: List.generate(labels.length, (i) {
                final active = i == index;
                return InkWell(
                  onTap: () => setState(() => index = i),
                  borderRadius: BorderRadius.circular(18),
                  child: SizedBox(
                    width: 72,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(icons[i], color: active ? cyan : Colors.white70, size: 27),
                        const SizedBox(height: 5),
                        Text(labels[i], style: TextStyle(color: active ? cyan : Colors.white70, fontWeight: active ? FontWeight.w800 : FontWeight.w500, fontSize: 12)),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  final bool compact;
  const AppHeader({super.key, this.compact = false});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(18, compact ? 10 : 18, 18, 8),
      child: Row(
        children: [
          ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/logo.png', width: 48, height: 48, fit: BoxFit.cover)),
          const SizedBox(width: 10),
          const Expanded(child: Text('ALLROUNDER99', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, letterSpacing: .7))),
          iconBox(Icons.search_rounded),
          const SizedBox(width: 10),
          iconBox(Icons.settings_rounded),
        ],
      ),
    );
  }
}

Widget iconBox(IconData icon) => Container(width: 46, height: 46, decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(.12))), child: Icon(icon, color: Colors.white, size: 25));

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const AppHeader(),
          const TopTabs(items: ['Featured', 'Live', 'WT20 WC'], active: 0),
          Padding(
            padding: const EdgeInsets.all(16),
            child: MatchHeroCard(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailScreen()))),
          ),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: ChipRow(items: ['All', 'T20', 'ODI', 'Test', 'Leagues'])),
          sectionTitle('Trending Series', 'View all'),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: SeriesWideCard(title: "Women’s T20 World Cup 2026", subtitle: '12 Jun – 05 Jul • 33 Matches', status: 'Live Now')),
          sectionTitle('Popular Shorts', 'View all'),
          const ShortsScroller(),
          sectionTitle('Quick Scoring', 'Start'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: PremiumCard(child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const CircleAvatar(backgroundColor: Color(0x3320D7FF), child: Icon(Icons.sports_cricket, color: cyan)),
              title: const Text('Create Local Match', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('Manual scoring with scorecard, history and share', style: TextStyle(color: soft)),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ManualScoringPage())),
            )),
          )
        ]),
      ),
    );
  }
}

class MatchHeroCard extends StatelessWidget {
  final VoidCallback? onTap;
  const MatchHeroCard({super.key, this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: premiumDecoration(borderColor: cyan.withOpacity(.8), glow: true),
        child: Column(children: [
          statusPill('FINISHED', cyan),
          const SizedBox(height: 10),
          const Text('Major League Cricket 2026 • 9th Match', style: TextStyle(color: Colors.white70, fontSize: 14)),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: teamScore('ORC', 'Orcas', '227-6', '(20.0)', const Color(0xFFE04D4D))),
            const Icon(Icons.flash_on_rounded, color: cyan, size: 36),
            Expanded(child: teamScore('FRE', 'Freedom', '139-10', '(16.2)', const Color(0xFFE4A0AA))),
          ]),
          const SizedBox(height: 16),
          Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: const Color(0x9907131C), borderRadius: BorderRadius.circular(14), border: Border.all(color: cyan.withOpacity(.25))), child: const Text('Seattle Orcas won by 88 runs', textAlign: TextAlign.center, style: TextStyle(color: cyan, fontWeight: FontWeight.w900))),
        ]),
      ),
    );
  }
}

Widget teamScore(String abbr, String name, String score, String overs, Color color) => Column(children: [
  CircleAvatar(radius: 34, backgroundColor: color, child: Text(abbr, style: const TextStyle(fontWeight: FontWeight.w900))),
  const SizedBox(height: 10),
  Text(score, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
  Text(overs, style: const TextStyle(color: Colors.white70, fontSize: 15)),
  const SizedBox(height: 8),
  Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
]);

class FixturesScreen extends StatelessWidget {
  const FixturesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.only(bottom: 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const AppHeader(compact: true),
      const TopTabs(items: ['Day wise', 'Series wise', 'Team wise'], active: 0),
      const Padding(padding: EdgeInsets.all(16), child: ChipRow(items: ['All', 'T20', 'ODI', 'Test', 'Hundred'])),
      const Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: Row(children: [Icon(Icons.calendar_today_rounded, color: Colors.white70, size: 18), SizedBox(width: 10), Text('Fri, 26 Jun 2026', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))])),
      const SizedBox(height: 10),
      MatchListCard(title: 'Major League Cricket 2026', match: '9th Match • 07:00 AM', left: 'Freedom', right: 'Orcas', leftScore: '139-10\n(16.2)', rightScore: '227-6\n(20.0)', status: 'Finished', color: green, result: 'Seattle Orcas won by 88 runs'),
      const MatchListCard(title: 'Andhra Premier League 2026', match: '25th Match • 02:00 PM', left: 'Capital Amaravati\nRoyals', right: 'Vijayawada\nSunshiners', status: 'Upcoming', color: orange, venue: 'Venue – Amaravathi, India'),
      const MatchListCard(title: 'Women T20 Blast 2026', match: '28th Match • 03:30 PM', left: 'Warwickshire\nWomen', right: 'Surrey Women', status: 'Upcoming', color: orange, venue: 'Venue – Birmingham, England'),
      const MatchListCard(title: 'The Hundred Women 2026', match: '15th Match • 07:00 PM', left: 'Southern Brave\nWomen', right: 'London Spirit\nWomen', status: 'Upcoming', color: orange, venue: 'Venue – Southampton, England'),
    ])));
  }
}

class MatchListCard extends StatelessWidget {
  final String title, match, left, right, status;
  final String? leftScore, rightScore, result, venue;
  final Color color;
  const MatchListCard({super.key, required this.title, required this.match, required this.left, required this.right, required this.status, required this.color, this.leftScore, this.rightScore, this.result, this.venue});
  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 0), child: InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailScreen())), borderRadius: BorderRadius.circular(18), child: PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), Text(match, style: const TextStyle(color: soft))])), statusPill(status, color)]),
      const Divider(color: Colors.white12, height: 24),
      Row(children: [teamMini(left, 'A', leftScore), const Expanded(child: Center(child: Icon(Icons.flash_on_rounded, color: cyan, size: 28))), teamMini(right, 'B', rightScore, alignRight: true)]),
      if (result != null) Padding(padding: const EdgeInsets.only(top: 14), child: Center(child: Text(result!, style: const TextStyle(color: cyan, fontWeight: FontWeight.w900)))),
      if (venue != null) Padding(padding: const EdgeInsets.only(top: 14), child: Row(children: [const Icon(Icons.location_on_outlined, color: soft, size: 18), const SizedBox(width: 6), Expanded(child: Text(venue!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)))])),
    ]))));
  }
}

Widget teamMini(String name, String abbr, String? score, {bool alignRight = false}) => SizedBox(width: 132, child: Column(crossAxisAlignment: alignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
  CircleAvatar(radius: 28, backgroundColor: alignRight ? const Color(0xFF115A9D) : const Color(0xFF92384B), child: Text(abbr, style: const TextStyle(fontWeight: FontWeight.w900))),
  const SizedBox(height: 8),
  if (score != null) Text(score, textAlign: alignRight ? TextAlign.right : TextAlign.left, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
  const SizedBox(height: 4),
  Text(name, textAlign: alignRight ? TextAlign.right : TextAlign.left, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
]));

class SeriesScreen extends StatelessWidget {
  const SeriesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final data = [
      ['Vidarbha Premier League 2026','01 Jun – 14 Jun','25 Matches','Finished','VPL'],
      ['T20 Mumbai 2026','01 Jun – 13 Jun','23 Matches','Finished','T20'],
      ['Asian Legends League 2026','02 Jun – 14 Jun','19 Matches','Postponed','AS'],
      ['Ireland Inter-Provincial T20 Trophy 2026','02 Jun – 17 Jun','9 Matches','Finished','IR'],
      ['Madhya Pradesh T20 League 2026','03 Jun – 26 Jun','48 Matches','Ongoing','MP'],
      ['Sri Lanka tour of West Indies 2026','04 Jun – 18 Jun','5 Matches','Ongoing','SL'],
    ];
    return SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.only(bottom: 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const AppHeader(compact: true),
      const TopTabs(items: ['Day wise', 'Series wise', 'Team wise'], active: 1),
      const Padding(padding: EdgeInsets.all(16), child: ChipRow(items: ['All', 'International', 'T20 Leagues', 'Domestic'])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: TextField(readOnly: true, decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: 'Search Series', filled: true, fillColor: panel, enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: cyan.withOpacity(.4))), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))))),
      const Padding(padding: EdgeInsets.fromLTRB(18, 22, 18, 8), child: Text('June 2026', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
      ...data.map((s) => SeriesCard(name: s[0], dates: s[1], matches: s[2], status: s[3], badge: s[4])),
    ])));
  }
}

class SeriesCard extends StatelessWidget {
  final String name, dates, matches, status, badge;
  const SeriesCard({super.key, required this.name, required this.dates, required this.matches, required this.status, required this.badge});
  @override
  Widget build(BuildContext context) {
    final c = status == 'Finished' ? green : status == 'Postponed' ? Colors.grey : red;
    return Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 0), child: PremiumCard(child: Row(children: [
      Container(width: 70, height: 70, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(colors: [Color(0xFF102B4A), Color(0xFF06121D)]), border: Border.all(color: Colors.white12)), child: Center(child: Text(badge, style: const TextStyle(fontSize: 20, color: cyan, fontWeight: FontWeight.w900)))),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text(dates, style: const TextStyle(color: Colors.white70)), const SizedBox(height: 4), Text(matches, style: const TextStyle(color: Colors.white70))])),
      statusPill(status, c),
    ])));
  }
}

class MatchDetailScreen extends StatelessWidget {
  const MatchDetailScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        body: SafeArea(
          child: Column(children: [
            Padding(padding: const EdgeInsets.fromLTRB(8, 8, 8, 0), child: Row(children: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)), const Expanded(child: Column(children: [Text('Freedom vs Orcas', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)), Text('9th Match', style: TextStyle(color: soft))])), IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert_rounded))])),
            const TabBar(isScrollable: true, indicatorColor: cyan, labelColor: cyan, unselectedLabelColor: Colors.white60, tabs: [Tab(text: 'Info'), Tab(text: 'Live'), Tab(text: 'Commentary'), Tab(text: 'Scorecard'), Tab(text: 'History'), Tab(text: 'Points Table')]),
            Expanded(child: TabBarView(children: [const InfoTab(), const LiveTab(), const CommentaryTab(), const ScorecardTab(), const HistoryTab(), const PointsTableTab()])),
          ]),
        ),
      ),
    );
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(children: [
      const MatchHeroCard(),
      const SizedBox(height: 12),
      BallStrip(balls: const ['0','4','=','6','W','','',''], label: 'Over 17', total: '6'),
      const SizedBox(height: 12),
      PremiumCard(child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: const [StatBox('Runs Needed','89'), StatBox('Balls Rem.','22'), StatBox('CRR','8.51'), StatBox('RRR','24.27'), StatBox('Target','228')])),
      const SizedBox(height: 12),
      scoreMiniTable('BATTING • Freedom', ['Batter','R','B','4s','6s','SR'], [['Amila Aponso','31','13','2','2','238.47'], ['S. Netravalkar','0','0','0','0','0.00']]),
      const SizedBox(height: 12),
      scoreMiniTable('BOWLING • Orcas', ['Bowler','O','R','Wkt','Eco'], [['Cameron Gannon','2.2','16','2','6.86']]),
      const SizedBox(height: 12),
      PremiumCard(child: Column(children: const [MenuRow(Icons.emoji_events_rounded,'Series'), Divider(color: Colors.white12), MenuRow(Icons.bar_chart_rounded,'Points Table'), Divider(color: Colors.white12), MenuRow(Icons.record_voice_over_rounded,'Voice Commentary')]))
    ]));
  }
}

class InfoTab extends StatelessWidget { const InfoTab({super.key}); @override Widget build(BuildContext context) => detailList('Match Info', const [['Series','Major League Cricket 2026'],['Venue','Dallas, USA'],['Toss','Orcas won toss and bat first'],['Umpire','Official Match Umpires'],['Match Type','T20']]); }
class CommentaryTab extends StatelessWidget { const CommentaryTab({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [Comment('16.2','W','K. Ramharack b Gannon. Orcas win by 88 runs.'), Comment('16.1','1','Single to deep cover.'), Comment('15.6','0','Dot ball. Excellent yorker.'), Comment('15.5','W','S. Netravalkar b Gannon.'), Comment('15.4','1','Pushed to long on.')]); }
class ScorecardTab extends StatelessWidget { const ScorecardTab({super.key}); @override Widget build(BuildContext context) => SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(children: [scoreMiniTable('Freedom Batting', ['Batter','R','B','4s','6s','SR'], [['K. Nair','7','5','1','0','140'], ['M. John','12','10','2','0','120'], ['A. Aponso','31','13','2','2','238.47']]), const SizedBox(height: 12), scoreMiniTable('Orcas Bowling', ['Bowler','O','M','R','W'], [['C. Gannon','2.2','0','16','2'], ['S. Netravalkar','4','0','22','1']]), const SizedBox(height: 12), detailList('Extras / Fall of Wickets', const [['Extras','11 (4b, 6lb, 1nb, 0w)'],['FOW','1-14, 2-20, 3-42, 4-78, 10-129']]) ])); }
class HistoryTab extends StatelessWidget { const HistoryTab({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [Text('Over by Over – Freedom Innings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), SizedBox(height: 12), OverRow('1', ['0','1','0','4','0','1'], '11 runs', '11/0'), OverRow('2', ['0','0','W','1','0','2'], 'K. Nair c Miller b Gannon', '14/1'), OverRow('3', ['4','0','1','W','0','0'], 'M. John b Gannon', '20/2'), OverRow('4', ['1','1','0','6','0','1'], '17 runs', '37/2'), OverRow('17', ['0','0','0','0','1','W'], 'K. Ramharack b Gannon', '129/10')]))]); }
class PointsTableTab extends StatelessWidget { const PointsTableTab({super.key}); @override Widget build(BuildContext context) => SingleChildScrollView(padding: const EdgeInsets.all(16), child: scoreMiniTable('Points Table', ['Team','M','W','L','Pts','NRR'], [['Orcas','9','7','2','14','+1.12'], ['Freedom','9','4','5','8','-0.33'], ['Royals','8','3','5','6','-0.42']])); }

Widget detailList(String title, List<List<String>> rows) => SingleChildScrollView(padding: const EdgeInsets.all(16), child: PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: cyan)), const SizedBox(height: 10), ...rows.map((r) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Expanded(child: Text(r[0], style: const TextStyle(color: soft))), Expanded(flex: 2, child: Text(r[1], style: const TextStyle(fontWeight: FontWeight.w700)))])))])));

class ManualScoringPage extends StatefulWidget { const ManualScoringPage({super.key}); @override State<ManualScoringPage> createState() => _ManualScoringPageState(); }
class _ManualScoringPageState extends State<ManualScoringPage> {
  int runs = 0, wkts = 0, balls = 0; final List<String> events = [];
  void add(String e) { setState(() { events.insert(0, e); if (['0','1','2','3','4','6'].contains(e)) { runs += int.parse(e); balls++; } else if (e == 'W') { wkts++; balls++; } else if (e == 'WD' || e == 'NB') { runs++; } else if (e == 'B' || e == 'LB') { runs++; balls++; } }); }
  void undo() { if (events.isNotEmpty) setState(() { final e = events.removeAt(0); if (['0','1','2','3','4','6'].contains(e)) { runs -= int.parse(e); balls--; } else if (e == 'W') { wkts--; balls--; } else if (e == 'WD' || e == 'NB') { runs--; } else if (e == 'B' || e == 'LB') { runs--; balls--; } }); }
  String overs() => '${balls ~/ 6}.${balls % 6}';
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Manual Scoring'), backgroundColor: bg), body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(children: [
    PremiumCard(child: Column(children: [const Text('Allrounder99 Local Match', style: TextStyle(color: cyan, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text('$runs-$wkts', style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w900)), Text('${overs()} Overs', style: const TextStyle(color: soft)), const SizedBox(height: 12), BallStrip(balls: events.take(8).toList().reversed.toList(), label: 'Recent Balls', total: '${events.take(6).length}') ])),
    const SizedBox(height: 14),
    Wrap(spacing: 10, runSpacing: 10, children: ['0','1','2','3','4','6','W','WD','NB','B','LB'].map((e) => scoringButton(e, () => add(e))).toList()),
    const SizedBox(height: 14),
    Row(children: [Expanded(child: ElevatedButton.icon(onPressed: undo, icon: const Icon(Icons.undo), label: const Text('Undo'))), const SizedBox(width: 10), Expanded(child: ElevatedButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: 'Allrounder99 Score: $runs-$wkts (${overs()})')); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Score copied'))); }, icon: const Icon(Icons.share), label: const Text('Share')))]),
    const SizedBox(height: 14),
    PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Ball History', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text(events.isEmpty ? 'No balls yet' : events.join('  '), style: const TextStyle(color: Colors.white70))])),
  ]));
}

Widget scoringButton(String text, VoidCallback onTap) => SizedBox(width: 84, height: 54, child: ElevatedButton(onPressed: onTap, style: ElevatedButton.styleFrom(backgroundColor: text == 'W' ? red : (text == '4' || text == '6') ? blue : panel2, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: cyan.withOpacity(.25)))), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900))));

class ShortsScreen extends StatelessWidget { const ShortsScreen({super.key}); @override Widget build(BuildContext context) => SafeArea(child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const AppHeader(), sectionTitle('Popular Shorts','Upload'), const ShortsScroller(big: true), sectionTitle('Latest Cricket Videos','View all'), const ShortsScroller(big: true)]))); }
class MoreScreen extends StatelessWidget { const MoreScreen({super.key}); @override Widget build(BuildContext context) => SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.only(bottom: 20), child: Column(children: [const AppHeader(), Padding(padding: const EdgeInsets.all(16), child: PremiumCard(child: Column(children: [const MenuRow(Icons.sports_cricket,'Manual Scoring'), const Divider(color: Colors.white12), const MenuRow(Icons.link_rounded,'WhatsApp Link'), const Divider(color: Colors.white12), const MenuRow(Icons.language_rounded,'Website Link'), const Divider(color: Colors.white12), const MenuRow(Icons.notifications_rounded,'Notifications'), const Divider(color: Colors.white12), const MenuRow(Icons.info_outline_rounded,'About Allrounder99')])))]))); }

class MenuRow extends StatelessWidget { final IconData icon; final String text; const MenuRow(this.icon, this.text, {super.key}); @override Widget build(BuildContext context) => ListTile(contentPadding: EdgeInsets.zero, leading: Icon(icon, color: Colors.white70), title: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)), trailing: const Icon(Icons.chevron_right_rounded)); }

class ShortsScroller extends StatelessWidget { final bool big; const ShortsScroller({super.key, this.big = false}); @override Widget build(BuildContext context) => SizedBox(height: big ? 260 : 190, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal, itemCount: 5, separatorBuilder: (_, __) => const SizedBox(width: 12), itemBuilder: (_, i) => Container(width: big ? 170 : 150, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(colors: [Color.lerp(blue, red, i / 5) ?? blue, const Color(0xFF07111B)]), border: Border.all(color: Colors.white24)), child: Stack(children: [Positioned.fill(child: Icon(Icons.sports_cricket, size: 80, color: Colors.white.withOpacity(.18))), const Positioned(left: 12, bottom: 42, child: CircleAvatar(backgroundColor: Colors.black54, child: Icon(Icons.play_arrow_rounded, color: Colors.white))), Positioned(left: 12, bottom: 12, right: 8, child: Text(['First hurdle on fire! 🔥','12 record wickets 🚀','Sanju Samson 👑','Top shot replay','Match preview'][i], style: const TextStyle(fontWeight: FontWeight.w900)))]))); }
}

class TopTabs extends StatelessWidget { final List<String> items; final int active; const TopTabs({super.key, required this.items, required this.active}); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: List.generate(items.length, (i) => Expanded(child: Container(padding: const EdgeInsets.only(top: 10, bottom: 12), decoration: BoxDecoration(border: Border(bottom: BorderSide(color: i == active ? cyan : Colors.white12, width: i == active ? 3 : 1))), child: Center(child: Text(items[i], style: TextStyle(color: i == active ? cyan : Colors.white54, fontWeight: FontWeight.w900, fontSize: 16))))))); }
class ChipRow extends StatelessWidget { final List<String> items; const ChipRow({super.key, required this.items}); @override Widget build(BuildContext context) => SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: List.generate(items.length, (i) => Padding(padding: const EdgeInsets.only(right: 10), child: Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12), decoration: BoxDecoration(color: i == 0 ? const Color(0x5520D7FF) : panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: i == 0 ? cyan : Colors.white24)), child: Text(items[i], style: TextStyle(fontWeight: FontWeight.w800, color: i == 0 ? Colors.white : Colors.white70))))))); }
Widget sectionTitle(String left, String right) => Padding(padding: const EdgeInsets.fromLTRB(18, 22, 18, 10), child: Row(children: [Expanded(child: Text(left, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))), Text(right, style: const TextStyle(color: cyan, fontWeight: FontWeight.w900)), const Icon(Icons.chevron_right_rounded, color: cyan)]));
class SeriesWideCard extends StatelessWidget { final String title, subtitle, status; const SeriesWideCard({super.key, required this.title, required this.subtitle, required this.status}); @override Widget build(BuildContext context) => PremiumCard(child: Row(children: [Container(width: 88, height: 88, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [cyan, Color(0xFFFF4BCD)])), child: const Center(child: Text('T20', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)))), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 8), Text(subtitle, style: const TextStyle(color: soft)), const SizedBox(height: 8), Text(status, style: const TextStyle(color: cyan, fontWeight: FontWeight.w900))])), const Icon(Icons.chevron_right_rounded)])); }
class PremiumCard extends StatelessWidget { final Widget child; const PremiumCard({super.key, required this.child}); @override Widget build(BuildContext context) => Container(width: double.infinity, padding: const EdgeInsets.all(16), decoration: premiumDecoration(), child: child); }
BoxDecoration premiumDecoration({Color? borderColor, bool glow = false}) => BoxDecoration(color: panel.withOpacity(.92), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderColor ?? Colors.white.withOpacity(.12)), boxShadow: glow ? [BoxShadow(color: cyan.withOpacity(.18), blurRadius: 24)] : null, gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF111D28), Color(0xFF07111A)]));
Widget statusPill(String text, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: color.withOpacity(.18), borderRadius: BorderRadius.circular(10), border: Border.all(color: color)), child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)));
class BallStrip extends StatelessWidget { final List<String> balls; final String label, total; const BallStrip({super.key, required this.balls, required this.label, required this.total}); @override Widget build(BuildContext context) => PremiumCard(child: Row(children: [Text(label, style: const TextStyle(fontWeight: FontWeight.w900)), const Spacer(), ...balls.map(ballCircle), const SizedBox(width: 8), Text('= $total', style: const TextStyle(fontWeight: FontWeight.w900))])); }
Widget ballCircle(String b) { Color c = b == 'W' ? red : b == '6' ? Colors.deepPurple : (b == '4' || b == '1' || b == '2' || b == '3') ? blue : Colors.white24; return Container(width: 32, height: 32, margin: const EdgeInsets.only(left: 6), decoration: BoxDecoration(shape: BoxShape.circle, color: b.isEmpty ? Colors.transparent : c, border: Border.all(color: Colors.white24)), child: Center(child: Text(b, style: const TextStyle(fontWeight: FontWeight.w900)))); }
class StatBox extends StatelessWidget { final String k, v; const StatBox(this.k,this.v,{super.key}); @override Widget build(BuildContext context) => Column(children: [Text(k, style: const TextStyle(color: soft, fontSize: 12)), const SizedBox(height: 6), Text(v, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19))]); }
Widget scoreMiniTable(String title, List<String> headers, List<List<String>> rows) => PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: cyan, fontWeight: FontWeight.w900, fontSize: 16)), const Divider(color: Colors.white12), Table(columnWidths: {0: const FlexColumnWidth(2.4), for (int i=1;i<headers.length;i++) i: const FlexColumnWidth(1)}, children: [TableRow(children: headers.map((h) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text(h, style: const TextStyle(color: soft, fontWeight: FontWeight.w800)))).toList()), ...rows.map((r) => TableRow(children: r.map((v) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(v, style: const TextStyle(fontWeight: FontWeight.w700)))).toList()))]) ]));
class Comment extends StatelessWidget { final String over, tag, text; const Comment(this.over,this.tag,this.text,{super.key}); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 10), child: PremiumCard(child: Row(children: [ballCircle(tag), const SizedBox(width: 12), Text(over, style: const TextStyle(color: cyan, fontWeight: FontWeight.w900)), const SizedBox(width: 12), Expanded(child: Text(text))]))); }
class OverRow extends StatelessWidget { final String over; final List<String> balls; final String note, score; const OverRow(this.over,this.balls,this.note,this.score,{super.key}); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [SizedBox(width: 24, child: Text(over, style: const TextStyle(fontWeight: FontWeight.w900))), ...balls.map(ballCircle), const SizedBox(width: 8), Expanded(child: Text(note, style: const TextStyle(color: Colors.white70))), Text(score, style: const TextStyle(fontWeight: FontWeight.w900))])); }
