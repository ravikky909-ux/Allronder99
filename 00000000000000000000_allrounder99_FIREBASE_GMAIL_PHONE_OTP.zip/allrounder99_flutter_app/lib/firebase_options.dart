// Generated for Allrounder99 from google-services.json
// Do not edit manually unless Firebase project settings change.
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('Firebase web options are not configured for Allrounder99.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
      case TargetPlatform.macOS:
      case TargetPlatform.windows:
      case TargetPlatform.linux:
        throw UnsupportedError('Firebase options are configured only for Android.');
      default:
        throw UnsupportedError('Unsupported platform for Firebase.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBFytI3BRwXw_2EZxiXWqvd5fofaZFZJDQ',
    appId: '1:120982466145:android:55fbb5745f8cc2d528c420',
    messagingSenderId: '120982466145',
    projectId: 'allrounder99-806a4',
    storageBucket: 'allrounder99-806a4.firebasestorage.app',
    androidClientId: '',
  );
}
