import 'package:flutter/material.dart';

void main() => runApp(const AdminApp());

class AdminColors {
  static const bg = Color(0xFF061015);
  static const bg2 = Color(0xFF101A22);
  static const card = Color(0xFF17232C);
  static const cyan = Color(0xFF09C8FF);
  static const text = Color(0xFFEDEDF4);
  static const muted = Color(0xFF9BA7B2);
  static const line = Color(0xFF2F3C46);
  static const green = Color(0xFF25C06D);
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Allrounder99 Admin',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AdminColors.bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AdminColors.cyan,
          brightness: Brightness.dark,
          primary: AdminColors.cyan,
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const AdminHome(),
    );
  }
}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  bool unlocked = false;
  final pinController = TextEditingController();

  @override
  void dispose() {
    pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF050B10), Color(0xFF071B24), Color(0xFF061015)],
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.asset('assets/admin_icon.png', width: 58, height: 58, fit: BoxFit.cover),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Allrounder99 Admin', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                        SizedBox(height: 4),
                        Text('Separate admin APK', style: TextStyle(color: AdminColors.muted)),
                      ],
                    ),
                  ),
                  const Icon(Icons.admin_panel_settings, color: AdminColors.cyan, size: 30),
                ],
              ),
              const SizedBox(height: 18),
              if (!unlocked) _pinCard(context) else _dashboard(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pinCard(BuildContext context) {
    return AdminCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Admin Login', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AdminColors.cyan)),
          const SizedBox(height: 10),
          const Text('Enter admin PIN to open control panel.', style: TextStyle(color: AdminColors.muted)),
          const SizedBox(height: 18),
          TextField(
            controller: pinController,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Admin PIN',
              prefixIcon: const Icon(Icons.lock_outline),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: AdminColors.cyan, width: 1.4),
              ),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: AdminColors.cyan,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () {
                if (pinController.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter PIN')));
                  return;
                }
                setState(() => unlocked = true);
              },
              icon: const Icon(Icons.login),
              label: const Text('Open Admin Panel'),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Default local PIN screen only. Real secure admin login can be connected later with Firebase/Auth backend.', style: TextStyle(color: AdminColors.muted, height: 1.35)),
        ],
      ),
    );
  }

  Widget _dashboard(BuildContext context) {
    final tools = [
      AdminTool('Live Score Control', Icons.sports_cricket, 'Update live score, overs, wickets and result.'),
      AdminTool('Fixture Manager', Icons.calendar_month, 'Create and edit upcoming fixtures.'),
      AdminTool('Series Manager', Icons.emoji_events_outlined, 'Manage tournaments, status and points table.'),
      AdminTool('Scorecard Control', Icons.table_chart_outlined, 'Edit batting and bowling scorecard rows.'),
      AdminTool('News / Notice', Icons.campaign_outlined, 'Publish app notice and cricket news cards.'),
      AdminTool('App Settings', Icons.settings_outlined, 'Theme, app links, privacy and terms pages.'),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AdminCard(
          child: Row(
            children: const [
              Icon(Icons.check_circle, color: AdminColors.green),
              SizedBox(width: 10),
              Expanded(child: Text('Admin panel is separate. User app stays clean for score viewing only.', style: TextStyle(fontWeight: FontWeight.w700))),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const Text('Dashboard', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        ...tools.map((t) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AdminMenuTile(tool: t),
            )),
      ],
    );
  }
}

class AdminTool {
  final String title;
  final IconData icon;
  final String subtitle;
  AdminTool(this.title, this.icon, this.subtitle);
}

class AdminMenuTile extends StatelessWidget {
  final AdminTool tool;
  const AdminMenuTile({super.key, required this.tool});

  @override
  Widget build(BuildContext context) {
    return AdminCard(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ToolPage(tool: tool))),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: AdminColors.cyan.withOpacity(0.13), borderRadius: BorderRadius.circular(14)),
            child: Icon(tool.icon, color: AdminColors.cyan),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tool.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 4),
                Text(tool.subtitle, style: const TextStyle(color: AdminColors.muted, fontSize: 12.5)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: AdminColors.muted),
        ],
      ),
    );
  }
}

class ToolPage extends StatelessWidget {
  final AdminTool tool;
  const ToolPage({super.key, required this.tool});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tool.title),
        backgroundColor: AdminColors.bg,
        foregroundColor: AdminColors.text,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF06131A), Color(0xFF050B10)],
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AdminCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(tool.icon, color: AdminColors.cyan, size: 36),
                  const SizedBox(height: 12),
                  Text(tool.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AdminColors.cyan)),
                  const SizedBox(height: 8),
                  Text(tool.subtitle, style: const TextStyle(color: AdminColors.muted, height: 1.35)),
                  const SizedBox(height: 18),
                  const AdminTextBox(label: 'Title / Match name', hint: 'CAMR vs VJS'),
                  const SizedBox(height: 12),
                  const AdminTextBox(label: 'Details', hint: 'VJS 46-1 (5.1) • Live'),
                  const SizedBox(height: 12),
                  const AdminTextBox(label: 'Status', hint: 'Live / Upcoming / Finished'),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: AdminColors.cyan,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved locally. Backend/API connect karne ke baad live update hoga.')));
                      },
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Save'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AdminTextBox extends StatelessWidget {
  final String label;
  final String hint;
  const AdminTextBox({super.key, required this.label, required this.hint});

  @override
  Widget build(BuildContext context) {
    return TextField(
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: const Color(0xFF0B141B),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AdminColors.line)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AdminColors.line)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AdminColors.cyan, width: 1.5)),
      ),
    );
  }
}

class AdminCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const AdminCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Ink(
          padding: padding,
          decoration: BoxDecoration(
            color: AdminColors.card.withOpacity(0.95),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AdminColors.line),
            boxShadow: [BoxShadow(color: AdminColors.cyan.withOpacity(0.06), blurRadius: 18, offset: const Offset(0, 8))],
          ),
          child: child,
        ),
      ),
    );
  }
}
