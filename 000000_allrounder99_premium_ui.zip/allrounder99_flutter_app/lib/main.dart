import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const Allrounder99App());

class C {
  static const bg = Color(0xFF05070B);
  static const bg2 = Color(0xFF08111A);
  static const card = Color(0xFF0B1520);
  static const card2 = Color(0xFF111D2A);
  static const cyan = Color(0xFF00D9FF);
  static const cyan2 = Color(0xFF078DB0);
  static const white = Color(0xFFF4F7FB);
  static const muted = Color(0xFFA6AFBA);
  static const line = Color(0xFF253243);
  static const green = Color(0xFF35C66B);
  static const orange = Color(0xFFD68B32);
  static const red = Color(0xFFE64E5B);
  static const purple = Color(0xFF7C5CFF);
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Allrounder99',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: C.bg,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: C.cyan, brightness: Brightness.dark),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 4500))..forward();
    Timer(const Duration(milliseconds: 4500), () {
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const RootScreen()));
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final scale = 0.86 + (controller.value * 0.14);
          return Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 1.15,
                colors: [Color(0xFF064155), C.bg],
              ),
            ),
            child: Center(
              child: Transform.scale(
                scale: scale,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const LogoBadge(size: 132),
                    const SizedBox(height: 22),
                    const BrandText(fontSize: 30),
                    const SizedBox(height: 10),
                    Container(height: 3, width: 170, decoration: glowBox(radius: 12)),
                    const SizedBox(height: 16),
                    const Text('Live Score • Manual Scoring • Fixtures', style: TextStyle(color: C.muted, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int index = 0;
  final pages = const [HomePage(), ShortsPage(), FixturesPage(), SeriesPage(), MorePage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xF20A131C),
          border: Border(top: BorderSide(color: C.line.withOpacity(0.8))),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 22)],
        ),
        child: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) => setState(() => index = i),
          backgroundColor: Colors.transparent,
          indicatorColor: C.cyan.withOpacity(0.15),
          height: 72,
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'Shorts'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Fixtures'),
            NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'Series'),
            NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz), label: 'More'),
          ],
        ),
      ),
    );
  }
}

BoxDecoration glowBox({double radius = 22, Color color = C.cyan}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(colors: [color.withOpacity(0.95), C.cyan2.withOpacity(0.65)]),
    boxShadow: [BoxShadow(color: color.withOpacity(0.33), blurRadius: 24, spreadRadius: 1)],
  );
}

class AppShell extends StatelessWidget {
  final Widget child;
  final bool showHeader;
  const AppShell({super.key, required this.child, this.showHeader = true});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF020406), C.bg2, C.bg]),
      ),
      child: SafeArea(
        child: Column(
          children: [
            if (showHeader) const MainHeader(),
            Expanded(child: child),
          ],
        ),
      ),
    );
  }
}

class MainHeader extends StatelessWidget {
  const MainHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
      child: Row(
        children: [
          const LogoBadge(size: 48),
          const SizedBox(width: 10),
          const Expanded(child: BrandText(fontSize: 24)),
          IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.search, size: 28)),
          const SizedBox(width: 8),
          IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.settings_outlined, size: 27)),
        ],
      ),
    );
  }
}

class LogoBadge extends StatelessWidget {
  final double size;
  const LogoBadge({super.key, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(colors: [Color(0xFF101923), Color(0xFF003849)]),
        border: Border.all(color: C.cyan, width: size > 80 ? 3 : 2),
        boxShadow: [BoxShadow(color: C.cyan.withOpacity(0.35), blurRadius: 24)],
      ),
      alignment: Alignment.center,
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(text: 'A', style: TextStyle(fontSize: size * 0.43, color: C.white, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
            TextSpan(text: '99', style: TextStyle(fontSize: size * 0.28, color: C.cyan, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
          ],
        ),
      ),
    );
  }
}

class BrandText extends StatelessWidget {
  final double fontSize;
  const BrandText({super.key, required this.fontSize});

  @override
  Widget build(BuildContext context) {
    return RichText(
      overflow: TextOverflow.ellipsis,
      text: TextSpan(
        children: [
          TextSpan(text: 'ALLROUNDER', style: TextStyle(color: C.white, fontSize: fontSize, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, letterSpacing: 0.3)),
          TextSpan(text: '99', style: TextStyle(color: C.cyan, fontSize: fontSize, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 18),
        children: [
          const AppTabs(items: ['Featured', 'Live', 'WT20 WC'], active: 0),
          const SizedBox(height: 14),
          const PremiumMatchCard(compact: false),
          const SizedBox(height: 14),
          const ChipRow(items: ['All', 'T20', 'ODI', 'Test', 'Leagues'], icons: [Icons.apps, Icons.sports_cricket, Icons.sports_baseball, Icons.shield, Icons.emoji_events]),
          const SizedBox(height: 20),
          const SectionTitle('Trending Series'),
          const SizedBox(height: 10),
          const SeriesHighlightCard(),
          const SizedBox(height: 20),
          const SectionTitle('Popular Shorts'),
          const SizedBox(height: 10),
          SizedBox(
            height: 168,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                ShortCard(title: 'First hurdle on fire! 🔥', time: '0:29', icon: Icons.sports_cricket),
                ShortCard(title: '12 record wickets 🚀', time: '0:26', icon: Icons.bolt),
                ShortCard(title: 'Sanju Samson 👑', time: '0:31', icon: Icons.handshake),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FixturesPage extends StatelessWidget {
  const FixturesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 18),
        children: const [
          AppTabs(items: ['Day wise', 'Series wise', 'Team wise'], active: 0),
          SizedBox(height: 14),
          ChipRow(items: ['All', 'T20', 'ODI', 'Test', 'Hundred'], icons: [Icons.apps, Icons.sports_cricket, Icons.sports_baseball, Icons.shield, Icons.filter_9_plus]),
          SizedBox(height: 20),
          Row(children: [Icon(Icons.calendar_month, color: C.white), SizedBox(width: 10), Text('Fri, 26 Jun 2026', style: TextStyle(fontSize: 26, color: C.white, fontWeight: FontWeight.w900))]),
          SizedBox(height: 14),
          FixtureCard(series: 'Major League Cricket 2026', match: '9th Match • 07:00 AM', teamA: 'Freedom', teamB: 'Orcas', scoreA: '139-10\n(16.2 Overs)', scoreB: '227-6\n(20.0 Overs)', status: 'Finished', statusColor: C.green, footer: 'Seattle Orcas won by 88 runs'),
          FixtureCard(series: 'Andhra Premier League 2026', match: '25th Match • 02:00 PM', teamA: 'Capital Amaravati\nRoyals', teamB: 'Vijayawada\nSunshiners', scoreA: '', scoreB: '', status: 'Upcoming', statusColor: C.orange, footer: 'Venue – Amaravathi, India'),
          FixtureCard(series: 'Women T20 Blast 2026', match: '28th Match • 03:30 PM', teamA: 'Warwickshire\nWomen', teamB: 'Surrey Women', scoreA: '', scoreB: '', status: 'Upcoming', statusColor: C.orange, footer: 'Venue – Birmingham, England'),
          FixtureCard(series: 'The Hundred Women 2026', match: '15th Match • 07:00 PM', teamA: 'Southern Brave\nWomen', teamB: 'London Spirit\nWomen', scoreA: '', scoreB: '', status: 'Live', statusColor: C.red, footer: 'Live scoring available'),
        ],
      ),
    );
  }
}

class SeriesPage extends StatelessWidget {
  const SeriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 18),
        children: const [
          AppTabs(items: ['Day wise', 'Series wise', 'Team wise'], active: 1),
          SizedBox(height: 14),
          TextFieldLike(),
          SizedBox(height: 18),
          Text('June 2026', style: TextStyle(color: C.white, fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 10),
          SeriesListCard(title: 'Vidarbha Premier League 2026', dates: '01 Jun – 14 Jun', matches: '25 Matches', status: 'Finished', color: C.green),
          SeriesListCard(title: 'T20 Mumbai 2026', dates: '01 Jun – 13 Jun', matches: '23 Matches', status: 'Finished', color: C.green),
          SeriesListCard(title: 'Asian Legends League 2026', dates: '02 Jun – 14 Jun', matches: '19 Matches', status: 'Postponed', color: C.muted),
          SeriesListCard(title: 'Ireland Inter-Provincial T20 Trophy 2026', dates: '02 Jun – 17 Jun', matches: '9 Matches', status: 'Finished', color: C.green),
          SeriesListCard(title: 'Madhya Pradesh T20 League 2026', dates: '03 Jun – 26 Jun', matches: '48 Matches', status: 'Ongoing', color: C.red),
        ],
      ),
    );
  }
}

class ShortsPage extends StatelessWidget {
  const ShortsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 18),
        children: const [
          SectionTitle('Popular Shorts'),
          SizedBox(height: 14),
          ShortWideCard(title: 'Best cover drive compilation', time: '0:29'),
          ShortWideCard(title: 'Top bowling spells', time: '0:26'),
          ShortWideCard(title: 'Captain talk before match', time: '0:31'),
        ],
      ),
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 18),
        children: const [
          SectionTitle('More'),
          SizedBox(height: 12),
          ManualScoringPanel(),
          SizedBox(height: 18),
          SettingsTile(icon: Icons.link, title: 'WhatsApp Link', subtitle: 'https://go.wa.link/allrounder99'),
          SettingsTile(icon: Icons.public, title: 'Website Link', subtitle: 'https://Gamerush99.com'),
          SettingsTile(icon: Icons.settings_voice, title: 'Voice Commentary', subtitle: 'Coming soon'),
          SettingsTile(icon: Icons.info_outline, title: 'About App', subtitle: 'Allrounder99 cricket scoring app'),
        ],
      ),
    );
  }
}

class AppTabs extends StatelessWidget {
  final List<String> items;
  final int active;
  const AppTabs({super.key, required this.items, required this.active});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(items.length, (i) {
        final selected = i == active;
        return Expanded(
          child: Column(
            children: [
              Text(items[i], style: TextStyle(fontSize: 18, color: selected ? C.cyan : C.muted, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Container(height: 3, margin: const EdgeInsets.symmetric(horizontal: 8), decoration: selected ? glowBox(radius: 8) : null),
            ],
          ),
        );
      }),
    );
  }
}

class ChipRow extends StatelessWidget {
  final List<String> items;
  final List<IconData> icons;
  const ChipRow({super.key, required this.items, required this.icons});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 54,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, i) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: i == 0 ? C.cyan : C.line, width: i == 0 ? 1.5 : 1),
            gradient: i == 0 ? LinearGradient(colors: [C.cyan.withOpacity(0.32), C.card]) : null,
            color: C.card,
          ),
          child: Row(children: [Icon(icons[i], color: i == 0 ? C.cyan : C.white), const SizedBox(width: 8), Text(items[i], style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))]),
        ),
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemCount: items.length,
      ),
    );
  }
}

class PremiumMatchCard extends StatelessWidget {
  final bool compact;
  const PremiumMatchCard({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF0E2436), Color(0xFF07111B)]),
        border: Border.all(color: C.cyan.withOpacity(0.75)),
        boxShadow: [BoxShadow(color: C.cyan.withOpacity(0.12), blurRadius: 28)],
      ),
      child: Column(
        children: [
          Center(child: StatusPill(label: 'FINISHED', color: C.cyan)),
          const SizedBox(height: 10),
          const Text('Major League Cricket 2026 • 9th Match', textAlign: TextAlign.center, style: TextStyle(color: C.muted, fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 18),
          Row(
            children: const [
              Expanded(child: TeamScore(logo: 'SO', team: 'Orcas', score: '227-6', overs: '(20.0)', alignRight: false)),
              Icon(Icons.flash_on, color: C.cyan, size: 46),
              Expanded(child: TeamScore(logo: 'WF', team: 'Freedom', score: '139-10', overs: '(16.2)', alignRight: true)),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: Colors.black.withOpacity(0.25), border: Border.all(color: C.cyan.withOpacity(0.35))),
            child: const Text('Seattle Orcas won by 88 runs', textAlign: TextAlign.center, style: TextStyle(color: C.cyan, fontWeight: FontWeight.w900, fontSize: 16)),
          ),
        ],
      ),
    );
  }
}

class TeamScore extends StatelessWidget {
  final String logo, team, score, overs;
  final bool alignRight;
  const TeamScore({super.key, required this.logo, required this.team, required this.score, required this.overs, required this.alignRight});

  @override
  Widget build(BuildContext context) {
    final align = alignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    return Column(
      crossAxisAlignment: align,
      children: [
        TeamLogo(text: logo),
        const SizedBox(height: 10),
        Text(score, style: const TextStyle(color: C.white, fontSize: 30, fontWeight: FontWeight.w900)),
        Text(overs, style: const TextStyle(color: C.muted, fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text(team, style: const TextStyle(color: C.white, fontSize: 20, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class TeamLogo extends StatelessWidget {
  final String text;
  const TeamLogo({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      width: 58,
      decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: text == 'SO' ? [Colors.red, Colors.blue] : [Colors.pinkAccent, Colors.white24]), boxShadow: [BoxShadow(color: C.cyan.withOpacity(0.22), blurRadius: 16)]),
      alignment: Alignment.center,
      child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
    );
  }
}

class StatusPill extends StatelessWidget {
  final String label;
  final Color color;
  const StatusPill({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), color: color.withOpacity(0.16), border: Border.all(color: color)),
      child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(color: C.white, fontSize: 23, fontWeight: FontWeight.w900))),
        const Text('View all', style: TextStyle(color: C.cyan, fontWeight: FontWeight.w800)),
        const SizedBox(width: 4),
        const Icon(Icons.chevron_right, color: C.cyan),
      ],
    );
  }
}

class SeriesHighlightCard extends StatelessWidget {
  const SeriesHighlightCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      child: Row(
        children: [
          Container(width: 96, height: 96, decoration: glowBox(radius: 18, color: C.purple), alignment: Alignment.center, child: const Text('T20\nWC\n2026', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
          const SizedBox(width: 16),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Women’s T20 World Cup 2026', style: TextStyle(color: C.white, fontSize: 21, fontWeight: FontWeight.w900)),
            SizedBox(height: 9),
            Text('12 Jun – 05 Jul 2026  •  33 Matches', style: TextStyle(color: C.muted, fontWeight: FontWeight.w700)),
            SizedBox(height: 10),
            Text('Top teams. Epic battles. One Dream.', style: TextStyle(color: C.cyan, fontWeight: FontWeight.w800)),
          ])),
          const Icon(Icons.chevron_right, color: C.white),
        ],
      ),
    );
  }
}

class ShortCard extends StatelessWidget {
  final String title, time;
  final IconData icon;
  const ShortCard({super.key, required this.title, required this.time, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 156,
      margin: const EdgeInsets.only(right: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFF17283A), Color(0xFF05111A)]), border: Border.all(color: C.line)),
              child: Stack(children: [
                Center(child: Icon(icon, color: C.cyan, size: 48)),
                const Positioned(left: 10, bottom: 10, child: CircleAvatar(radius: 17, backgroundColor: Colors.black54, child: Icon(Icons.play_arrow, color: Colors.white))),
                Positioned(right: 10, bottom: 10, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)), child: Text(time, style: const TextStyle(fontWeight: FontWeight.w900)))),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: C.white, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class ShortWideCard extends StatelessWidget {
  final String title, time;
  const ShortWideCard({super.key, required this.title, required this.time});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: InfoCard(
        child: Row(children: [
          Container(height: 82, width: 112, decoration: glowBox(radius: 16), child: const Icon(Icons.play_arrow, color: C.white, size: 42)),
          const SizedBox(width: 14),
          Expanded(child: Text(title, style: const TextStyle(color: C.white, fontSize: 18, fontWeight: FontWeight.w900))),
          Text(time, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  final Widget child;
  const InfoCard({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: C.card,
        border: Border.all(color: C.line),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.22), blurRadius: 16)],
      ),
      child: child,
    );
  }
}

class FixtureCard extends StatelessWidget {
  final String series, match, teamA, teamB, scoreA, scoreB, status, footer;
  final Color statusColor;
  const FixtureCard({super.key, required this.series, required this.match, required this.teamA, required this.teamB, required this.scoreA, required this.scoreB, required this.status, required this.statusColor, required this.footer});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: InfoCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text(series, style: const TextStyle(color: C.white, fontSize: 20, fontWeight: FontWeight.w900))), StatusPill(label: status, color: statusColor)]),
          const SizedBox(height: 3),
          Text(match, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700)),
          const SizedBox(height: 18),
          Row(children: [
            TeamLogo(text: teamA.split('').take(2).join().toUpperCase()),
            const SizedBox(width: 10),
            Expanded(child: Text(scoreA.isEmpty ? teamA : '$scoreA\n$teamA', style: const TextStyle(color: C.white, fontSize: 18, fontWeight: FontWeight.w900))),
            const Icon(Icons.flash_on, color: C.cyan, size: 32),
            Expanded(child: Text(scoreB.isEmpty ? teamB : '$scoreB\n$teamB', textAlign: TextAlign.right, style: const TextStyle(color: C.white, fontSize: 18, fontWeight: FontWeight.w900))),
            const SizedBox(width: 10),
            TeamLogo(text: teamB.replaceAll('\n', ' ').split(' ').map((e) => e.isEmpty ? '' : e[0]).take(2).join().toUpperCase()),
          ]),
          const SizedBox(height: 14),
          Divider(color: C.line.withOpacity(0.85)),
          Text(footer, style: const TextStyle(color: C.cyan, fontSize: 16, fontWeight: FontWeight.w900)),
        ]),
      ),
    );
  }
}

class TextFieldLike extends StatelessWidget {
  const TextFieldLike({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: C.card, border: Border.all(color: C.cyan.withOpacity(0.6))),
      child: const Row(children: [Icon(Icons.search, color: C.muted), SizedBox(width: 10), Text('Search Series', style: TextStyle(color: C.muted, fontSize: 17, fontWeight: FontWeight.w700))]),
    );
  }
}

class SeriesListCard extends StatelessWidget {
  final String title, dates, matches, status;
  final Color color;
  const SeriesListCard({super.key, required this.title, required this.dates, required this.matches, required this.status, required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InfoCard(
        child: Row(children: [
          Container(width: 70, height: 70, decoration: glowBox(radius: 14, color: color == C.muted ? C.cyan : color), alignment: Alignment.center, child: const Icon(Icons.emoji_events, color: C.white, size: 36)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: C.white, fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(dates, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(matches, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700)),
          ])),
          StatusPill(label: status, color: color),
        ]),
      ),
    );
  }
}

class ManualScoringPanel extends StatefulWidget {
  const ManualScoringPanel({super.key});

  @override
  State<ManualScoringPanel> createState() => _ManualScoringPanelState();
}

class _ManualScoringPanelState extends State<ManualScoringPanel> {
  int runs = 0;
  int wickets = 0;
  int legalBalls = 0;
  final List<String> balls = [];
  final List<_Snapshot> history = [];

  void addBall(String label, int value, {bool legal = true, bool wicket = false}) {
    history.add(_Snapshot(runs, wickets, legalBalls, List<String>.from(balls)));
    setState(() {
      runs += value;
      if (wicket && wickets < 10) wickets++;
      if (legal) legalBalls++;
      balls.add(label);
      if (balls.length > 18) balls.removeAt(0);
    });
  }

  void undo() {
    if (history.isEmpty) return;
    final s = history.removeLast();
    setState(() {
      runs = s.runs;
      wickets = s.wickets;
      legalBalls = s.legalBalls;
      balls..clear()..addAll(s.balls);
    });
  }

  String get overs => '${legalBalls ~/ 6}.${legalBalls % 6}';
  double get crr => legalBalls == 0 ? 0 : runs / (legalBalls / 6);

  Color ballColor(String b) {
    if (b == 'W') return C.red;
    if (b == '6') return C.purple;
    if (b == '4') return C.cyan;
    if (b == 'Wd' || b == 'Nb') return C.orange;
    if (b == '0') return Colors.white;
    return Colors.blue;
  }

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Manual Scoring Panel', style: TextStyle(color: C.white, fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFF0E2436), Color(0xFF07111B)]), border: Border.all(color: C.cyan.withOpacity(0.55))),
          child: Column(children: [
            Row(children: [
              const TeamLogo(text: 'A99'),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Allrounder XI  $runs-$wickets', style: const TextStyle(color: C.white, fontSize: 26, fontWeight: FontWeight.w900)),
                Text('$overs Overs  •  CRR ${crr.toStringAsFixed(2)}', style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700)),
              ])),
            ]),
            const SizedBox(height: 14),
            SizedBox(
              height: 38,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: balls.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, i) {
                  final b = balls[i];
                  return CircleAvatar(radius: 18, backgroundColor: ballColor(b), child: Text(b, style: TextStyle(color: b == '0' ? Colors.black : Colors.white, fontWeight: FontWeight.w900, fontSize: b.length > 1 ? 11 : 15)));
                },
              ),
            ),
          ]),
        ),
        const SizedBox(height: 16),
        Wrap(spacing: 10, runSpacing: 10, children: [
          ScoreButton('0', () => addBall('0', 0)),
          ScoreButton('1', () => addBall('1', 1)),
          ScoreButton('2', () => addBall('2', 2)),
          ScoreButton('3', () => addBall('3', 3)),
          ScoreButton('4', () => addBall('4', 4)),
          ScoreButton('6', () => addBall('6', 6)),
          ScoreButton('Wicket', () => addBall('W', 0, wicket: true), color: C.red),
          ScoreButton('Wide', () => addBall('Wd', 1, legal: false), color: C.orange),
          ScoreButton('No Ball', () => addBall('Nb', 1, legal: false), color: C.orange),
          ScoreButton('Bye', () => addBall('B', 1), color: Colors.blueGrey),
          ScoreButton('Leg Bye', () => addBall('LB', 1), color: Colors.blueGrey),
          ScoreButton('Undo', undo, color: C.muted),
        ]),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: 'Allrounder99 Score\nAllrounder XI $runs-$wickets ($overs)\nCRR ${crr.toStringAsFixed(2)}'));
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Score copied')));
            },
            icon: const Icon(Icons.share),
            label: const Text('Copy / Share Score'),
          ),
        ),
      ]),
    );
  }
}

class _Snapshot {
  final int runs, wickets, legalBalls;
  final List<String> balls;
  _Snapshot(this.runs, this.wickets, this.legalBalls, this.balls);
}

class ScoreButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color;
  const ScoreButton(this.label, this.onTap, {super.key, this.color = C.cyan});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: label.length > 4 ? 104 : 62,
      height: 48,
      child: FilledButton(
        style: FilledButton.styleFrom(backgroundColor: color.withOpacity(0.18), foregroundColor: color, side: BorderSide(color: color.withOpacity(0.8)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        onPressed: onTap,
        child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
    );
  }
}

class SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const SettingsTile({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InfoCard(
        child: Row(children: [
          Icon(icon, color: C.cyan, size: 30),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: C.white, fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w600)),
          ])),
          const Icon(Icons.chevron_right, color: C.muted),
        ]),
      ),
    );
  }
}
