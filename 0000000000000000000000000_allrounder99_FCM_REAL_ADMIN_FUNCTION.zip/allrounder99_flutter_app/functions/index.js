const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');

admin.initializeApp();

const ADMIN_PIN = defineSecret('ADMIN_PIN');

exports.sendAllrounder99Push = onCall(
  { region: 'us-central1', secrets: [ADMIN_PIN] },
  async (request) => {
    const configuredPin = ADMIN_PIN.value();
    const { title, body, topic, adminPin } = request.data || {};

    if (!configuredPin) {
      throw new HttpsError('failed-precondition', 'ADMIN_PIN secret is not set in Firebase Functions.');
    }
    if (!adminPin || adminPin !== configuredPin) {
      throw new HttpsError('permission-denied', 'Invalid admin PIN.');
    }
    if (!title || !body) {
      throw new HttpsError('invalid-argument', 'Notification title and body are required.');
    }

    const safeTopic = (topic || 'all_users').replace(/^\/topics\//, '').trim();
    if (!/^[A-Za-z0-9_\-.~%]+$/.test(safeTopic)) {
      throw new HttpsError('invalid-argument', 'Invalid FCM topic name.');
    }

    const message = {
      topic: safeTopic,
      notification: { title: String(title), body: String(body) },
      data: {
        type: 'allrounder99_push',
        click_action: 'FLUTTER_NOTIFICATION_CLICK',
        createdAt: new Date().toISOString()
      },
      android: {
        priority: 'high',
        notification: {
          channelId: 'allrounder99_alerts',
          sound: 'default'
        }
      }
    };

    const messageId = await admin.messaging().send(message);
    return { ok: true, topic: safeTopic, messageId };
  }
);
