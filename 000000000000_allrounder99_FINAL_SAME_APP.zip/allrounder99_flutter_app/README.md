Allrounder99 Final Same App UI
- Black + cyan blue theme
- Allrounder99 logo fixed on splash and home
- Home, Shorts, Fixtures, Series, More
- Match detail tabs: Info, Live, Commentary, Scorecard, History, Points Table
- TV style live screen
- Add Run option removed
