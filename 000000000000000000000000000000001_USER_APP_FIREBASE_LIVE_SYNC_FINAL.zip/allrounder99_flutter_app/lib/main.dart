import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const Allrounder99App());
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Allrounder99',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColor.bg,
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const SplashScreen(),
    );
  }
}

class AppColor {
  static const bg = Color(0xFF070B0F);
  static const bg2 = Color(0xFF0B1218);
  static const card = Color(0xFF172029);
  static const card2 = Color(0xFF202A33);
  static const line = Color(0xFF34404B);
  static const cyan = Color(0xFF08C7FF);
  static const blue = Color(0xFF058DFF);
  static const text = Color(0xFFE9F1F7);
  static const muted = Color(0xFF9AA6B2);
  static const green = Color(0xFF28A745);
  static const red = Color(0xFFE64040);
  static const orange = Color(0xFFE59A3A);
  static const purple = Color(0xFF7A4DFF);
}

String teamCode(String name) {
  final n = name.toUpperCase();
  if (n.contains('CAMR') || n.contains('AMARAVATI')) return 'CAMR';
  if (n.contains('VJS') || n.contains('VIJAYAWADA')) return 'VJS';
  if (n.contains('WARWICKSHIRE')) return 'WAR';
  if (n.contains('SURREY')) return 'SUR';
  if (n.contains('IND')) return 'IND';
  if (n.contains('IRE')) return 'IRE';
  if (n.trim().length <= 4) return n.trim();
  return n.trim().split(' ').map((e) => e.isNotEmpty ? e[0] : '').take(3).join();
}

String teamFlag(String name) {
  final n = name.toUpperCase();
  if (n.contains('CAMR') || n.contains('AMARAVATI')) return '🏰';
  if (n.contains('VJS') || n.contains('VIJAYAWADA')) return '☀️';
  if (n.contains('WARWICKSHIRE')) return '🏏';
  if (n.contains('SURREY')) return '🛡️';
  if (n.contains('IND')) return '🇮🇳';
  if (n.contains('IRE')) return '🇮🇪';
  return '🏏';
}

Color teamColor(String name) {
  final n = name.toUpperCase();
  if (n.contains('CAMR') || n.contains('AMARAVATI')) return const Color(0xFFC51238);
  if (n.contains('VJS') || n.contains('VIJAYAWADA')) return const Color(0xFF1E9C65);
  if (n.contains('WARWICKSHIRE')) return const Color(0xFF7A4DFF);
  if (n.contains('SURREY')) return const Color(0xFF1E70D8);
  if (n.contains('IND')) return const Color(0xFF1E9C65);
  if (n.contains('IRE')) return const Color(0xFF2F9A44);
  return AppColor.blue;
}

class TeamLogo extends StatelessWidget {
  final String code;
  final String flag;
  final Color color;
  final double size;
  final bool showCode;

  const TeamLogo({
    super.key,
    required this.code,
    required this.flag,
    required this.color,
    this.size = 52,
    this.showCode = true,
  });

  @override
  Widget build(BuildContext context) {
    final codeFont = size < 40 ? 8.5 : 10.5;
    return SizedBox(
      width: size,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: size,
            width: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [color, color.withOpacity(0.55)]),
              border: Border.all(color: Colors.white.withOpacity(0.20), width: 1),
              boxShadow: [BoxShadow(color: color.withOpacity(0.28), blurRadius: 12)],
            ),
            child: Center(child: Text(flag, style: TextStyle(fontSize: size * 0.48))),
          ),
          if (showCode) ...[
            const SizedBox(height: 4),
            Text(
              code,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: codeFont, fontWeight: FontWeight.w900, color: AppColor.text),
            ),
          ],
        ],
      ),
    );
  }
}



class LiveMatchSync {
  static const Map<String, dynamic> fallback = {
    'series': 'Andhra Premier League 2026',
    'matchTitle': '25th Match',
    'teamA': 'CAMR',
    'teamB': 'VJS',
    'teamAScore': 'Bowling',
    'teamBScore': '46-1',
    'overs': '5.1 Over',
    'status': 'Live',
    'currentRun': '1 Run',
    'result': 'VJS 46-1 (5.1) • Live now • 1 Run',
    'battingTeam': 'VJS',
    'bowlingTeam': 'CAMR',
  };

  static DocumentReference<Map<String, dynamic>> get doc =>
      FirebaseFirestore.instance.collection('allrounder99').doc('live_match');
}

class LiveMatchBuilder extends StatelessWidget {
  final Widget Function(BuildContext context, Map<String, dynamic> data) builder;
  const LiveMatchBuilder({super.key, required this.builder});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: LiveMatchSync.doc.snapshots(),
      builder: (context, snapshot) {
        final data = Map<String, dynamic>.from(LiveMatchSync.fallback);
        final cloudData = snapshot.data?.data();
        if (cloudData != null) {
          data.addAll(cloudData);
        }
        return builder(context, data);
      },
    );
  }
}

String liveValue(Map<String, dynamic> data, String key) {
  final value = data[key];
  if (value == null) return '${LiveMatchSync.fallback[key] ?? ''}';
  final text = value.toString().trim();
  return text.isEmpty ? '${LiveMatchSync.fallback[key] ?? ''}' : text;
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 4500), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const MainShell()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: Column(
            children: [
              const Spacer(),
              Container(
                height: 230,
                width: 230,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColor.cyan.withOpacity(0.30),
                      blurRadius: 55,
                      spreadRadius: 8,
                    ),
                  ],
                ),
                child: ClipOval(child: Image.asset('assets/logo.png', fit: BoxFit.contain)),
              ),
              const SizedBox(height: 20),
              const Text(
                'ALLROUNDER99',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  color: AppColor.text,
                  fontStyle: FontStyle.italic,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'CRICKET  •  FAST SCORES  •  REAL TIME',
                style: TextStyle(fontSize: 12, color: AppColor.cyan, fontWeight: FontWeight.w700),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 68),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: const LinearProgressIndicator(
                    minHeight: 4,
                    color: AppColor.cyan,
                    backgroundColor: AppColor.card2,
                  ),
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  late final List<Widget> pages = [
    HomePage(openMatch: openMatch),
    FixturesPage(openMatch: openMatch),
    const SeriesPage(),
    const MorePage(),
  ];

  void openMatch() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF0C1117),
          border: Border(top: BorderSide(color: AppColor.line, width: 0.5)),
        ),
        child: SafeArea(
          top: false,
          child: NavigationBar(
            selectedIndex: index,
            height: 64,
            backgroundColor: Colors.transparent,
            indicatorColor: AppColor.cyan.withOpacity(0.14),
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            onDestinationSelected: (value) => setState(() => index = value),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: AppColor.cyan), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.sports_cricket_outlined), selectedIcon: Icon(Icons.sports_cricket, color: AppColor.cyan), label: 'Fixtures'),
              NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events, color: AppColor.cyan), label: 'Series'),
              NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz, color: AppColor.cyan), label: 'More'),
            ],
          ),
        ),
      ),
    );
  }
}

class GradientPage extends StatelessWidget {
  final Widget child;
  const GradientPage({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF030608), Color(0xFF071017), Color(0xFF051D2A)],
        ),
      ),
      child: child,
    );
  }
}

class TopLogo extends StatelessWidget {
  const TopLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppColor.cyan, width: 1),
          ),
          child: ClipOval(child: Image.asset('assets/logo.png', fit: BoxFit.contain)),
        ),
        const SizedBox(width: 8),
        const Text.rich(
          TextSpan(
            children: [
              TextSpan(text: 'ALLROUNDER', style: TextStyle(color: AppColor.text)),
              TextSpan(text: '99', style: TextStyle(color: AppColor.cyan)),
            ],
          ),
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, letterSpacing: 0.3),
        ),
      ],
    );
  }
}

class CircleTeam extends StatelessWidget {
  final String label;
  final Color color;
  final String? flag;
  const CircleTeam({super.key, required this.label, required this.color, this.flag});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: 50,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [color, color.withOpacity(0.55)]),
        border: Border.all(color: Colors.white.withOpacity(0.20)),
      ),
      child: Center(
        child: Text(flag ?? label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.onTap});

  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: AppColor.card.withOpacity(0.94),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColor.line.withOpacity(0.85), width: 0.75),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: child,
    );
    if (onTap == null) return card;
    return InkWell(borderRadius: BorderRadius.circular(12), onTap: onTap, child: card);
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  const SectionHeader(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
      child: Row(
        children: [
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const Spacer(),
          const Text('View all', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w700, fontSize: 12)),
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final bool selected;
  final Color? color;
  final VoidCallback? onTap;
  const Pill(this.text, {super.key, this.selected = false, this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColor.cyan;
    final child = Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? c.withOpacity(0.95) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: selected ? c : AppColor.line),
      ),
      child: Text(text, style: TextStyle(fontWeight: FontWeight.w700, color: selected ? Colors.white : AppColor.muted, fontSize: 12)),
    );
    return GestureDetector(
      onTap: onTap ?? () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$text selected'), duration: const Duration(milliseconds: 800))),
      child: child,
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback openMatch;
  const HomePage({super.key, required this.openMatch});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
          children: [
            Row(
              children: [
                const TopLogo(),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(color: AppColor.card, borderRadius: BorderRadius.circular(22)),
                  child: const Row(children: [Icon(Icons.search, size: 18), SizedBox(width: 8), Text('Search', style: TextStyle(color: AppColor.muted))]),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SimpleOptionPage(title: 'Settings', subtitle: 'App settings and preferences'))), icon: const Icon(Icons.settings_outlined)),
              ],
            ),
            const SizedBox(height: 18),
            const Row(children: [Pill('Featured', selected: true), SizedBox(width: 10), Pill('Live'), SizedBox(width: 10), Pill('WT20 WC')]),
            const SizedBox(height: 12),
            FeaturedMatchCard(openMatch: openMatch),
            const SizedBox(height: 12),
            const QuickFeatureGrid(),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: const [
                Pill('WT20 WC 2026', selected: true), SizedBox(width: 8), Pill('WT20 WC Winners'), SizedBox(width: 8), Pill('Rankings'),
              ]),
            ),
            const SectionHeader('Trending Series'),
            GlassCard(
              child: Row(
                children: [
                  Container(
                    height: 72,
                    width: 86,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), gradient: const LinearGradient(colors: [Color(0xFF712BFF), Color(0xFFFF2995)])),
                    child: const Center(child: Text('T20\nWC', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text("Women's T20 World Cup 2026", style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      SizedBox(height: 8),
                      Text('12 Jun - 05 Jul 2026', style: TextStyle(color: AppColor.muted)),
                      SizedBox(height: 4),
                      Text('33 Matches', style: TextStyle(color: AppColor.muted)),
                    ]),
                  ),
                  const Icon(Icons.chevron_right, color: AppColor.muted),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class QuickFeatureGrid extends StatelessWidget {
  const QuickFeatureGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.flash_on, 'Live Matches', 'Fast score updates'),
      (Icons.comment_outlined, 'Commentary', 'Ball by ball'),
      (Icons.table_chart_outlined, 'Scorecards', 'Full match score'),
      (Icons.emoji_events_outlined, 'Points Table', 'League standings'),
      (Icons.leaderboard_outlined, 'Rankings', 'ICC & league'),
      (Icons.analytics_outlined, 'Insights & Graphs', 'Trends & analysis'),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 2.45,
      ),
      itemBuilder: (context, i) {
        final item = items[i];
        return GlassCard(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => SimpleOptionPage(title: item.$2, subtitle: featureSubtitle(item.$2))),
          ),
          child: Row(
            children: [
              Icon(item.$1, color: AppColor.cyan, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(item.$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12.5)),
                    const SizedBox(height: 2),
                    Text(item.$3, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColor.muted, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

String featureSubtitle(String t) {
  switch (t) {
    case 'Live Matches': return 'Live score, current over, run rate, target and live match status.';
    case 'Fixtures & Schedule': return 'Day wise, series wise and team wise upcoming fixtures.';
    case 'Series & Leagues': return 'International, domestic and T20 league tournament details.';
    case 'Commentary': return 'Ball by ball commentary with runs, wickets, boundaries and over summary.';
    case 'Scorecards': return 'Batting, bowling, extras, fall of wickets and full innings scorecards.';
    case 'Points Table': return 'Team standings with played, won, lost, NRR and points.';
    case 'Squads': return 'Playing XI, bench players and team squad list.';
    case 'Players': return 'Player profile, batting stats, bowling stats, form and records.';
    case 'Teams': return 'Team profile, squad, schedule, recent form and records.';
    case 'Rankings': return 'Team and player rankings for batting, bowling and all-rounders.';
    case 'Stats & Records': return 'Batting records, bowling records, strike rate, economy and milestones.';
    case 'Match Insights': return 'Win probability, head to head, venue data and match summary.';
    case 'Insights & Graphs': return 'Run rate graph, worm graph, partnerships and match trends.';
    case 'News': return 'Latest cricket news and match stories. Shorts option removed as requested.';
    case 'Voice Commentary': return 'Voice commentary option screen ready.';
    default: return 'This option is working in Allrounder99 demo mode.';
  }
}


class FeaturedMatchCard extends StatelessWidget {
  final VoidCallback openMatch;
  const FeaturedMatchCard({super.key, required this.openMatch});

  @override
  Widget build(BuildContext context) {
    return LiveMatchBuilder(
      builder: (context, data) {
        final teamA = liveValue(data, 'teamA');
        final teamB = liveValue(data, 'teamB');
        final teamAScore = liveValue(data, 'teamAScore');
        final teamBScore = liveValue(data, 'teamBScore');
        final series = liveValue(data, 'series');
        final matchTitle = liveValue(data, 'matchTitle');
        final status = liveValue(data, 'status');
        final overs = liveValue(data, 'overs');
        final result = liveValue(data, 'result');
        return GlassCard(
          onTap: openMatch,
          padding: const EdgeInsets.all(0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(13),
                child: Row(
                  children: [
                    Pill(status.toUpperCase(), selected: true, color: AppColor.red),
                    const SizedBox(width: 8),
                    Expanded(child: Text('$series, $matchTitle', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14))),
                    const Icon(Icons.chevron_right, color: AppColor.muted),
                  ],
                ),
              ),
              const Divider(height: 1, color: AppColor.line),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    TeamLogo(code: teamCode(teamA), flag: teamFlag(teamA), color: teamColor(teamA)),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(teamA, style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Text(teamAScore, style: const TextStyle(color: AppColor.muted)),
                    ])),
                    const Icon(Icons.flash_on, color: AppColor.text, size: 30),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Text(teamBScore, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                      Text(overs, style: const TextStyle(color: AppColor.muted)),
                      const SizedBox(height: 8),
                      Text(teamB, style: const TextStyle(fontWeight: FontWeight.w700)),
                    ])),
                    const SizedBox(width: 10),
                    TeamLogo(code: teamCode(teamB), flag: teamFlag(teamB), color: teamColor(teamB)),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: const BoxDecoration(color: Color(0xFF0E1820), borderRadius: BorderRadius.vertical(bottom: Radius.circular(12))),
                child: Center(child: Text(result, style: const TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900))),
              ),
            ],
          ),
        );
      },
    );
  }
}

class ShortTile extends StatelessWidget {
  final String title;
  final Color color;
  const ShortTile({super.key, required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 124,
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color, Colors.black]),
        border: Border.all(color: AppColor.line),
      ),
      child: Stack(
        children: [
          const Center(child: Icon(Icons.play_circle_fill, size: 44, color: Colors.white)),
          Positioned(left: 8, right: 8, bottom: 8, child: Text(title, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12))),
        ],
      ),
    );
  }
}

class ShortsPage extends StatelessWidget {
  const ShortsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Row(children: [Text('Shorts', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Spacer(), Icon(Icons.search)]),
            const SizedBox(height: 14),
            const Row(children: [Pill('Trending', selected: true), SizedBox(width: 8), Pill('Popular'), SizedBox(width: 8), Pill('Recent')]),
            const SizedBox(height: 12),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 0.74,
              children: const [
                ShortTile(title: 'RCB last over thriller', color: Color(0xFFC21E36)),
                ShortTile(title: 'Top 10 catches', color: Color(0xFFE7A928)),
                ShortTile(title: 'MS Dhoni six', color: Color(0xFF4352C8)),
                ShortTile(title: 'Best yorkers', color: Color(0xFF1283C5)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class FixturesPage extends StatelessWidget {
  final VoidCallback openMatch;
  const FixturesPage({super.key, required this.openMatch});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Row(children: [Text('Fixtures', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Spacer(), Icon(Icons.search), SizedBox(width: 12), Icon(Icons.notifications_none)]),
            const SizedBox(height: 12),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [Text('Day wise', style: TextStyle(fontWeight: FontWeight.w800, color: AppColor.cyan)), Text('Series wise'), Text('Team wise')]),
            const SizedBox(height: 12),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: const [Pill('All', selected: true), SizedBox(width: 8), Pill('T20'), SizedBox(width: 8), Pill('ODI'), SizedBox(width: 8), Pill('Test'), SizedBox(width: 8), Pill('Hundred')])),
            const SizedBox(height: 16),
            const Text('Fri, 26 Jun 2026', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            FixtureCard(openMatch: openMatch, title: 'Andhra Premier League 2026', status: 'Live', scoreA: '', teamA: 'CAMR', scoreB: '46-1 (5.1)', teamB: 'VJS', result: 'Live now - VJS 46-1 after 5.1 overs'),
            FixtureCard(openMatch: openMatch, title: 'Andhra Premier League 2026', status: 'Upcoming', scoreA: '', teamA: 'Capital Amaravati Royals', scoreB: '', teamB: 'Vijayawada Sunshiners', result: 'Venue - Amaravathi, India'),
            FixtureCard(openMatch: openMatch, title: 'Women T20 Blast 2026', status: 'Upcoming', scoreA: '', teamA: 'Warwickshire Women', scoreB: '', teamB: 'Surrey Women', result: 'Venue - Birmingham, England'),
          ],
        ),
      ),
    );
  }
}

class FixtureCard extends StatelessWidget {
  final VoidCallback? openMatch;
  final String title, status, scoreA, teamA, scoreB, teamB, result;
  const FixtureCard({super.key, this.openMatch, required this.title, required this.status, required this.scoreA, required this.teamA, required this.scoreB, required this.teamB, required this.result});

  @override
  Widget build(BuildContext context) {
    final statusColor = status == 'Live' ? AppColor.red : (status == 'Finished' ? AppColor.green : AppColor.orange);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        onTap: openMatch,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))), Pill(status, color: statusColor, selected: true)]),
          const SizedBox(height: 4),
          const Text('9th Match - 07:00 AM', style: TextStyle(color: AppColor.muted)),
          const Divider(height: 22, color: AppColor.line),
          Row(children: [
            TeamLogo(code: teamCode(teamA), flag: teamFlag(teamA), color: teamColor(teamA), size: 48), const SizedBox(width: 10),
            Expanded(child: Text(scoreA.isEmpty ? teamA : '$scoreA\n$teamA', style: const TextStyle(fontWeight: FontWeight.w800))),
            const Icon(Icons.flash_on, color: AppColor.text),
            Expanded(child: Text(scoreB.isEmpty ? teamB : '$scoreB\n$teamB', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800))), const SizedBox(width: 10),
            TeamLogo(code: teamCode(teamB), flag: teamFlag(teamB), color: teamColor(teamB), size: 48),
          ]),
          const Divider(height: 22, color: AppColor.line),
          Text(result, style: TextStyle(color: result.startsWith('Venue') ? Color(0xFFFFF3A5) : Color(0xFFFF8BA0), fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class SeriesPage extends StatelessWidget {
  const SeriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Row(children: [Text('Series', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Spacer(), Icon(Icons.search)]),
            const SizedBox(height: 12),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [Text('Day wise'), Text('Series wise', style: TextStyle(fontWeight: FontWeight.w800, color: AppColor.cyan)), Text('Team wise')]),
            const SizedBox(height: 12),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: const [Pill('All', selected: true), SizedBox(width: 8), Pill('International'), SizedBox(width: 8), Pill('T20 Leagues'), SizedBox(width: 8), Pill('Domestic')])),
            const SizedBox(height: 12),
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColor.card, borderRadius: BorderRadius.circular(10)), child: const Row(children: [Icon(Icons.search, color: AppColor.muted), SizedBox(width: 10), Text('Search Series', style: TextStyle(color: AppColor.muted))])),
            const SizedBox(height: 16),
            const Text('June 2026', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            const SeriesTile(name: 'Vidarbha Premier League 2026', dates: '01 Jun - 14 Jun', matches: '25 Matches', status: 'Finished', color: Color(0xFFB78919)),
            const SeriesTile(name: 'T20 Mumbai 2026', dates: '01 Jun - 13 Jun', matches: '23 Matches', status: 'Finished', color: Color(0xFF165CC3)),
            const SeriesTile(name: 'Asian Legends League 2026', dates: '02 Jun - 14 Jun', matches: '19 Matches', status: 'Postponed', color: Color(0xFFC71225)),
            const SeriesTile(name: 'Ireland Inter-Provincial T20 Trophy 2026', dates: '02 Jun - 17 Jun', matches: '9 Matches', status: 'Finished', color: Color(0xFF0B7D3C)),
            const SeriesTile(name: 'Madhya Pradesh T20 League 2026', dates: '03 Jun - 26 Jun', matches: '48 Matches', status: 'Ongoing', color: Color(0xFF123A8D)),
          ],
        ),
      ),
    );
  }
}

class SeriesTile extends StatelessWidget {
  final String name, dates, matches, status;
  final Color color;
  const SeriesTile({super.key, required this.name, required this.dates, required this.matches, required this.status, required this.color});

  @override
  Widget build(BuildContext context) {
    final c = status == 'Finished' ? AppColor.green : (status == 'Ongoing' ? AppColor.red : AppColor.muted);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SimpleOptionPage(title: name, subtitle: '$dates • $matches • $status'))),
        child: Row(children: [
          Container(height: 64, width: 64, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: color), child: Center(child: Text(name.split(' ').first.substring(0, 1), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)), const SizedBox(height: 7), Text(dates, style: const TextStyle(color: AppColor.muted)), const SizedBox(height: 4), Text(matches, style: const TextStyle(color: AppColor.muted)),
          ])),
          Pill(status, color: c),
        ]),
      ),
    );
  }
}


class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: const [
            Text('More', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            SizedBox(height: 14),
            MoreWelcomeCard(),
            SizedBox(height: 14),
            MenuItem(icon: Icons.flash_on, title: 'Live Matches'),
            MenuItem(icon: Icons.calendar_month_outlined, title: 'Fixtures & Schedule'),
            MenuItem(icon: Icons.emoji_events_outlined, title: 'Series & Leagues'),
            MenuItem(icon: Icons.comment_outlined, title: 'Commentary'),
            MenuItem(icon: Icons.table_chart_outlined, title: 'Scorecards'),
            MenuItem(icon: Icons.leaderboard_outlined, title: 'Points Table'),
            MenuItem(icon: Icons.notifications_active_outlined, title: 'Live Score Alerts', trailing: 'On'),
            MenuItem(icon: Icons.settings_outlined, title: 'Settings'),
            MenuItem(icon: Icons.language, title: 'Language', trailing: 'English'),
            MenuItem(icon: Icons.share_outlined, title: 'Share App'),
            MenuItem(icon: Icons.star_border, title: 'Rate Us'),
            MenuItem(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy'),
            MenuItem(icon: Icons.description_outlined, title: 'Terms & Conditions'),
            MenuItem(icon: Icons.info_outline, title: 'About Allrounder99', trailing: 'v1.0.0'),
          ],
        ),
      ),
    );
  }
}

class MoreWelcomeCard extends StatelessWidget {
  const MoreWelcomeCard({super.key});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColor.cyan, width: 1.4),
              boxShadow: [
                BoxShadow(
                  color: AppColor.cyan.withOpacity(0.25),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ClipOval(child: Image.asset('assets/logo.png', fit: BoxFit.contain)),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome to Allrounder99',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppColor.text),
                ),
                SizedBox(height: 6),
                Text(
                  'Scoring app for live cricket scores, scorecards and match history.',
                  style: TextStyle(fontSize: 13, height: 1.35, color: AppColor.muted, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final VoidCallback? onTap;
  const MenuItem({super.key, required this.icon, required this.title, this.trailing, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        onTap: onTap ?? () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => SimpleOptionPage(title: title, subtitle: _subtitle(title))),
          );
        },
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        child: Row(children: [
          Icon(icon, size: 20, color: AppColor.text),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))),
          Text(trailing ?? '', style: const TextStyle(color: AppColor.muted)),
          const Icon(Icons.chevron_right, color: AppColor.muted),
        ]),
      ),
    );
  }

  String _subtitle(String t) {
    switch (t) {
      case 'Live Matches': return featureSubtitle(t);
      case 'Fixtures & Schedule': return featureSubtitle(t);
      case 'Series & Leagues': return featureSubtitle(t);
      case 'Commentary': return featureSubtitle(t);
      case 'Scorecards': return featureSubtitle(t);
      case 'Points Table': return featureSubtitle(t);
      case 'Squads': return featureSubtitle(t);
      case 'Stats & Records': return featureSubtitle(t);
      case 'Match Insights': return featureSubtitle(t);
      case 'Insights & Graphs': return featureSubtitle(t);
      case 'News': return featureSubtitle(t);
      case 'Voice Commentary': return featureSubtitle(t);
      case 'My Profile': return 'Profile details, photo, phone and account info.';
      case 'My Matches': return 'Saved and followed matches list.';
      case 'My Series': return 'Followed series and tournament list.';
      case 'Live Score Alerts': return 'Live alerts are switched on.';
      case 'Favorite Teams': return 'Choose and manage favorite teams.';
      case 'Watchlist': return 'Matches and players saved to watchlist.';
      case 'Downloads': return 'Offline scorecards and saved match data.';
      case 'Rankings': return featureSubtitle(t);
      case 'Teams': return featureSubtitle(t);
      case 'Players': return featureSubtitle(t);
      case 'Settings': return 'Theme, language, notifications and app preferences.';
      case 'Language': return 'English selected. Hindi can be added in next update.';
      case 'Share App': return 'Share Allrounder99 with friends.';
      case 'Rate Us': return 'Rating screen ready for Play Store link.';
      case 'Help & Support': return 'Support page with contact details.';
      case 'Privacy Policy': return 'Privacy policy page placeholder.';
      case 'Terms & Conditions': return 'Terms and conditions page placeholder.';
      case 'About Allrounder99': return 'Allrounder99 v1.0.0 cricket scoring app.';
      default: return 'This option is working.';
    }
  }
}

class SimpleOptionPage extends StatelessWidget {
  final String title;
  final String subtitle;
  const SimpleOptionPage({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              Row(children: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)), Expanded(child: Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)))]),
              const SizedBox(height: 14),
              GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: const [TopLogo(), Spacer(), Icon(Icons.check_circle, color: AppColor.cyan)]),
                const SizedBox(height: 18),
                Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColor.cyan)),
                const SizedBox(height: 10),
                if (title == 'Privacy Policy' || title == 'Terms & Conditions') ...[
                  LegalContent(title: title),
                ] else ...[
                  Text(subtitle, style: const TextStyle(fontSize: 15, color: AppColor.text, height: 1.45)),
                  const SizedBox(height: 16),
                  const Text('Screen connected successfully. Backend/API integration can be added later.', style: TextStyle(color: AppColor.muted)),
                  const SizedBox(height: 16),
                  FeatureContent(title: title),
                ],
              ])),
            ],
          ),
        ),
      ),
    );
  }
}



class LegalSection {
  final String heading;
  final String body;
  const LegalSection(this.heading, this.body);
}

class LegalContent extends StatelessWidget {
  final String title;
  const LegalContent({super.key, required this.title});

  bool get isPrivacy => title == 'Privacy Policy';

  @override
  Widget build(BuildContext context) {
    final sections = isPrivacy ? privacyPolicySections : termsSections;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Last Updated: 26 June 2026', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        Text(
          isPrivacy
              ? 'Allrounder99 respects your privacy. This Privacy Policy explains how our app handles user information.'
              : 'Welcome to Allrounder99. By using this app, you agree to the following Terms and Conditions.',
          style: const TextStyle(fontSize: 15, color: AppColor.text, height: 1.45),
        ),
        const SizedBox(height: 16),
        for (final section in sections)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColor.bg2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColor.line),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(section.heading, style: const TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900, fontSize: 15.5)),
                const SizedBox(height: 8),
                Text(section.body, style: const TextStyle(color: AppColor.text, height: 1.45)),
              ],
            ),
          ),
      ],
    );
  }
}

const privacyPolicySections = [
  LegalSection('1. Information We Collect', 'Allrounder99 is mainly a cricket score and information app. At present, the app does not require users to create an account or login. The app is designed for viewing cricket scores, match information, and related updates.'),
  LegalSection('2. App Usage Data', 'The app may use basic technical information required for app performance, security, and content display. This may include device type, app version, crash reports, and usage performance data.'),
  LegalSection('3. Third-Party Services', 'Our app may use third-party services for features such as cricket score data, app performance, analytics, or future updates. These services may collect limited technical data according to their own privacy policies.'),
  LegalSection('4. External Links', 'The app may contain links to external pages or services. We are not responsible for the privacy practices or content of external platforms.'),
  LegalSection('5. Children’s Privacy', 'Allrounder99 is not intended to collect personal information from children. If any personal information is found to be collected unintentionally, it will be removed as soon as possible.'),
  LegalSection('6. Data Security', 'We take reasonable steps to protect app-related data. However, no online service is 100% secure.'),
  LegalSection('7. Changes to This Policy', 'We may update this Privacy Policy from time to time. Any changes will be posted in the app or through an official update.'),
  LegalSection('8. Contact Us', 'For any privacy-related questions, users can contact Allrounder99 support through the contact option provided inside the app.'),
];

const termsSections = [
  LegalSection('1. Use of the App', 'Allrounder99 is provided for cricket score, match information, updates, and entertainment purposes only. You agree to use the app only for lawful purposes and not to misuse, copy, damage, or interfere with the app.'),
  LegalSection('2. No Account Required', 'At present, the app does not require login or registration for normal users. Users can open the app and view available cricket-related information.'),
  LegalSection('3. Cricket Scores and Information', 'We try to provide accurate and updated cricket information. However, scores, match details, schedules, and other content may sometimes be delayed, incomplete, or incorrect. Allrounder99 does not guarantee 100% accuracy of live scores or match information.'),
  LegalSection('4. No Betting or Gambling Service', 'Allrounder99 does not provide betting, gambling, or real-money gaming services inside the app. The app is only for cricket information and score viewing.'),
  LegalSection('5. External Links', 'The app may include links to external platforms or services. We are not responsible for third-party websites, content, offers, or services.'),
  LegalSection('6. Intellectual Property', 'The app name, logo, design, layout, and content belong to Allrounder99 or its respective owners. Users are not allowed to copy, sell, modify, or distribute the app without permission.'),
  LegalSection('7. App Changes', 'We may update, modify, remove, or add features in the app at any time without prior notice.'),
  LegalSection('8. Limitation of Liability', 'Allrounder99 will not be responsible for any loss, damage, error, delay, or issue caused by using the app or relying on app information.'),
  LegalSection('9. Termination', 'We may restrict or stop access to the app if any user misuses the app or violates these Terms and Conditions.'),
  LegalSection('10. Contact Us', 'For any questions about these Terms and Conditions, users can contact Allrounder99 support through the contact option provided inside the app.'),
];

class FeatureContent extends StatelessWidget {
  final String title;
  const FeatureContent({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final rows = _rows(title);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Preview', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900, fontSize: 16)),
        const SizedBox(height: 10),
        for (final row in rows) Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColor.bg2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColor.line),
            ),
            child: Row(
              children: [
                Icon(row.$1, color: AppColor.cyan, size: 20),
                const SizedBox(width: 10),
                Expanded(child: Text(row.$2, style: const TextStyle(fontWeight: FontWeight.w700))),
                if (row.$3.isNotEmpty) Text(row.$3, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  List<(IconData, String, String)> _rows(String t) {
    switch (t) {
      case 'Live Matches':
        return [
          (Icons.circle, 'CAMR vs VJS • Live', 'VJS 46-1'),
          (Icons.flash_on, 'Current ball TV update', '1 Run'),
          (Icons.speed, 'Run Rate / Balls Remaining', '8.9 / 89'),
        ];
      case 'Fixtures & Schedule':
        return [
          (Icons.today, 'Day wise fixtures', 'Today'),
          (Icons.emoji_events, 'Series wise fixtures', 'T20'),
          (Icons.groups, 'Team wise fixtures', 'India'),
        ];
      case 'Series & Leagues':
        return [
          (Icons.emoji_events, 'IPL / T20 League / Domestic', 'Live'),
          (Icons.calendar_month, 'Series dates and total matches', '33'),
          (Icons.table_chart, 'Points table and squads', 'Ready'),
        ];
      case 'Commentary':
        return [
          (Icons.sports_cricket, '5.1 FOUR! Beautiful square drive.', '46-1'),
          (Icons.sports_cricket, '5.0 Single, tucked away to mid-wicket.', '42-1'),
          (Icons.sports_cricket, 'Over summary with runs and wickets', '12 runs'),
        ];
      case 'Scorecards':
        return [
          (Icons.person, 'Ashwin Hebbar 16 (9)', 'SR 177.78'),
          (Icons.person, 'Harshavardhan 23 (15)', 'SR 153.34'),
          (Icons.sports_baseball, 'M Toshith Yadav 2.1-0-20-1', 'Eco 9.24'),
        ];
      case 'Points Table':
        return [
          (Icons.looks_one, 'CAMR', '12 pts'),
          (Icons.looks_two, 'VJS', '10 pts'),
          (Icons.trending_up, 'NRR and standings included', '+1.245'),
        ];
      case 'Squads':
        return [
          (Icons.groups, 'Playing XI', '11'),
          (Icons.person_add, 'Bench players', '7'),
          (Icons.sports_cricket, 'Captain / wicket keeper tags', 'Ready'),
        ];
      case 'Players':
        return [
          (Icons.person, 'Player profile', 'Stats'),
          (Icons.sports_cricket, 'Batting / Bowling records', 'Ready'),
          (Icons.timeline, 'Recent form and milestones', 'Ready'),
        ];
      case 'Teams':
        return [
          (Icons.groups, 'Team profile', 'Squad'),
          (Icons.calendar_month, 'Team schedule', 'Fixtures'),
          (Icons.history, 'Recent results', 'Form'),
        ];
      case 'Rankings':
        return [
          (Icons.leaderboard, 'Team ranking', 'India #1'),
          (Icons.person, 'Batter ranking', 'Top 10'),
          (Icons.sports_baseball, 'Bowler / all-rounder ranking', 'Top 10'),
        ];
      case 'Stats & Records':
        return [
          (Icons.bar_chart, 'Batting stats', 'Runs / SR'),
          (Icons.show_chart, 'Bowling stats', 'Wickets / Eco'),
          (Icons.star, 'Records and milestones', 'Ready'),
        ];
      case 'Match Insights':
        return [
          (Icons.percent, 'Win probability', 'VJS 76%'),
          (Icons.compare_arrows, 'Head to head', '12 matches'),
          (Icons.stadium, 'Venue performance', 'Good batting'),
        ];
      case 'Insights & Graphs':
        return [
          (Icons.show_chart, 'Run rate graph', 'Ready'),
          (Icons.timeline, 'Worm graph', 'Ready'),
          (Icons.handshake, 'Partnership graph', 'Ready'),
        ];
      case 'News':
        return [
          (Icons.newspaper, 'Latest cricket news', 'Updated'),
          (Icons.article, 'Match stories', 'Ready'),
          (Icons.notifications, 'News alerts', 'Ready'),
        ];
      case 'Voice Commentary':
        return [
          (Icons.volume_up, 'Hindi / English voice option', 'Ready'),
          (Icons.record_voice_over, 'Boundary and wicket voice', 'Ready'),
          (Icons.settings_voice, 'Voice settings', 'Ready'),
        ];
      default:
        return [
          (Icons.check_circle, '$title screen is connected', 'Working'),
          (Icons.storage, 'Sample data loaded', 'Ready'),
          (Icons.api, 'API/backend can be connected later', 'Next'),
        ];
    }
  }
}

class MatchDetailPage extends StatefulWidget {
  const MatchDetailPage({super.key});

  @override
  State<MatchDetailPage> createState() => _MatchDetailPageState();
}

class _MatchDetailPageState extends State<MatchDetailPage> {
  int tab = 1;
  final tabs = const ['Info', 'Live', 'Commentary', 'Scorecard', 'History', 'Points Table'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Row(children: [
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)),
                  Expanded(
                    child: LiveMatchBuilder(
                      builder: (context, data) {
                        final teamA = liveValue(data, 'teamA');
                        final teamB = liveValue(data, 'teamB');
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TeamLogo(code: teamCode(teamA), flag: teamFlag(teamA), color: teamColor(teamA), size: 34, showCode: false),
                            const SizedBox(width: 10),
                            Column(children: [
                              Text('$teamA vs $teamB', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                              Text('${liveValue(data, 'matchTitle')} • ${liveValue(data, 'status')}', style: const TextStyle(color: AppColor.muted)),
                            ]),
                            const SizedBox(width: 10),
                            TeamLogo(code: teamCode(teamB), flag: teamFlag(teamB), color: teamColor(teamB), size: 34, showCode: false),
                          ],
                        );
                      },
                    ),
                  ),
                  const Icon(Icons.star_border), const SizedBox(width: 8), const Icon(Icons.more_vert),
                ]),
              ),
              SizedBox(
                height: 46,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemBuilder: (context, i) => GestureDetector(
                    onTap: () => setState(() => tab = i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tab == i ? AppColor.cyan : Colors.transparent, width: 2))),
                      child: Text(tabs[i], style: TextStyle(color: tab == i ? AppColor.text : AppColor.muted, fontWeight: FontWeight.w800)),
                    ),
                  ),
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemCount: tabs.length,
                ),
              ),
              Expanded(child: _body()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _body() {
    if (tab == 0) return const InfoTab();
    if (tab == 1) return const LiveTab();
    if (tab == 2) return const CommentaryTab();
    if (tab == 3) return const ScorecardTab();
    if (tab == 4) return const HistoryTab();
    return const PointsTableTab();
  }
}

class InfoTab extends StatelessWidget {
  const InfoTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(14), children: const [
      MatchMiniHeader(),
      SizedBox(height: 12),
      DetailRow(label: 'Match', value: '25th Match'),
      DetailRow(label: 'Series', value: 'Andhra Premier League 2026'),
      DetailRow(label: 'Venue', value: 'Amaravathi, India'),
      DetailRow(label: 'Toss', value: 'VJS won the toss and elected to bat'),
      DetailRow(label: 'Umpires', value: 'Nitin Menon, Richard Illingworth'),
      SizedBox(height: 12),
      GlassCard(child: Row(children: [Icon(Icons.sunny, color: Colors.orange), SizedBox(width: 10), Text('Weather 28°C • Clear'), Spacer(), Text('Pitch: Good for batting', style: TextStyle(color: AppColor.cyan))])),
    ]);
  }
}

class DetailRow extends StatelessWidget {
  final String label, value;
  const DetailRow({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(padding: const EdgeInsets.all(12), child: Row(children: [SizedBox(width: 86, child: Text(label, style: const TextStyle(color: AppColor.muted))), Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w700)))])),
    );
  }
}


class MatchMiniHeader extends StatelessWidget {
  const MatchMiniHeader({super.key});
  @override
  Widget build(BuildContext context) {
    return LiveMatchBuilder(
      builder: (context, data) {
        final teamA = liveValue(data, 'teamA');
        final teamB = liveValue(data, 'teamB');
        return GlassCard(
          child: Row(
            children: [
              TeamLogo(code: teamCode(teamA), flag: teamFlag(teamA), color: teamColor(teamA), size: 46),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$teamA vs $teamB', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text('${liveValue(data, 'teamB')} ${liveValue(data, 'teamBScore')} (${liveValue(data, 'overs').replaceAll(' Over', '')}) • Live match profile', style: const TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
              const Icon(Icons.flash_on, color: AppColor.cyan),
              const SizedBox(width: 12),
              TeamLogo(code: teamCode(teamB), flag: teamFlag(teamB), color: teamColor(teamB), size: 46),
            ],
          ),
        );
      },
    );
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      children: const [
        TvLiveBox(),
        SizedBox(height: 10),
        BallStrip(),
        SizedBox(height: 10),
        QuickStatsRow(items: [('Run Rate', '8.9'), ('Balls Rem', '89')]),
        SizedBox(height: 10),
        WinProbability(),
        SizedBox(height: 10),
        BattingPanel(),
        SizedBox(height: 10),
        BowlingPanel(),
        SizedBox(height: 10),
        YetToBatPanel(),
        SizedBox(height: 10),
        ReviewPanel(),
        SizedBox(height: 10),
        GlassCard(child: Text('Settings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
      ],
    );
  }
}


class TvLiveBox extends StatelessWidget {
  const TvLiveBox({super.key});
  @override
  Widget build(BuildContext context) {
    return LiveMatchBuilder(
      builder: (context, data) {
        final teamA = liveValue(data, 'teamA');
        final teamB = liveValue(data, 'teamB');
        final battingTeam = liveValue(data, 'battingTeam');
        final bowlingTeam = liveValue(data, 'bowlingTeam');
        final battingScore = battingTeam == teamA ? liveValue(data, 'teamAScore') : liveValue(data, 'teamBScore');
        return Container(
          height: 220,
          decoration: BoxDecoration(color: Colors.black, border: Border.all(color: AppColor.line, width: 5)),
          child: Column(children: [
            Expanded(child: Stack(children: [
              const Positioned(left: 14, top: 14, child: Icon(Icons.volume_off, color: Colors.white)),
              const Positioned(right: 14, top: 14, child: Row(children: [CircleAvatar(radius: 4, backgroundColor: Colors.red), SizedBox(width: 4), Text('Live')])),
              Center(child: Text(liveValue(data, 'currentRun'), style: const TextStyle(fontSize: 33, fontWeight: FontWeight.w900))),
              Positioned(left: 14, bottom: 12, child: TeamLogo(code: teamCode(teamA), flag: teamFlag(teamA), color: teamColor(teamA), size: 40)),
              Positioned(right: 14, bottom: 12, child: TeamLogo(code: teamCode(teamB), flag: teamFlag(teamB), color: teamColor(teamB), size: 40)),
            ])),
            Container(
              height: 58,
              color: AppColor.card2,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: [
                TeamLogo(code: teamCode(battingTeam), flag: teamFlag(battingTeam), color: teamColor(battingTeam), size: 34, showCode: false),
                const SizedBox(width: 8),
                Text('$battingTeam $battingScore (${liveValue(data, 'overs').replaceAll(' Over', '')})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(width: 8),
                const Pill('P', selected: true, color: Color(0xFF606C38)),
                const Spacer(),
                Text(bowlingTeam, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)),
                const SizedBox(width: 8),
                TeamLogo(code: teamCode(bowlingTeam), flag: teamFlag(bowlingTeam), color: teamColor(bowlingTeam), size: 34, showCode: false),
              ]),
            ),
          ]),
        );
      },
    );
  }
}

class BallStrip extends StatelessWidget {
  const BallStrip({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
      child: Row(children: [
        const Ball('1', color: AppColor.green), const Ball('1', color: AppColor.green), const Ball('4', color: AppColor.blue), const Text(' = 9', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(width: 14), Container(height: 28, width: 1, color: AppColor.line), const SizedBox(width: 14), const Text('Over 6', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(width: 8), const Ball('1', color: AppColor.green), const Ball('', outlined: true), const Ball('', outlined: true), const Ball('', outlined: true), const Ball('', outlined: true), const Text(' = 1', style: TextStyle(fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class Ball extends StatelessWidget {
  final String text;
  final Color? color;
  final bool outlined;
  const Ball(this.text, {super.key, this.color, this.outlined = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 31,
      height: 31,
      margin: const EdgeInsets.only(right: 6),
      decoration: BoxDecoration(shape: BoxShape.circle, color: outlined ? Colors.transparent : (color ?? AppColor.card2), border: Border.all(color: outlined ? AppColor.muted : Colors.transparent, width: 0.8)),
      child: Center(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900))),
    );
  }
}

class QuickStatsRow extends StatelessWidget {
  final List<(String, String)> items;
  const QuickStatsRow({super.key, required this.items});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Row(children: [for (final item in items) Expanded(child: Text('${item.$1}: ${item.$2}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700), textAlign: item == items.last ? TextAlign.right : TextAlign.left))]));
  }
}

class WinProbability extends StatelessWidget {
  const WinProbability({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Row(children: const [Text('Win Probability  ⓘ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)), Spacer(), Text('VJS:'), SizedBox(width: 10), Pill('75', selected: true, color: AppColor.red), SizedBox(width: 6), Pill('76', selected: true, color: AppColor.green)]));
  }
}

class BattingPanel extends StatelessWidget {
  const BattingPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(children: const [
      TableHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']),
      ScoreRow(cols: ['Ashwin Hebbar 🏏', '16', '9', '1', '1', '177.78']),
      ScoreRow(cols: ['Harshavardhan Maddi...', '23', '15', '2', '1', '153.34']),
      Divider(color: AppColor.line),
      Row(children: [Text("P'ship: 39(22)", style: TextStyle(color: AppColor.muted)), Spacer(), Text("L' Wkt: M. Abhinav 5(7)", style: TextStyle(color: AppColor.muted))]),
    ]));
  }
}

class BowlingPanel extends StatelessWidget {
  const BowlingPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(children: const [
      TableHeader(cols: ['Bowler', 'O', 'R', 'Wkt', 'Eco']),
      ScoreRow(cols: ['M Toshith Yadav 🏏', '2.1', '20', '1', '9.24']),
    ]));
  }
}

class YetToBatPanel extends StatelessWidget {
  const YetToBatPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('Yet to bat', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)), Divider(color: AppColor.line),
      Text('S Zaheer Abbas, Harsha Vardhan Myla, Penmetsa Panduranga Raju, B Pranav Reddy, Db Prasanth Kumar, Ch Siddhardha, Lalith Mohan, Gollapudi Sai Venkata Sumith', style: TextStyle(height: 1.35, fontWeight: FontWeight.w700)),
    ]));
  }
}

class ReviewPanel extends StatelessWidget {
  const ReviewPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(children: const [
      Row(children: [Text('Team Review - UDRS ⓘ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)), Spacer(), Text('Left'), SizedBox(width: 32), Icon(Icons.check, color: AppColor.green), SizedBox(width: 32), Icon(Icons.close, color: AppColor.red)]),
      Divider(color: AppColor.line),
      Row(children: [Expanded(child: Text('CAMR')), Text('2        0        0')]), SizedBox(height: 8), Row(children: [Expanded(child: Text('VJS')), Text('2        0        0')]),
    ]));
  }
}

class TableHeader extends StatelessWidget {
  final List<String> cols;
  const TableHeader({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [for (int i = 0; i < cols.length; i++) Expanded(flex: i == 0 ? 5 : 1, child: Text(cols[i], textAlign: i == 0 ? TextAlign.left : TextAlign.right, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)))]),
    );
  }
}

class ScoreRow extends StatelessWidget {
  final List<String> cols;
  const ScoreRow({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(children: [for (int i = 0; i < cols.length; i++) Expanded(flex: i == 0 ? 5 : 1, child: Text(cols[i], textAlign: i == 0 ? TextAlign.left : TextAlign.right, style: TextStyle(fontWeight: i == 0 ? FontWeight.w800 : FontWeight.w600)))]),
    );
  }
}

class CommentaryTab extends StatelessWidget {
  const CommentaryTab({super.key});
  @override
  Widget build(BuildContext context) {
    final data = ['5.1  FOUR! Beautifully timed by Harshavardhan Maddi.', '5.0  Full toss on middle, tucked away to mid-wicket.', '4.6  Pushed to long on for a single.', '4.5  Good length ball, defended solidly.', '4.4  Short and wide, cut away to point.', '4.3  FOUR! Crunched through point.'];
    return ListView(padding: const EdgeInsets.all(14), children: [
      const Row(children: [Pill('All', selected: true), SizedBox(width: 8), Pill('This Over'), SizedBox(width: 8), Pill('CAMR'), SizedBox(width: 8), Pill('VJS')]),
      const SizedBox(height: 12),
      for (final item in data) Padding(padding: const EdgeInsets.only(bottom: 8), child: GlassCard(padding: const EdgeInsets.all(12), child: Text(item, style: const TextStyle(fontWeight: FontWeight.w700)))),
    ]);
  }
}

class ScorecardTab extends StatelessWidget {
  const ScorecardTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(14), children: const [
      Row(children: [Expanded(child: Pill('CAMR')), SizedBox(width: 8), Expanded(child: Pill('VJS', selected: true))]),
      SizedBox(height: 12),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Text('VJS Innings', style: TextStyle(fontWeight: FontWeight.w900, color: AppColor.cyan)), Spacer(), Text('46-1 (5.1 Overs)', style: TextStyle(fontWeight: FontWeight.w900))]),
        Divider(color: AppColor.line), TableHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']), ScoreRow(cols: ['Ashwin Hebbar 🏏', '16', '9', '1', '1', '177.78']), ScoreRow(cols: ['Harshavardhan Maddi...', '23', '15', '2', '1', '153.34']), ScoreRow(cols: ['M. Abhinav (wk)', '5', '7', '0', '0', '71.43']), Divider(color: AppColor.line), Text('Extras    2 (b 1, wd 1)'), SizedBox(height: 4), Text('Total     46-1 (5.1 Overs)', style: TextStyle(fontWeight: FontWeight.w900)),
      ])),
      SizedBox(height: 10),
      BowlingPanel(),
      SizedBox(height: 10),
      GlassCard(child: Text('Fall of Wickets\n1-7 (M. Abhinav, 1.2 Ov)', style: TextStyle(height: 1.5))),
    ]);
  }
}


class BallHistory {
  final String ball;
  final String run;
  final String score;
  final String time;
  final Color color;
  final String team;
  final String teamLow;
  final String teamHigh;
  final String overLow;
  final String overHigh;

  const BallHistory({
    required this.ball,
    required this.run,
    required this.score,
    required this.time,
    required this.color,
    required this.team,
    required this.teamLow,
    required this.teamHigh,
    required this.overLow,
    required this.overHigh,
  });
}

class OverHistory {
  final String title;
  final String runs;
  final String teamScore;
  final String overLabel;
  final List<BallHistory> balls;

  const OverHistory({
    required this.title,
    required this.runs,
    required this.teamScore,
    required this.overLabel,
    required this.balls,
  });
}

class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key});

  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  int innings = 2;

  static const List<OverHistory> firstInnings = [
    OverHistory(
      title: '1st Over',
      runs: '6 runs',
      teamScore: 'CAMR: 6-0',
      overLabel: '6 Over',
      balls: [
        BallHistory(ball: '0.6', run: '1', score: '6 - 0', time: '07:16 PM', color: AppColor.green, team: 'CAMR', teamLow: '09', teamHigh: '10', overLow: '62', overHigh: '63'),
        BallHistory(ball: '0.5', run: '0', score: '5 - 0', time: '07:15 PM', color: Color(0xFFEDEFF2), team: 'CAMR', teamLow: '10', teamHigh: '11', overLow: '61', overHigh: '62'),
        BallHistory(ball: '0.4', run: '4', score: '5 - 0', time: '07:14 PM', color: AppColor.blue, team: 'CAMR', teamLow: '08', teamHigh: '09', overLow: '60', overHigh: '61'),
        BallHistory(ball: '0.3', run: '1', score: '1 - 0', time: '07:13 PM', color: AppColor.green, team: 'CAMR', teamLow: '12', teamHigh: '13', overLow: '58', overHigh: '59'),
        BallHistory(ball: '0.2', run: '0', score: '0 - 0', time: '07:12 PM', color: Color(0xFFEDEFF2), team: 'CAMR', teamLow: '13', teamHigh: '14', overLow: '57', overHigh: '58'),
        BallHistory(ball: '0.1', run: '0', score: '0 - 0', time: '07:12 PM', color: Color(0xFFEDEFF2), team: 'CAMR', teamLow: '14', teamHigh: '15', overLow: '56', overHigh: '57'),
      ],
    ),
    OverHistory(
      title: '2nd Over',
      runs: '8 runs',
      teamScore: 'CAMR: 14-0',
      overLabel: '6 Over',
      balls: [
        BallHistory(ball: '1.6', run: '2', score: '14 - 0', time: '07:22 PM', color: AppColor.orange, team: 'CAMR', teamLow: '07', teamHigh: '08', overLow: '68', overHigh: '69'),
        BallHistory(ball: '1.5', run: '4', score: '12 - 0', time: '07:21 PM', color: AppColor.blue, team: 'CAMR', teamLow: '08', teamHigh: '09', overLow: '66', overHigh: '67'),
        BallHistory(ball: '1.4', run: '0', score: '8 - 0', time: '07:20 PM', color: Color(0xFFEDEFF2), team: 'CAMR', teamLow: '09', teamHigh: '10', overLow: '65', overHigh: '66'),
        BallHistory(ball: '1.3', run: '1', score: '8 - 0', time: '07:19 PM', color: AppColor.green, team: 'CAMR', teamLow: '10', teamHigh: '11', overLow: '64', overHigh: '65'),
      ],
    ),
  ];

  static const List<OverHistory> secondInnings = [
    OverHistory(
      title: '1st Over',
      runs: '16 runs',
      teamScore: 'VJS: 16-0',
      overLabel: '6 Over',
      balls: [
        BallHistory(ball: '0.6', run: '4', score: '16 - 0', time: '07:56 PM', color: AppColor.blue, team: 'VJS', teamLow: '06', teamHigh: '07', overLow: '77', overHigh: '78'),
        BallHistory(ball: '0.5', run: '6', score: '12 - 0', time: '07:55 PM', color: AppColor.purple, team: 'VJS', teamLow: '06', teamHigh: '07', overLow: '69', overHigh: '70'),
        BallHistory(ball: '0.4', run: '1', score: '6 - 0', time: '07:54 PM', color: AppColor.green, team: 'VJS', teamLow: '08', teamHigh: '09', overLow: '69', overHigh: '70'),
        BallHistory(ball: '0.3', run: '4', score: '5 - 0', time: '07:54 PM', color: AppColor.blue, team: 'VJS', teamLow: '09', teamHigh: '10', overLow: '69', overHigh: '70'),
        BallHistory(ball: '0.2', run: '0', score: '1 - 0', time: '07:53 PM', color: Color(0xFFEDEFF2), team: 'VJS', teamLow: '10', teamHigh: '11', overLow: '67', overHigh: '68'),
        BallHistory(ball: '0.1', run: '1', score: '1 - 0', time: '07:52 PM', color: AppColor.green, team: 'VJS', teamLow: '12', teamHigh: '13', overLow: '69', overHigh: '70'),
      ],
    ),
    OverHistory(
      title: '2nd Over',
      runs: '9 runs',
      teamScore: 'VJS: 25-0',
      overLabel: '6 Over',
      balls: [
        BallHistory(ball: '1.6', run: '1', score: '25 - 0', time: '08:03 PM', color: AppColor.green, team: 'VJS', teamLow: '05', teamHigh: '06', overLow: '81', overHigh: '82'),
        BallHistory(ball: '1.5', run: '4', score: '24 - 0', time: '08:02 PM', color: AppColor.blue, team: 'VJS', teamLow: '06', teamHigh: '07', overLow: '79', overHigh: '80'),
        BallHistory(ball: '1.4', run: '1', score: '20 - 0', time: '08:01 PM', color: AppColor.green, team: 'VJS', teamLow: '07', teamHigh: '08', overLow: '77', overHigh: '78'),
        BallHistory(ball: '1.3', run: '2', score: '19 - 0', time: '08:00 PM', color: AppColor.orange, team: 'VJS', teamLow: '08', teamHigh: '09', overLow: '74', overHigh: '75'),
      ],
    ),
    OverHistory(
      title: '3rd Over',
      runs: '11 runs',
      teamScore: 'VJS: 36-0',
      overLabel: '6 Over',
      balls: [
        BallHistory(ball: '2.6', run: '6', score: '36 - 0', time: '08:10 PM', color: AppColor.purple, team: 'VJS', teamLow: '04', teamHigh: '05', overLow: '88', overHigh: '89'),
        BallHistory(ball: '2.5', run: '1', score: '30 - 0', time: '08:09 PM', color: AppColor.green, team: 'VJS', teamLow: '05', teamHigh: '06', overLow: '84', overHigh: '85'),
        BallHistory(ball: '2.4', run: '4', score: '29 - 0', time: '08:08 PM', color: AppColor.blue, team: 'VJS', teamLow: '06', teamHigh: '07', overLow: '82', overHigh: '83'),
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final overs = innings == 1 ? firstInnings : secondInnings;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const MatchMiniHeader(),
        const SizedBox(height: 12),
        _InningsSelector(
          selected: innings,
          onChanged: (value) => setState(() => innings = value),
        ),
        const SizedBox(height: 12),
        for (final over in overs) Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: OverHistoryCard(over: over),
        ),
      ],
    );
  }
}

class _InningsSelector extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onChanged;
  const _InningsSelector({required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: _InningsButton(text: '1st Innings', isSelected: selected == 1, onTap: () => onChanged(1))),
      const SizedBox(width: 10),
      Expanded(child: _InningsButton(text: '2nd Innings', isSelected: selected == 2, onTap: () => onChanged(2))),
    ]);
  }
}

class _InningsButton extends StatelessWidget {
  final String text;
  final bool isSelected;
  final VoidCallback onTap;
  const _InningsButton({required this.text, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF5B6670) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: isSelected ? const Color(0xFF5B6670) : AppColor.line),
        ),
        child: Center(
          child: Text(text, style: TextStyle(fontWeight: FontWeight.w900, color: isSelected ? AppColor.text : AppColor.muted, fontSize: 16)),
        ),
      ),
    );
  }
}

class OverHistoryCard extends StatelessWidget {
  final OverHistory over;
  const OverHistoryCard({super.key, required this.over});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(0),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            child: Row(children: [
              Text(over.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              Text(' : ${over.runs}', style: const TextStyle(fontSize: 17, color: AppColor.muted, fontWeight: FontWeight.w800)),
              const Spacer(),
              Text(over.teamScore, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(width: 8),
              const Icon(Icons.keyboard_arrow_up, color: AppColor.text),
            ]),
          ),
          const Divider(height: 1, color: AppColor.line),
          for (int i = 0; i < over.balls.length; i++) ...[
            HistoryBallTile(ball: over.balls[i], overLabel: over.overLabel),
            if (i != over.balls.length - 1) const Divider(height: 1, color: Color(0xFF101820)),
          ],
        ],
      ),
    );
  }
}

class HistoryBallTile extends StatelessWidget {
  final BallHistory ball;
  final String overLabel;
  const HistoryBallTile({super.key, required this.ball, required this.overLabel});

  @override
  Widget build(BuildContext context) {
    final textColor = ball.run == '0' ? const Color(0xFF111820) : Colors.white;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(shape: BoxShape.circle, color: ball.color),
              child: Center(child: Text(ball.run, style: TextStyle(color: textColor, fontWeight: FontWeight.w900, fontSize: 16))),
            ),
            const SizedBox(height: 8),
            Text(ball.time, style: const TextStyle(color: AppColor.muted, fontSize: 12)),
          ]),
          const SizedBox(width: 16),
          Expanded(
            child: Row(children: [
              Text(ball.score, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(width: 5),
              Text(ball.ball, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)),
            ]),
          ),
          OddsBox(ball: ball, overLabel: overLabel),
        ],
      ),
    );
  }
}

class OddsBox extends StatelessWidget {
  final BallHistory ball;
  final String overLabel;
  const OddsBox({super.key, required this.ball, required this.overLabel});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 178,
      child: Column(children: [
        Row(children: [
          _OddCell(text: ball.team, color: const Color(0xFFE9EDF3), textColor: const Color(0xFF222A32), flex: 2),
          const SizedBox(width: 8),
          _OddCell(text: ball.teamLow, color: AppColor.red),
          const SizedBox(width: 8),
          _OddCell(text: ball.teamHigh, color: AppColor.green),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          _OddCell(text: overLabel, color: Colors.transparent, border: true, flex: 2),
          const SizedBox(width: 8),
          _OddCell(text: ball.overLow, color: AppColor.red),
          const SizedBox(width: 8),
          _OddCell(text: ball.overHigh, color: AppColor.green),
        ]),
      ]),
    );
  }
}

class _OddCell extends StatelessWidget {
  final String text;
  final Color color;
  final Color textColor;
  final bool border;
  final int flex;
  const _OddCell({required this.text, required this.color, this.textColor = Colors.white, this.border = false, this.flex = 1});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(6),
          border: border ? Border.all(color: AppColor.line) : null,
        ),
        child: Center(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: textColor, fontSize: 14, fontWeight: FontWeight.w900))),
      ),
    );
  }
}

class DetailLine extends StatelessWidget {
  final String a, b, c;
  const DetailLine(this.a, this.b, this.c, {super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [SizedBox(width: 86, child: Text(a, style: const TextStyle(color: AppColor.muted))), Expanded(child: Text(b)), Pill(c, selected: true, color: c == 'W' ? AppColor.green : AppColor.red)]));
  }
}

class PointsTableTab extends StatelessWidget {
  const PointsTableTab({super.key});
  @override
  Widget build(BuildContext context) {
    final rows = [
      ['1', 'Seattle Orcas', '4', '3', '1', '+1.223', '6'], ['2', 'Texas Titans', '4', '3', '1', '+0.857', '6'], ['3', 'New York Strikers', '4', '2', '2', '+0.216', '4'], ['4', 'Freedom', '4', '2', '2', '-0.132', '4'], ['5', 'LA Knights', '4', '1', '3', '-0.645', '2']
    ];
    return ListView(padding: const EdgeInsets.all(14), children: [
      const Row(children: [Expanded(child: Pill('League Table', selected: true)), SizedBox(width: 8), Expanded(child: Pill('Team Form'))]),
      const SizedBox(height: 12),
      GlassCard(child: Column(children: [
        const TableHeader(cols: ['Team', 'P', 'W', 'L', 'NRR', 'Pts']),
        for (final r in rows) ScoreRow(cols: ['${r[0]}  ${r[1]}', r[2], r[3], r[4], r[5], r[6]]),
        const Divider(color: AppColor.line), const Text('Top 4 teams qualify for the Playoffs.', style: TextStyle(color: AppColor.cyan)),
      ])),
    ]);
  }
}
