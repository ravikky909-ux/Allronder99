package com.example.allrounder99

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "allrounder99/notifications"
    private val notificationChannelId = "allrounder99_live_score"
    private val requestCode = 9901

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        createNotificationChannel()
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "requestPermission" -> result.success(requestNotificationPermission())
                "showNotification" -> {
                    val title = call.argument<String>("title") ?: "Allrounder99"
                    val body = call.argument<String>("body") ?: "Live score update"
                    result.success(showNotification(title, body))
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun requestNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCode)
            return false
        }
        return true
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(notificationChannelId, "Allrounder99 Live Score", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Live score alerts and cricket updates"
            manager.createNotificationChannel(channel)
        }
    }

    private fun notificationsAllowed(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    private fun showNotification(title: String, body: String): Boolean {
        if (!notificationsAllowed()) {
            requestNotificationPermission()
            return false
        }
        return try {
            createNotificationChannel()
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, notificationChannelId) else @Suppress("DEPRECATION") Notification.Builder(this)
            val notification = builder
                .setSmallIcon(applicationInfo.icon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setShowWhen(true)
                .build()
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(System.currentTimeMillis().toInt(), notification)
            true
        } catch (e: Exception) {
            false
        }
    }
}
