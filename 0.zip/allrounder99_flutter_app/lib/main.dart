import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';


const MethodChannel allrounderNotificationChannel = MethodChannel('allrounder99/notifications');

const String kSportmonksApiToken = 'T1u48aL0cEvdDSF08pUNM0slwarNYKP4Kz3UWejZP55eHi90IGO8bxqjVeuw'; // Built-in Sportmonks API token
const String kSportmonksBaseUrl = 'https://cricket.sportmonks.com/api/v2.0';

final ValueNotifier<int?> selectedFixtureIdNotifier = ValueNotifier<int?>(null);



Future<bool> requestAllrounderNotificationPermission() async {
  try {
    final result = await allrounderNotificationChannel.invokeMethod<bool>('requestPermission');
    return result == true;
  } catch (_) {
    return false;
  }
}

Future<bool> showAllrounderNotification(String title, String body) async {
  try {
    final result = await allrounderNotificationChannel.invokeMethod<bool>('showNotification', {
      'title': title,
      'body': body,
    });
    return result == true;
  } catch (_) {
    return false;
  }
}

void main() {
  runApp(const Allrounder99App());
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Allrounder99',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColor.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.cyan, brightness: Brightness.dark),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaler: const TextScaler.linear(0.88)),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const MainShell(),
    );
  }
}

class AppColor {
  static const bg = Color(0xFF11191F);
  static const bg2 = Color(0xFF1F272D);
  static const card = Color(0xFF2E3841);
  static const card2 = Color(0xFF26313A);
  static const line = Color(0xFF172129);
  static const header = Color(0xFF5B6670);
  static const text = Color(0xFFF3F3F6);
  static const muted = Color(0xFFB5BCC4);
  static const cyan = Color(0xFF08C7FF);
  static const green = Color(0xFF159E69);
  static const red = Color(0xFFE94B55);
  static const blue = Color(0xFF2F9EE8);
  static const purple = Color(0xFF7252D5);
  static const yellow = Color(0xFFFFC247);
}


int _liveStatusPriority(String status) {
  final s = status.toLowerCase();
  if (s.contains('stump') || s.contains('close') || s.contains('ended')) return 8;
  if (s.contains('innings break') || s.contains('lunch') || s.contains('tea') || s.contains('rain') || s.contains('delay')) return 5;
  if (s.contains('innings') || s.contains('session') || s == 'live') return 0;
  return 2;
}

String _fixtureCombinedStatus(Map<String, dynamic> item) {
  final status = (item['status'] ?? '').toString();
  final note = (item['note'] ?? '').toString();
  return '$status $note'.trim();
}

String _friendlyMatchState(Map<String, dynamic> item) {
  final combined = _fixtureCombinedStatus(item);
  final s = combined.toLowerCase();
  if (combined.isEmpty) return 'Live';
  if (s.contains('rain')) return 'Rain stop play';
  if (s.contains('stump')) return combined;
  if (s.contains('innings break')) return 'Innings Break';
  if (s.contains('lunch')) return 'Lunch Break';
  if (s.contains('tea')) return 'Tea Break';
  if (s.contains('delay') || s.contains('delayed')) return 'Play delayed';
  if (s.contains('suspend') || s.contains('interrupt')) return 'Play stopped';
  if (s.contains('abandon')) return 'Match abandoned';
  if (s.contains('no result')) return 'No result';
  return combined;
}

bool _isPlayStoppedOrBreak(String status) {
  final s = status.toLowerCase();
  return s.contains('rain') ||
      s.contains('stump') ||
      s.contains('break') ||
      s.contains('lunch') ||
      s.contains('tea') ||
      s.contains('delay') ||
      s.contains('delayed') ||
      s.contains('stopped') ||
      s.contains('suspend') ||
      s.contains('interrupt') ||
      s.contains('abandon') ||
      s.contains('no result');
}

bool _isActuallyPlayingLive(Map<String, dynamic> item) {
  // Keep every Sportmonks live:true fixture visible, including rain, stumps,
  // innings break, lunch/tea and play stopped. Sorting keeps active play first.
  return item['live'] == true || item['live']?.toString().toLowerCase() == 'true';
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const HomePage(),
      const FixturesPage(),
      const SeriesPage(),
      const MorePage(),
    ];

    return Scaffold(
      body: pages[selected],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        height: 68,
        backgroundColor: AppColor.bg2,
        indicatorColor: AppColor.cyan.withOpacity(0.14),
        onDestinationSelected: (value) => setState(() => selected = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: AppColor.cyan), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month, color: AppColor.cyan), label: 'Fixtures'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events, color: AppColor.cyan), label: 'Series'),
          NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz, color: AppColor.cyan), label: 'More'),
        ],
      ),
    );
  }
}

class GradientPage extends StatelessWidget {
  final Widget child;
  const GradientPage({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.bg,
      child: SafeArea(child: child),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;
  final double radius;
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.color,
    this.radius = 9,
  });

  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? AppColor.card,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: AppColor.line.withOpacity(0.4)),
      ),
      child: child,
    );
    if (onTap == null) return card;
    return InkWell(onTap: onTap, borderRadius: BorderRadius.circular(radius), child: card);
  }
}


Widget welcomeCardMore() {
  return GlassCard(
    padding: const EdgeInsets.all(14),
    child: Row(
      children: [
        ClipOval(
          child: Image.asset(
            'assets/logo.png',
            width: 64,
            height: 64,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.sports_cricket, color: AppColor.cyan, size: 54),
          ),
        ),
        const SizedBox(width: 14),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Welcome to Allrounder99', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              SizedBox(height: 6),
              Text(
                'Scoring app for live cricket scores, scorecards and match history.',
                style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700, height: 1.3),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Timer? _timer;
  bool loading = true;
  String status = 'Loading live matches...';
  List<HomeLiveMatch> matches = const [];
  int homeTab = 0;

  @override
  void initState() {
    super.initState();
    _loadHomeLiveMatches();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) => _loadHomeLiveMatches(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadHomeLiveMatches({bool silent = false}) async {
    try {
      final token = kSportmonksApiToken.trim();
      if (!silent && mounted) setState(() => loading = true);
      final url = Uri.parse('$kSportmonksBaseUrl/livescores?api_token=${Uri.encodeComponent(token)}&include=localteam,visitorteam,runs');
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      if (res.statusCode == 401) throw Exception('Token invalid');
      if (res.statusCode != 200) throw Exception('API ${res.statusCode}');
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final list = (json['data'] as List?) ?? const [];
      final loaded = <HomeLiveMatch>[];
      for (final item in list) {
        if (item is Map) {
          final data = Map<String, dynamic>.from(item);
          if (!_isActuallyPlayingLive(data)) continue;
          final match = HomeLiveMatch.fromJson(data);
          if (match != null) loaded.add(match);
        }
      }
      loaded.sort((a, b) {
        final p = _liveStatusPriority(a.status).compareTo(_liveStatusPriority(b.status));
        if (p != 0) return p;
        return a.title.compareTo(b.title);
      });
      if (!mounted) return;
      setState(() {
        loading = false;
        matches = loaded;
        status = loaded.isEmpty ? 'No live matches right now' : 'Live matches updated • ${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        status = 'API error: ${e.toString().replaceAll('Exception: ', '')}';
      });
    }
  }

  void _openLiveMatch(HomeLiveMatch match) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MatchDetailPage(initialTab: 1, initialFixtureId: match.id)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final featured = matches.isNotEmpty ? matches.first : null;
    return GradientPage(
      child: RefreshIndicator(
        onRefresh: () => _loadHomeLiveMatches(),
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Row(
              children: [
                ClipOval(child: Image.asset('assets/logo.png', width: 54, height: 54, fit: BoxFit.cover)),
                const SizedBox(width: 12),
                const Expanded(child: Text('ALLROUNDER99', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
                IconButton(onPressed: () => _loadHomeLiveMatches(), icon: const Icon(Icons.refresh, color: AppColor.text)),
                const Icon(Icons.notifications_none, color: AppColor.text),
              ],
            ),
            const SizedBox(height: 16),
            Row(children: [
              GestureDetector(onTap: () => setState(() => homeTab = 0), child: Pill('Featured', selected: homeTab == 0)),
              const SizedBox(width: 8),
              GestureDetector(onTap: () => setState(() => homeTab = 1), child: Pill('Live', selected: homeTab == 1)),
              const SizedBox(width: 8),
              GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FixturesPage())), child: const Pill('All Matches')),
            ]),
            const SizedBox(height: 14),
            if (homeTab == 0 && featured != null)
              HomeFeaturedLiveCard(match: featured, onTap: () => _openLiveMatch(featured))
            else if (homeTab == 0)
              GlassCard(
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(loading ? 'Loading live matches...' : 'No live match at the moment', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text(status, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailPage(initialTab: 1))), icon: const Icon(Icons.sports_cricket), label: const Text('Open Live')),
                ]),
              ),
            if (homeTab == 0) ...[
              const SizedBox(height: 14),
              const AdminPostsPreview(),
              const SizedBox(height: 14),
            ] else const SizedBox(height: 14),
            Row(children: [
              const Expanded(child: SectionTitle('Live Matches')),
              Text(status, style: const TextStyle(color: AppColor.muted, fontSize: 11, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 8),
            if (matches.isEmpty && !loading)
              const GlassCard(child: Text('Live match milte hi yahan show hoga. Rain/stumps/break status bhi TV box me dikhega.', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)))
            else
              for (final match in matches)
                HomeLiveListTile(match: match, onTap: () => _openLiveMatch(match)),
          ],
        ),
      ),
    );
  }
}

class HomeLiveMatch {
  final int id;
  final String title;
  final String subtitle;
  final String status;
  final String score;
  final String localCode;
  final String visitCode;
  final String? localImage;
  final String? visitImage;
  final bool isBreak;

  const HomeLiveMatch({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.score,
    required this.localCode,
    required this.visitCode,
    required this.localImage,
    required this.visitImage,
    required this.isBreak,
  });

  static HomeLiveMatch? fromJson(Map<String, dynamic> item) {
    final rawId = item['id'];
    final id = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '');
    if (id == null) return null;
    final local = Map<String, dynamic>.from((item['localteam'] as Map?) ?? const {});
    final visit = Map<String, dynamic>.from((item['visitorteam'] as Map?) ?? const {});
    final runs = ((item['runs'] as List?) ?? const []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    final localName = (local['name'] ?? 'Team ${item['localteam_id'] ?? ''}').toString();
    final visitName = (visit['name'] ?? 'Team ${item['visitorteam_id'] ?? ''}').toString();
    final localCode = (local['code'] ?? _shortCodeStatic(localName)).toString();
    final visitCode = (visit['code'] ?? _shortCodeStatic(visitName)).toString();
    String score = (item['status'] ?? 'Live').toString();
    if (runs.isNotEmpty) {
      final run = runs.last;
      final battingTeamId = run['team_id'];
      final battingCode = battingTeamId == local['id'] ? localCode : (battingTeamId == visit['id'] ? visitCode : 'BAT');
      score = '$battingCode ${_asIntStatic(run['score'])}-${_asIntStatic(run['wickets'])} (${_formatOversStatic(run['overs'])})';
    }
    final status = (item['status'] ?? 'Live').toString();
    return HomeLiveMatch(
      id: id,
      title: '$localCode vs $visitCode',
      subtitle: (item['round'] ?? item['type'] ?? 'Live match').toString(),
      status: status,
      score: score,
      localCode: localCode,
      visitCode: visitCode,
      localImage: local['image_path']?.toString(),
      visitImage: visit['image_path']?.toString(),
      isBreak: _liveStatusPriority(status) >= 5,
    );
  }
}

String _shortCodeStatic(String name) {
  final parts = name.trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
  if (parts.isEmpty) return 'TM';
  if (parts.length == 1) return parts.first.substring(0, parts.first.length < 3 ? parts.first.length : 3).toUpperCase();
  return parts.map((e) => e[0]).join().toUpperCase();
}

int _asIntStatic(dynamic v) {
  if (v is int) return v;
  if (v is num) return v.round();
  return int.tryParse(v?.toString() ?? '') ?? 0;
}

String _formatOversStatic(dynamic overs) {
  if (overs == null) return '--';
  final s = overs.toString();
  return s.contains('.') ? s : '$s.0';
}

class HomeFeaturedLiveCard extends StatelessWidget {
  final HomeLiveMatch match;
  final VoidCallback onTap;
  const HomeFeaturedLiveCard({super.key, required this.match, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      onTap: onTap,
      padding: EdgeInsets.zero,
      radius: 12,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(13),
          child: Row(children: [
            const Pill('LIVE', selected: true, color: AppColor.red),
            const SizedBox(width: 8),
            Expanded(child: Text(match.subtitle, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis)),
            const Icon(Icons.chevron_right, color: AppColor.muted),
          ]),
        ),
        const Divider(height: 1, color: AppColor.line),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            _NetTeamLogo(code: match.localCode, image: match.localImage),
            const SizedBox(width: 10),
            Expanded(child: Text(match.score, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.4))),
            const Icon(Icons.flash_on, color: AppColor.text, size: 30),
            Expanded(child: Text(match.status, textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, height: 1.4, color: match.isBreak ? AppColor.yellow : AppColor.text))),
            const SizedBox(width: 10),
            _NetTeamLogo(code: match.visitCode, image: match.visitImage),
          ]),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: const BoxDecoration(color: AppColor.bg2, borderRadius: BorderRadius.vertical(bottom: Radius.circular(12))),
          child: Center(child: Text(match.isBreak ? '${match.status} • Tap another active match' : '${match.score} • Tap for live ball-by-ball', style: const TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900))),
        ),
      ]),
    );
  }
}

class HomeLiveListTile extends StatelessWidget {
  final HomeLiveMatch match;
  final VoidCallback onTap;
  const HomeLiveListTile({super.key, required this.match, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        onTap: onTap,
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          _NetTeamLogo(code: match.localCode, image: match.localImage),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(match.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 5),
            Text(match.score, style: const TextStyle(color: AppColor.green, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text('${match.status} • ${match.subtitle}', style: const TextStyle(color: AppColor.muted, fontSize: 12.5), maxLines: 1, overflow: TextOverflow.ellipsis),
          ])),
          const Icon(Icons.chevron_right, color: AppColor.muted),
        ]),
      ),
    );
  }
}


Future<List<HomeLiveMatch>> _fetchLiveHomeMatches() async {
  final url = Uri.parse('$kSportmonksBaseUrl/livescores?api_token=${Uri.encodeComponent(kSportmonksApiToken.trim())}&include=localteam,visitorteam,runs');
  final res = await http.get(url).timeout(const Duration(seconds: 10));
  if (res.statusCode == 401) throw Exception('token invalid');
  if (res.statusCode != 200) throw Exception('Livescores ${res.statusCode}');
  final json = jsonDecode(res.body) as Map<String, dynamic>;
  final list = (json['data'] as List?) ?? const [];
  final loaded = <HomeLiveMatch>[];
  for (final item in list) {
    if (item is Map) {
      final data = Map<String, dynamic>.from(item);
      if (!_isActuallyPlayingLive(data)) continue;
      final match = HomeLiveMatch.fromJson(data);
      if (match != null) loaded.add(match);
    }
  }
  loaded.sort((a, b) {
    final p = _liveStatusPriority(a.status).compareTo(_liveStatusPriority(b.status));
    if (p != 0) return p;
    return a.title.compareTo(b.title);
  });
  return loaded;
}

DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

Future<List<UpcomingMatch>> _fetchUpcomingMatches() async {
  final now = DateTime.now().toUtc();
  final from = _dateOnly(now).toIso8601String().substring(0, 10);
  final to = _dateOnly(now.add(const Duration(days: 10))).toIso8601String().substring(0, 10);
  final urls = <Uri>[
    Uri.parse('$kSportmonksBaseUrl/fixtures?api_token=${Uri.encodeComponent(kSportmonksApiToken.trim())}&include=localteam,visitorteam&filter[starts_between]=$from,$to'),
    Uri.parse('$kSportmonksBaseUrl/fixtures?api_token=${Uri.encodeComponent(kSportmonksApiToken.trim())}&include=localteam,visitorteam'),
  ];
  for (final url in urls) {
    try {
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      if (res.statusCode == 401) throw Exception('token invalid');
      if (res.statusCode != 200) continue;
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final list = (json['data'] as List?) ?? const [];
      final loaded = <UpcomingMatch>[];
      for (final item in list) {
        if (item is Map) {
          final match = UpcomingMatch.fromJson(Map<String, dynamic>.from(item));
          if (match != null && match.startingAt.isAfter(now.subtract(const Duration(hours: 2)))) loaded.add(match);
        }
      }
      loaded.sort((a, b) => a.startingAt.compareTo(b.startingAt));
      return loaded.take(20).toList();
    } catch (_) {}
  }
  return const [];
}

class UpcomingMatch {
  final int id;
  final String title;
  final String series;
  final String timeText;
  final String localCode;
  final String visitCode;
  final String? localImage;
  final String? visitImage;
  final DateTime startingAt;

  const UpcomingMatch({required this.id, required this.title, required this.series, required this.timeText, required this.localCode, required this.visitCode, required this.localImage, required this.visitImage, required this.startingAt});

  static UpcomingMatch? fromJson(Map<String, dynamic> item) {
    final rawId = item['id'];
    final id = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '');
    if (id == null) return null;
    final start = DateTime.tryParse((item['starting_at'] ?? '').toString())?.toLocal();
    if (start == null) return null;
    final local = Map<String, dynamic>.from((item['localteam'] as Map?) ?? const {});
    final visit = Map<String, dynamic>.from((item['visitorteam'] as Map?) ?? const {});
    final localName = (local['name'] ?? 'Team ${item['localteam_id'] ?? ''}').toString();
    final visitName = (visit['name'] ?? 'Team ${item['visitorteam_id'] ?? ''}').toString();
    final localCode = (local['code'] ?? _shortCodeStatic(localName)).toString();
    final visitCode = (visit['code'] ?? _shortCodeStatic(visitName)).toString();
    final series = (item['round'] ?? item['type'] ?? 'Upcoming match').toString();
    final timeText = "${start.day.toString().padLeft(2, '0')}/${start.month.toString().padLeft(2, '0')} • ${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')}";
    return UpcomingMatch(id: id, title: '$localName vs $visitName', series: series, timeText: timeText, localCode: localCode, visitCode: visitCode, localImage: local['image_path']?.toString(), visitImage: visit['image_path']?.toString(), startingAt: start);
  }
}

class UpcomingMatchTile extends StatelessWidget {
  final UpcomingMatch match;
  const UpcomingMatchTile({super.key, required this.match});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          _NetTeamLogo(code: match.localCode, image: match.localImage),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(match.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15), maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 5),
            Text(match.series, style: const TextStyle(color: AppColor.muted, fontSize: 12.5), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 5),
            Text(match.timeText, style: const TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900, fontSize: 12.5)),
          ])),
          _NetTeamLogo(code: match.visitCode, image: match.visitImage),
        ]),
      ),
    );
  }
}

class MatchListTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String left;
  final String right;
  const MatchListTile({super.key, required this.title, required this.subtitle, required this.left, required this.right});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailPage(initialTab: 1))),
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          TeamLogo(code: left, size: 42),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(color: AppColor.muted, fontSize: 12.5)),
          ])),
          TeamLogo(code: right, size: 42),
        ]),
      ),
    );
  }
}

class FixturesPage extends StatefulWidget {
  const FixturesPage({super.key});

  @override
  State<FixturesPage> createState() => _FixturesPageState();
}

class _FixturesPageState extends State<FixturesPage> {
  bool loading = true;
  String message = 'Loading fixtures...';
  List<HomeLiveMatch> live = const [];
  List<UpcomingMatch> upcoming = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { loading = true; message = 'Loading fixtures...'; });
    try {
      final liveList = await _fetchLiveHomeMatches();
      final upcomingList = await _fetchUpcomingMatches();
      if (!mounted) return;
      setState(() {
        loading = false;
        live = liveList;
        upcoming = upcomingList;
        message = liveList.isEmpty && upcomingList.isEmpty ? 'No matches found right now' : 'Updated just now';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { loading = false; message = 'API error: ${e.toString().replaceAll('Exception: ', '')}'; });
    }
  }

  void _openLive(HomeLiveMatch m) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => MatchDetailPage(initialTab: 1, initialFixtureId: m.id)));
  }

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Row(children: [
              const Expanded(child: Text('Fixtures', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
              IconButton(onPressed: _load, icon: const Icon(Icons.refresh, color: AppColor.cyan)),
            ]),
            Text(message, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            const SectionTitle('Running / Live Matches'),
            const SizedBox(height: 8),
            if (loading) const GlassCard(child: Text('Loading live matches...', style: TextStyle(fontWeight: FontWeight.w900)))
            else if (live.isEmpty) const GlassCard(child: Text('No live matches at the moment', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)))
            else for (final m in live) HomeLiveListTile(match: m, onTap: () => _openLive(m)),
            const SizedBox(height: 14),
            const SectionTitle('Upcoming Matches'),
            const SizedBox(height: 8),
            if (loading) const SizedBox.shrink()
            else if (upcoming.isEmpty) const GlassCard(child: Text('Upcoming fixtures API se nahi mila. Refresh karke try karo.', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)))
            else for (final m in upcoming) UpcomingMatchTile(match: m),
          ],
        ),
      ),
    );
  }
}

class SeriesPage extends StatefulWidget {
  const SeriesPage({super.key});

  @override
  State<SeriesPage> createState() => _SeriesPageState();
}

class _SeriesPageState extends State<SeriesPage> {
  bool loading = true;
  List<String> series = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final live = await _fetchLiveHomeMatches();
      final upcoming = await _fetchUpcomingMatches();
      final names = <String>{};
      for (final m in live) {
        if (m.subtitle.trim().isNotEmpty) names.add(m.subtitle.trim());
      }
      for (final m in upcoming) {
        if (m.series.trim().isNotEmpty) names.add(m.series.trim());
      }
      if (!mounted) return;
      setState(() {
        loading = false;
        series = names.toList()..sort();
      });
    } catch (_) {
      if (!mounted) return;
      setState(() { loading = false; series = const []; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Row(children: [
              const Expanded(child: Text('Series', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
              IconButton(onPressed: _load, icon: const Icon(Icons.refresh, color: AppColor.cyan)),
            ]),
            const SizedBox(height: 12),
            if (loading) const GlassCard(child: Text('Loading series from API...', style: TextStyle(fontWeight: FontWeight.w900)))
            else if (series.isEmpty) const GlassCard(child: Text('No active series found right now', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)))
            else for (final title in series) SeriesCard(title: title, subtitle: 'Live fixtures, commentary and scorecard'),
          ],
        ),
      ),
    );
  }
}

class SeriesCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SeriesCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        child: Row(children: [
          const TournamentLogo(size: 58),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(color: AppColor.muted)),
          ])),
          const Icon(Icons.chevron_right, color: AppColor.muted),
        ]),
      ),
    );
  }
}

class MorePage extends StatefulWidget {
  const MorePage({super.key});

  @override
  State<MorePage> createState() => _MorePageState();
}

class _MorePageState extends State<MorePage> {
  bool alertsOn = true;

  void _snack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _openUrl(String url) async {
    var raw = url.trim();
    if (!raw.startsWith('http://') && !raw.startsWith('https://')) {
      raw = 'https://$raw';
    }
    final ok = await launchUrl(Uri.parse(raw), mode: LaunchMode.externalApplication);
    if (!ok) {
      await Clipboard.setData(ClipboardData(text: raw));
      if (mounted) _snack('Link open nahi hua, copy kar diya ✅');
    }
  }

  Future<void> _shareApp() async {
    _snack('Share option ready ✅');
  }

  void _openMatchTab(int tab) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => MatchDetailPage(initialTab: tab)));
  }

  void _openPage(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const Text('More', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          welcomeCardMore(),
          const SizedBox(height: 14),
          MoreTile(icon: Icons.flash_on, title: 'Live Matches', onTap: () => _openMatchTab(1)),
          MoreTile(icon: Icons.calendar_month_outlined, title: 'Fixtures & Schedule', onTap: () => _openPage(const FixturesPage())),
          MoreTile(icon: Icons.comment_outlined, title: 'Commentary', onTap: () => _openMatchTab(2)),
          MoreTile(icon: Icons.table_chart_outlined, title: 'Scorecards', onTap: () => _openMatchTab(3)),
          MoreTile(icon: Icons.leaderboard_outlined, title: 'Points Table', onTap: () => _openMatchTab(5)),
          MoreTile(
            icon: Icons.notifications_active_outlined,
            title: 'Live Score Alerts',
            trailing: alertsOn ? 'On' : 'Off',
            onTap: () async {
              final next = !alertsOn;
              setState(() => alertsOn = next);
              if (next) {
                final allowed = await requestAllrounderNotificationPermission();
                await showAllrounderNotification('Allrounder99', 'Live Score Alerts ON ✅');
                _snack(allowed ? 'Notifications ON ✅' : 'Notification permission allow karo');
              } else {
                _snack('Live score alerts OFF');
              }
            },
          ),
          MoreTile(
            icon: Icons.volume_up_outlined,
            title: 'Cricket Voice Sound',
            trailing: 'Live',
            onTap: () => _openMatchTab(1),
          ),
          MoreTile(
            icon: Icons.notification_add_outlined,
            title: 'Test Notification',
            onTap: () async {
              final allowed = await requestAllrounderNotificationPermission();
              await showAllrounderNotification('Allrounder99', 'Test notification working ✅');
              _snack(allowed ? 'Test notification sent ✅' : 'Permission allow karo');
            },
          ),
          MoreTile(icon: Icons.language, title: 'Language', trailing: 'English', onTap: () => _snack('Language: English')),
          MoreTile(icon: Icons.share_outlined, title: 'Share App', onTap: _shareApp),
          MoreTile(icon: Icons.star_border, title: 'Rate Us', onTap: () => _snack('Thank you for rating Allrounder99 ⭐')),
          MoreTile(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy', onTap: () => _openUrl('https://ravikky909-ux.github.io/Allronder99/privacy-policy.html')),
          MoreTile(
            icon: Icons.description_outlined,
            title: 'Terms & Conditions',
            onTap: () => _openPage(const SimpleInfoPage(
              title: 'Terms & Conditions',
              body: 'Allrounder99 is for cricket score and match information. Use the app for personal information and entertainment. Data and match details may update from external sources.',
            )),
          ),
          MoreTile(
            icon: Icons.info_outline,
            title: 'About Allrounder99',
            trailing: 'v1.0.0',
            onTap: () => _openPage(const SimpleInfoPage(
              title: 'About Allrounder99',
              body: 'Allrounder99 is a cricket scoring app with live-style match screens, commentary, scorecard, history, points table and admin updates.',
            )),
          ),
        ],
      ),
    );
  }
}

class SimpleInfoPage extends StatelessWidget {
  final String title;
  final String body;
  const SimpleInfoPage({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(backgroundColor: AppColor.bg, title: Text(title)),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            GlassCard(
              child: Text(body, style: const TextStyle(color: AppColor.text, fontSize: 16, height: 1.45, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }
}




class MoreTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final VoidCallback? onTap;
  const MoreTile({super.key, required this.icon, required this.title, this.trailing, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: AppColor.cyan),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
            if (trailing != null) Text(trailing!, style: const TextStyle(color: AppColor.muted)),
            const Icon(Icons.chevron_right, color: AppColor.muted),
          ],
        ),
      ),
    );
  }
}

class MatchDetailPage extends StatefulWidget {
  final int initialTab;
  final int? initialFixtureId;
  const MatchDetailPage({super.key, this.initialTab = 0, this.initialFixtureId});

  @override
  State<MatchDetailPage> createState() => _MatchDetailPageState();
}

class _MatchDetailPageState extends State<MatchDetailPage> {
  late int tab;
  late final PageController pageController;
  final tabs = const ['Info', 'Live', 'Commentary', 'Scorecard', 'History', 'Points Table'];

  @override
  void initState() {
    super.initState();
    tab = widget.initialTab;
    pageController = PageController(initialPage: tab);
    if (widget.initialFixtureId != null) {
      selectedFixtureIdNotifier.value = widget.initialFixtureId;
    }
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  void openTab(int index) {
    setState(() => tab = index);
    pageController.animateToPage(index, duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      DynamicInfoTab(initialFixtureId: widget.initialFixtureId),
      LiveTab(initialFixtureId: widget.initialFixtureId),
      DynamicCommentaryTab(initialFixtureId: widget.initialFixtureId),
      DynamicScorecardTab(initialFixtureId: widget.initialFixtureId),
      const HistoryTab(),
      const PointsTableTab(),
    ];

    return Scaffold(
      body: GradientPage(
        child: Column(
          children: [
            SizedBox(
              height: 48,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: tabs.length,
                separatorBuilder: (_, __) => const SizedBox(width: 14),
                itemBuilder: (context, i) => GestureDetector(
                  onTap: () => openTab(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tab == i ? Colors.white : Colors.transparent, width: 3))),
                    child: Text(
                      tabs[i],
                      style: TextStyle(color: tab == i ? AppColor.text : AppColor.muted, fontWeight: FontWeight.w900, fontSize: 17),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: PageView(
                controller: pageController,
                onPageChanged: (value) => setState(() => tab = value),
                children: pages,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MatchTeamsHeader extends StatelessWidget {
  final bool scores;
  const MatchTeamsHeader({super.key, this.scores = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 12, 17, 8),
      child: Row(
        children: [
          const TeamLogo(code: 'SCOW', size: 58),
          const SizedBox(width: 14),
          Expanded(
            child: scores
                ? const Text('151-6 (20.0)\nSCOW', style: TextStyle(fontWeight: FontWeight.w900, height: 1.35))
                : const Text('SCOW', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          ),
          const Icon(Icons.flash_on, color: AppColor.text, size: 28),
          Expanded(
            child: scores
                ? const Text('0-0\nSLW', textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, height: 1.35))
                : const Text('SLW', textAlign: TextAlign.right, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 14),
          const TeamLogo(code: 'SLW', size: 58),
        ],
      ),
    );
  }
}

class InfoTab extends StatelessWidget {
  const InfoTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: const [
        MatchTeamsHeader(),
        TournamentInfoCard(),
        SizedBox(height: 14),
        MatchMetaCard(),
        SizedBox(height: 16),
        Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: Text('Team Squads', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        SizedBox(height: 10),
        TeamSquadsCard(),
        SizedBox(height: 16),
        Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: Text('Recent Performance   (Last 5 Matches)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        SizedBox(height: 10),
        RecentPerformanceCard(),
        SizedBox(height: 16),
        Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: Text('Head to Head', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        SizedBox(height: 10),
        HeadToHeadCard(),
        SizedBox(height: 20),
      ],
    );
  }
}

class TournamentInfoCard extends StatelessWidget {
  const TournamentInfoCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        child: Row(
          children: const [
            TournamentLogo(size: 70),
            SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('25th Match, Group B', style: TextStyle(color: AppColor.muted, fontSize: 17)),
              SizedBox(height: 8),
              Text('Scotland Women Vs Sri Lanka Women', style: TextStyle(color: AppColor.muted, fontSize: 17)),
              SizedBox(height: 8),
              Text('Womens T20 World Cup 2026', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            ])),
            Icon(Icons.chevron_right, color: AppColor.muted),
          ],
        ),
      ),
    );
  }
}

class MatchMetaCard extends StatelessWidget {
  const MatchMetaCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(
          children: const [
            MetaLine(icon: Icons.calendar_month, text: 'Fri, 26 Jun, 11:00 PM at Your Time'),
            Divider(height: 1, color: AppColor.line),
            MetaLine(icon: Icons.thumb_up_alt, text: 'Sri Lanka Women opt to bowl', iconColor: Colors.orangeAccent),
            Divider(height: 1, color: AppColor.line),
            MetaLine(icon: Icons.location_on, text: 'Emirates Old Trafford, Manchester, England', iconColor: Colors.red),
          ],
        ),
      ),
    );
  }
}

class MetaLine extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color iconColor;
  const MetaLine({super.key, required this.icon, required this.text, this.iconColor = Colors.white});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Icon(icon, color: iconColor, size: 24),
        const SizedBox(width: 15),
        Expanded(child: Text(text, style: const TextStyle(color: AppColor.muted, fontSize: 16, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}

class TeamSquadsCard extends StatelessWidget {
  const TeamSquadsCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(children: [
          SquadLine(code: 'SLW', name: 'Sri Lanka Women'),
          Divider(height: 1, color: AppColor.line),
          SquadLine(code: 'SCOW', name: 'Scotland Women'),
        ]),
      ),
    );
  }
}

class SquadLine extends StatelessWidget {
  final String code;
  final String name;
  const SquadLine({super.key, required this.code, required this.name});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(13),
      child: Row(children: [
        TeamLogo(code: code, size: 32, showCode: false),
        const SizedBox(width: 8),
        Expanded(child: Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        const Icon(Icons.chevron_right, color: AppColor.muted),
      ]),
    );
  }
}

class RecentPerformanceCard extends StatelessWidget {
  const RecentPerformanceCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: Column(
        children: const [
          FormLine(team: 'Sri Lanka Women', results: ['*', 'W', 'L', 'W', 'L', 'W']),
          SizedBox(height: 8),
          FormLine(team: 'Scotland Women', results: ['*', 'L', 'L', 'L', 'W', 'W']),
        ],
      ),
    );
  }
}

class FormLine extends StatelessWidget {
  final String team;
  final List<String> results;
  const FormLine({super.key, required this.team, required this.results});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      child: Row(
        children: [
          Expanded(child: Text(team, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          for (final r in results) FormBox(r),
          const Icon(Icons.keyboard_arrow_down, color: AppColor.muted),
        ],
      ),
    );
  }
}

class FormBox extends StatelessWidget {
  final String text;
  const FormBox(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    Color bg = Colors.transparent;
    Color fg = Colors.white;
    Color border = Colors.white70;
    if (text == 'W') {
      bg = const Color(0xFFE9FFF0);
      fg = AppColor.green;
      border = AppColor.green;
    } else if (text == 'L') {
      bg = const Color(0xFFFFEEF0);
      fg = AppColor.red;
      border = AppColor.red;
    }
    return Container(
      margin: const EdgeInsets.only(right: 6),
      width: 34,
      height: 34,
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(4), border: Border.all(color: border)),
      child: Center(child: Text(text, style: TextStyle(color: fg, fontWeight: FontWeight.w900))),
    );
  }
}

class HeadToHeadCard extends StatelessWidget {
  const HeadToHeadCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        child: Row(
          children: const [
            SizedBox(width: 95, child: Text('2\nMatches', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
            SizedBox(width: 16),
            Expanded(child: Column(children: [
              H2HLine(code: 'SLW', won: 'Won 2', value: 1.0),
              Divider(height: 20, color: AppColor.line),
              H2HLine(code: 'SCOW', won: 'Won 0', value: 0.05),
            ])),
          ],
        ),
      ),
    );
  }
}

class H2HLine extends StatelessWidget {
  final String code;
  final String won;
  final double value;
  const H2HLine({super.key, required this.code, required this.won, required this.value});
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      TeamLogo(code: code, size: 42),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(won, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        LinearProgressIndicator(value: value, minHeight: 14, color: AppColor.purple, backgroundColor: AppColor.bg2, borderRadius: BorderRadius.circular(9)),
      ])),
    ]);
  }
}


class LiveTab extends StatefulWidget {
  final int? initialFixtureId;
  const LiveTab({super.key, this.initialFixtureId});

  @override
  State<LiveTab> createState() => _LiveTabState();
}

class _LiveTabState extends State<LiveTab> {
  final FlutterTts _tts = FlutterTts();
  Timer? _apiTimer;
  String _apiToken = kSportmonksApiToken;

  bool soundOn = true;
  bool apiAutoOn = true;
  bool loading = true;
  bool _isRefreshing = false;

  int? _fixtureId;
  int? _lastBallId;
  String? _lastStatusText;
  List<LiveMatchSummary> liveMatches = const [];

  String apiStatus = 'Connecting live cricket API...';
  String liveEventText = 'Connecting API...';
  String matchStatus = 'Live';
  String localTeamName = 'Team A';
  String visitTeamName = 'Team B';
  String localTeamCode = 'A';
  String visitTeamCode = 'B';
  String? localTeamImage;
  String? visitTeamImage;
  String battingTeamCode = 'BAT';
  String bowlingTeamCode = 'BOWL';
  String scoreLine = 'Loading score...';
  String otherLine = '';
  String runRateText = 'Run Rate: --';
  String ballsRemainingText = 'Balls Rem: --';
  String overLabel = 'Live over';
  List<String> recentBalls = const [];
  List<List<String>> liveBattingRows = const [['Data loading', '--', '--', '--', '--']];
  List<List<String>> liveBowlingRows = const [['Data loading', '--', '--', '--', '--']];
  String winLeftCode = 'A';
  String winRightCode = 'B';
  int winLeftPct = 50;
  int winRightPct = 50;
  String sixOverProjection = '6 Ov: --';
  String fullOverProjection = '20 Ov: --';

  @override
  void initState() {
    super.initState();
    _fixtureId = widget.initialFixtureId;
    if (_fixtureId != null) {
      selectedFixtureIdNotifier.value = _fixtureId;
    }
    _setupVoice();
    _loadSavedApiToken();
    _startApiAuto();
  }

  Future<void> _loadSavedApiToken() async {
    // API token is built into the app. Ignore any old saved token so users never see token setup.
    _apiToken = kSportmonksApiToken.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('sportmonks_api_token');
    if (!mounted) return;
    await _loadLiveMatch(announceLatest: false);
  }

  Future<void> _setupVoice() async {
    await _tts.setLanguage('en-IN');
    await _tts.setSpeechRate(0.42);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.08);
  }

  void _startApiAuto() {
    _apiTimer?.cancel();
    if (!apiAutoOn) return;
    _apiTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted || !apiAutoOn) return;
      _loadLiveMatch(announceLatest: true);
    });
  }

  void _toggleApiAuto() {
    setState(() => apiAutoOn = !apiAutoOn);
    if (apiAutoOn) {
      _startApiAuto();
      _loadLiveMatch(announceLatest: false);
    } else {
      _apiTimer?.cancel();
      setState(() => apiStatus = 'Auto refresh off');
    }
  }

  Future<void> _loadLiveMatch({required bool announceLatest}) async {
    if (_isRefreshing) return;
    _isRefreshing = true;
    try {
      final token = _apiToken.trim();
      if (token.isEmpty) {
        if (!mounted) return;
        setState(() {
          loading = false;
          apiStatus = 'API token not configured';
          liveEventText = 'API setup issue';
          scoreLine = 'API setup issue';
        });
        return;
      }

      final liveUrl = Uri.parse(
        '$kSportmonksBaseUrl/livescores?api_token=${Uri.encodeComponent(token)}&include=localteam,visitorteam,runs',
      );
      final liveRes = await http.get(liveUrl).timeout(const Duration(seconds: 10));
      if (liveRes.statusCode == 401) throw Exception('Livescores 401 - token invalid');
      if (liveRes.statusCode != 200) throw Exception('Livescores ${liveRes.statusCode}');

      final liveJson = jsonDecode(liveRes.body) as Map<String, dynamic>;
      final list = (liveJson['data'] as List?) ?? const [];
      final matches = <LiveMatchSummary>[];
      for (final entry in list) {
        if (entry is Map) {
          final data = Map<String, dynamic>.from(entry);
          if (!_isActuallyPlayingLive(data)) continue;
          final match = _summaryFromLiveFixture(data);
          if (match != null) matches.add(match);
        }
      }
      matches.sort((a, b) {
        final p = _liveStatusPriority(a.status).compareTo(_liveStatusPriority(b.status));
        if (p != 0) return p;
        return a.title.compareTo(b.title);
      });

      if (matches.isEmpty) {
        if (!mounted) return;
        setState(() {
          loading = false;
          liveMatches = const [];
          _fixtureId = null;
          apiStatus = 'No live matches right now';
          liveEventText = 'No live match at the moment';
          scoreLine = 'Waiting for live match';
          recentBalls = const [];
        });
        return;
      }

      int? selected = _fixtureId;
      final selectedStillLive = selected != null && matches.any((match) => match.id == selected);
      if (!selectedStillLive) {
        selected = matches.first.id;
        _lastBallId = null;
        _lastStatusText = null;
      }

      if (!mounted) return;
      setState(() {
        liveMatches = matches;
        _fixtureId = selected;
      });
      if (selected != null) {
        selectedFixtureIdNotifier.value = selected;
      }

      if (selected != null) {
        await _loadFixture(selected, announceLatest: announceLatest);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        apiStatus = 'API error: ${e.toString().replaceAll('Exception: ', '')}';
        liveEventText = 'API retrying...';
      });
    } finally {
      _isRefreshing = false;
    }
  }

  LiveMatchSummary? _summaryFromLiveFixture(Map<String, dynamic> item) {
    final rawId = item['id'];
    final id = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '');
    if (id == null) return null;

    final local = Map<String, dynamic>.from((item['localteam'] as Map?) ?? const {});
    final visit = Map<String, dynamic>.from((item['visitorteam'] as Map?) ?? const {});
    final runs = ((item['runs'] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

    final localName = (local['name'] ?? 'Team ${item['localteam_id'] ?? ''}').toString();
    final visitName = (visit['name'] ?? 'Team ${item['visitorteam_id'] ?? ''}').toString();
    final localCode = (local['code'] ?? _shortCode(localName)).toString();
    final visitCode = (visit['code'] ?? _shortCode(visitName)).toString();

    String score = (item['status'] ?? 'Live').toString();
    if (runs.isNotEmpty) {
      final run = runs.last;
      final battingTeamId = run['team_id'];
      final battingCode = battingTeamId == local['id'] ? localCode : (battingTeamId == visit['id'] ? visitCode : 'BAT');
      score = '$battingCode ${_asInt(run['score'])}-${_asInt(run['wickets'])} (${_formatOvers(run['overs'])})';
    }

    return LiveMatchSummary(
      id: id,
      title: '$localCode vs $visitCode',
      subtitle: (item['round'] ?? item['type'] ?? 'Live match').toString(),
      status: _friendlyMatchState(item),
      score: score,
    );
  }

  Future<void> _selectLiveMatch(int fixtureId) async {
    if (_fixtureId == fixtureId) return;
    _apiTimer?.cancel();
    setState(() {
      _fixtureId = fixtureId;
      selectedFixtureIdNotifier.value = fixtureId;
      _lastBallId = null;
      _lastStatusText = null;
      loading = true;
      apiStatus = 'Loading selected live match...';
      liveEventText = 'Loading match...';
      scoreLine = 'Loading score...';
      recentBalls = const [];
    });
    try {
      await _loadFixture(fixtureId, announceLatest: false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        apiStatus = 'API error: ${e.toString().replaceAll('Exception: ', '')}';
        liveEventText = 'API retrying...';
      });
    } finally {
      _startApiAuto();
    }
  }

  Future<void> _loadFixture(int fixtureId, {required bool announceLatest}) async {
    final url = Uri.parse('$kSportmonksBaseUrl/fixtures/$fixtureId?api_token=${Uri.encodeComponent(_apiToken.trim())}&include=localteam,visitorteam,runs,scoreboards,balls');
    final res = await http.get(url).timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) throw Exception('Fixture ${res.statusCode}');
    final json = jsonDecode(res.body) as Map<String, dynamic>;
    final data = Map<String, dynamic>.from(json['data'] as Map);

    final local = Map<String, dynamic>.from((data['localteam'] as Map?) ?? const {});
    final visit = Map<String, dynamic>.from((data['visitorteam'] as Map?) ?? const {});
    final runs = ((data['runs'] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final balls = ((data['balls'] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    balls.sort((a, b) => ((a['id'] ?? 0) as num).compareTo((b['id'] ?? 0) as num));

    final displayStatus = _friendlyMatchState(data);
    final playStopped = _isPlayStoppedOrBreak(displayStatus);
    final Map<String, dynamic>? latestBall = balls.isNotEmpty ? balls.last : null;
    final latestCode = latestBall == null ? 'LIVE' : _ballCode(latestBall);
    final latestText = latestBall == null ? 'Ball running' : _voiceText(latestCode);
    final latestId = latestBall == null ? null : (latestBall['id'] as int?);

    final Map<String, dynamic>? run = runs.isNotEmpty ? runs.last : null;
    final battingTeamId = run != null ? run['team_id'] : (latestBall != null ? latestBall['team_id'] : null);
    final localId = local['id'];
    final visitId = visit['id'];

    localTeamName = (local['name'] ?? 'Team A').toString();
    visitTeamName = (visit['name'] ?? 'Team B').toString();
    localTeamCode = (local['code'] ?? _shortCode(localTeamName)).toString();
    visitTeamCode = (visit['code'] ?? _shortCode(visitTeamName)).toString();
    localTeamImage = local['image_path']?.toString();
    visitTeamImage = visit['image_path']?.toString();

    battingTeamCode = battingTeamId == localId ? localTeamCode : (battingTeamId == visitId ? visitTeamCode : 'BAT');
    bowlingTeamCode = battingTeamCode == localTeamCode ? visitTeamCode : localTeamCode;

    if (run != null) {
      final score = _asInt(run['score']);
      final wickets = _asInt(run['wickets']);
      final overs = _formatOvers(run['overs']);
      scoreLine = '$battingTeamCode $score-$wickets ($overs)';
      runRateText = 'Run Rate: ${_runRate(score, run['overs'])}';
      ballsRemainingText = 'Balls Rem: ${_ballsRemaining(data['total_overs_played'], run['overs'])}';
    } else {
      scoreLine = '$battingTeamCode score loading';
      runRateText = 'Run Rate: --';
      ballsRemainingText = 'Balls Rem: --';
    }

    matchStatus = displayStatus;
    otherLine = playStopped ? displayStatus : '$bowlingTeamCode bowling';
    overLabel = playStopped ? displayStatus : (latestBall == null ? 'Live over' : 'Ball ${latestBall['ball']}');
    recentBalls = balls.takeLast(18).map(_ballCode).toList();
    liveBattingRows = _calculateBattingStats(balls);
    liveBowlingRows = _calculateBowlingStats(balls);
    winLeftCode = localTeamCode;
    winRightCode = visitTeamCode;
    final prob = _estimateWinProbability(data, runs, localId, visitId);
    winLeftPct = prob[0];
    winRightPct = prob[1];
    final projections = _projectionTexts(run, data['total_overs_played']);
    sixOverProjection = projections[0];
    fullOverProjection = projections[1];

    if (!mounted) return;
    setState(() {
      loading = false;
      apiStatus = 'Live score updated • ${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')} • $displayStatus';
      liveEventText = playStopped ? displayStatus : (latestBall == null ? 'Ball running' : latestText);
    });

    if (playStopped) {
      if (announceLatest && displayStatus != _lastStatusText) {
        _lastStatusText = displayStatus;
        await _announceStatus(displayStatus);
      }
      return;
    }

    _lastStatusText = null;
    if (announceLatest && latestId != null && latestId != _lastBallId) {
      _lastBallId = latestId;
      await _announce(latestCode);
    } else if (_lastBallId == null && latestId != null) {
      _lastBallId = latestId;
    }
  }

  String _shortCode(String name) {
    final parts = name.trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
    if (parts.isEmpty) return 'TM';
    if (parts.length == 1) return parts.first.substring(0, parts.first.length < 3 ? parts.first.length : 3).toUpperCase();
    return parts.map((e) => e[0]).join().toUpperCase();
  }

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.round();
    return int.tryParse(v?.toString() ?? '') ?? 0;
  }

  String _formatOvers(dynamic overs) {
    if (overs == null) return '--';
    final s = overs.toString();
    return s.contains('.') ? s : '$s.0';
  }

  String _runRate(int score, dynamic oversValue) {
    final overs = double.tryParse(oversValue?.toString() ?? '') ?? 0;
    if (overs <= 0) return '--';
    return (score / overs).toStringAsFixed(2);
  }

  String _ballsRemaining(dynamic totalOversValue, dynamic oversValue) {
    final totalOvers = _asInt(totalOversValue);
    final overs = double.tryParse(oversValue?.toString() ?? '') ?? 0;
    if (totalOvers <= 0 || overs <= 0) return '--';
    final completedOvers = overs.floor();
    final ballPart = ((overs - completedOvers) * 10).round();
    final legalBalls = (completedOvers * 6) + ballPart;
    final remaining = (totalOvers * 6) - legalBalls;
    return remaining < 0 ? '0' : remaining.toString();
  }


  List<int> _estimateWinProbability(Map<String, dynamic> data, List<Map<String, dynamic>> runs, dynamic localId, dynamic visitId) {
    if (runs.isEmpty) return const [50, 50];
    final last = runs.last;
    final battingId = last['team_id'];
    final score = _asInt(last['score']);
    final wickets = _asInt(last['wickets']);
    final overs = double.tryParse(last['overs']?.toString() ?? '') ?? 0;
    final rr = overs <= 0 ? 0 : score / overs;
    var battingPct = 50 + ((rr - 7.0) * 4).round() - (wickets * 3);
    battingPct = battingPct.clamp(20, 80).toInt();
    if (_isPlayStoppedOrBreak(_friendlyMatchState(data))) {
      battingPct = (battingPct * 0.90).round().clamp(20, 80).toInt();
    }
    if (battingId == localId) return [battingPct, 100 - battingPct];
    if (battingId == visitId) return [100 - battingPct, battingPct];
    return const [50, 50];
  }

  List<String> _projectionTexts(Map<String, dynamic>? run, dynamic totalOversValue) {
    if (run == null) return const ['6 Ov: --', 'Full Ov: --'];
    final score = _asInt(run['score']);
    final wickets = _asInt(run['wickets']);
    final overs = double.tryParse(run['overs']?.toString() ?? '') ?? 0;
    if (overs <= 0) return const ['6 Ov: --', 'Full Ov: --'];
    final rr = score / overs;
    final sixProj = overs >= 6 ? score : (rr * 6).round();
    final totalOvers = _asInt(totalOversValue) <= 0 ? 20 : _asInt(totalOversValue);
    final fullProj = (rr * totalOvers).round().clamp(score, 999).toInt();
    return ['6 Ov Proj: $sixProj/$wickets', '$totalOvers Ov Proj: $fullProj/$wickets'];
  }

  String _ballCode(Map<String, dynamic> ball) {
    final score = Map<String, dynamic>.from((ball['score'] as Map?) ?? const {});
    final name = (score['name'] ?? '').toString().toLowerCase();
    final runs = _asInt(score['runs']);
    if (score['is_wicket'] == true || score['out'] == true || name.contains('wicket')) return 'W';
    if (_asInt(score['noball']) > 0 || _asInt(score['noball_runs']) > 0 || name.contains('no ball') || name.contains('noball')) return 'NB';
    if (name.contains('wide')) return 'WD';
    if (score['six'] == true || name.contains('six')) return '6';
    if (score['four'] == true || name.contains('four')) return '4';
    if (runs == 0) return '0';
    if (runs == 1) return '1';
    if (runs == 2) return '2';
    if (runs == 3) return '3';
    return runs.toString();
  }

  String _voiceText(String code) {
    switch (code.toUpperCase()) {
      case '6':
        return 'Six';
      case '4':
        return 'Four';
      case '1':
        return 'Single';
      case '2':
        return 'Double';
      case '3':
        return 'Triple';
      case 'WD':
        return 'Wide';
      case 'NB':
        return 'No ball';
      case 'W':
        return 'Out';
      case '0':
        return 'Dot ball';
      default:
        return code;
    }
  }

  Future<void> _announceStatus(String statusText) async {
    if (!mounted) return;
    setState(() => liveEventText = statusText);
    await showAllrounderNotification('Allrounder99 Match Update', '$scoreLine • $statusText');
    if (!soundOn) return;
    await _tts.stop();
    await _tts.speak(statusText);
  }

  Future<void> _announce(String code) async {
    final text = _voiceText(code);
    final speakText = 'Ball start. $text';
    if (!mounted) return;
    setState(() => liveEventText = 'Ball Start • $text');
    await showAllrounderNotification('Allrounder99 Live Score', '$scoreLine • $speakText');
    if (!soundOn) return;
    await _tts.stop();
    await _tts.speak(speakText);
  }

  @override
  void dispose() {
    _apiTimer?.cancel();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () => _loadLiveMatch(announceLatest: false),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
        children: [
          if (liveMatches.isNotEmpty) ...[
            LiveMatchSelector(
              matches: liveMatches,
              selectedFixtureId: _fixtureId,
              onSelect: _selectLiveMatch,
            ),
            const SizedBox(height: 10),
          ],
          LiveApiTeamsHeader(
            localName: localTeamName,
            visitName: visitTeamName,
            localCode: localTeamCode,
            visitCode: visitTeamCode,
            localImage: localTeamImage,
            visitImage: visitTeamImage,
            scoreLine: scoreLine,
            otherLine: otherLine,
          ),
          TvLiveBox(
            eventText: liveEventText,
            soundOn: soundOn,
            battingCode: battingTeamCode,
            bowlingCode: bowlingTeamCode,
            scoreLine: scoreLine,
            otherLine: otherLine,
          ),
          const SizedBox(height: 10),
          SoundControlCard(
            soundOn: soundOn,
            apiAutoOn: apiAutoOn,
            apiStatus: apiStatus,
            onToggle: () => setState(() => soundOn = !soundOn),
            onAutoToggle: _toggleApiAuto,
            onRefresh: () => _loadLiveMatch(announceLatest: false),
          ),
          const SizedBox(height: 10),
          BallStrip(balls: recentBalls, overLabel: overLabel),
          const SizedBox(height: 10),
          LiveStatsCard(runRateText: runRateText, ballsRemainingText: ballsRemainingText),
          const SizedBox(height: 10),
          WinProbCard(leftCode: winLeftCode, rightCode: winRightCode, leftPct: winLeftPct, rightPct: winRightPct, sixOverProjection: sixOverProjection, fullOverProjection: fullOverProjection),
          const SizedBox(height: 10),
          GlassCard(padding: EdgeInsets.zero, child: ApiStatsTable(headers: const ['Batter', 'R', 'B', '4s', '6s'], rows: liveBattingRows.take(4).toList())),
          const SizedBox(height: 10),
          GlassCard(padding: EdgeInsets.zero, child: ApiStatsTable(headers: const ['Bowler', 'O', 'R', 'W', 'ER'], rows: liveBowlingRows.take(4).toList())),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

extension _TakeLastExtension<T> on List<T> {
  List<T> takeLast(int count) {
    if (length <= count) return List<T>.from(this);
    return sublist(length - count);
  }
}



class ApiFixtureSnapshot {
  final int id;
  final String localName;
  final String visitName;
  final String localCode;
  final String visitCode;
  final String? localImage;
  final String? visitImage;
  final String title;
  final String subtitle;
  final String statusText;
  final String scoreLine;
  final String otherLine;
  final String battingCode;
  final String bowlingCode;
  final String latestEvent;
  final String overLabel;
  final List<Map<String, dynamic>> runs;
  final List<Map<String, dynamic>> balls;
  final List<Map<String, dynamic>> scoreboards;
  final Map<String, dynamic> raw;

  const ApiFixtureSnapshot({
    required this.id,
    required this.localName,
    required this.visitName,
    required this.localCode,
    required this.visitCode,
    required this.localImage,
    required this.visitImage,
    required this.title,
    required this.subtitle,
    required this.statusText,
    required this.scoreLine,
    required this.otherLine,
    required this.battingCode,
    required this.bowlingCode,
    required this.latestEvent,
    required this.overLabel,
    required this.runs,
    required this.balls,
    required this.scoreboards,
    required this.raw,
  });

  factory ApiFixtureSnapshot.fromJson(Map<String, dynamic> data) {
    final rawId = data['id'];
    final id = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '') ?? 0;
    final local = Map<String, dynamic>.from((data['localteam'] as Map?) ?? const {});
    final visit = Map<String, dynamic>.from((data['visitorteam'] as Map?) ?? const {});
    final runs = ((data['runs'] as List?) ?? const []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    final balls = ((data['balls'] as List?) ?? const []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    balls.sort((a, b) => (_asIntStatic(a['id'])).compareTo(_asIntStatic(b['id'])));
    final scoreboards = ((data['scoreboards'] as List?) ?? const []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();

    final localName = (local['name'] ?? 'Team ${data['localteam_id'] ?? ''}').toString();
    final visitName = (visit['name'] ?? 'Team ${data['visitorteam_id'] ?? ''}').toString();
    final localCode = (local['code'] ?? _shortCodeStatic(localName)).toString();
    final visitCode = (visit['code'] ?? _shortCodeStatic(visitName)).toString();
    final localId = local['id'];
    final visitId = visit['id'];
    final latestBall = balls.isNotEmpty ? balls.last : null;
    final run = runs.isNotEmpty ? runs.last : null;
    final battingTeamId = run != null ? run['team_id'] : latestBall?['team_id'];
    final battingCode = battingTeamId == localId ? localCode : (battingTeamId == visitId ? visitCode : 'BAT');
    final bowlingCode = battingCode == localCode ? visitCode : localCode;

    String scoreLine = 'Score loading';
    if (run != null) {
      scoreLine = '$battingCode ${_asIntStatic(run['score'])}-${_asIntStatic(run['wickets'])} (${_formatOversStatic(run['overs'])})';
    }
    final statusText = _friendlyMatchState(data);
    final stopped = _isPlayStoppedOrBreak(statusText);
    final latestCode = latestBall == null ? 'LIVE' : _apiBallCode(latestBall);
    final latestEvent = stopped ? statusText : (latestBall == null ? 'Ball running' : 'Ball Start • ${_apiVoiceText(latestCode)}');
    final overLabel = stopped ? statusText : (latestBall == null ? 'Live over' : 'Ball ${latestBall['ball']}');
    final otherLine = stopped ? statusText : '$bowlingCode bowling';

    return ApiFixtureSnapshot(
      id: id,
      localName: localName,
      visitName: visitName,
      localCode: localCode,
      visitCode: visitCode,
      localImage: local['image_path']?.toString(),
      visitImage: visit['image_path']?.toString(),
      title: '$localName vs $visitName',
      subtitle: (data['round'] ?? data['type'] ?? 'Live match').toString(),
      statusText: statusText,
      scoreLine: scoreLine,
      otherLine: otherLine,
      battingCode: battingCode,
      bowlingCode: bowlingCode,
      latestEvent: latestEvent,
      overLabel: overLabel,
      runs: runs,
      balls: balls,
      scoreboards: scoreboards,
      raw: data,
    );
  }
}

String _apiBallCode(Map<String, dynamic> ball) {
  final score = Map<String, dynamic>.from((ball['score'] as Map?) ?? const {});
  final name = (score['name'] ?? '').toString().toLowerCase();
  final runs = _asIntStatic(score['runs']);
  if (score['is_wicket'] == true || score['out'] == true || name.contains('wicket')) return 'W';
  if (_asIntStatic(score['noball']) > 0 || _asIntStatic(score['noball_runs']) > 0 || name.contains('no ball') || name.contains('noball')) return 'NB';
  if (name.contains('wide')) return 'WD';
  if (score['six'] == true || name.contains('six')) return '6';
  if (score['four'] == true || name.contains('four')) return '4';
  if (runs == 0) return '0';
  if (runs == 1) return '1';
  if (runs == 2) return '2';
  if (runs == 3) return '3';
  return runs.toString();
}

String _apiVoiceText(String code) {
  switch (code.toUpperCase()) {
    case '6': return 'Six';
    case '4': return 'Four';
    case '1': return 'Single';
    case '2': return 'Double';
    case '3': return 'Triple';
    case 'WD': return 'Wide';
    case 'NB': return 'No ball';
    case 'W': return 'Out';
    case '0': return 'Dot ball';
    default: return code;
  }
}

Future<int?> _fetchFirstLiveFixtureId() async {
  final url = Uri.parse('$kSportmonksBaseUrl/livescores?api_token=${Uri.encodeComponent(kSportmonksApiToken.trim())}&include=localteam,visitorteam,runs');
  final res = await http.get(url).timeout(const Duration(seconds: 10));
  if (res.statusCode != 200) throw Exception('Livescores ${res.statusCode}');
  final json = jsonDecode(res.body) as Map<String, dynamic>;
  final list = (json['data'] as List?) ?? const [];
  final items = <Map<String, dynamic>>[];
  for (final item in list) {
    if (item is Map) {
      final data = Map<String, dynamic>.from(item);
      if (_isActuallyPlayingLive(data)) items.add(data);
    }
  }
  items.sort((a, b) {
    final p = _liveStatusPriority(_friendlyMatchState(a)).compareTo(_liveStatusPriority(_friendlyMatchState(b)));
    if (p != 0) return p;
    return (a['starting_at'] ?? '').toString().compareTo((b['starting_at'] ?? '').toString());
  });
  if (items.isEmpty) return null;
  final rawId = items.first['id'];
  return rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '');
}

Future<ApiFixtureSnapshot> _fetchFixtureSnapshot(int? preferredFixtureId) async {
  var fixtureId = preferredFixtureId ?? selectedFixtureIdNotifier.value;
  fixtureId ??= await _fetchFirstLiveFixtureId();
  if (fixtureId == null) throw Exception('No live match right now');
  selectedFixtureIdNotifier.value = fixtureId;
  final url = Uri.parse('$kSportmonksBaseUrl/fixtures/$fixtureId?api_token=${Uri.encodeComponent(kSportmonksApiToken.trim())}&include=localteam,visitorteam,runs,scoreboards,balls');
  final res = await http.get(url).timeout(const Duration(seconds: 10));
  if (res.statusCode != 200) throw Exception('Fixture ${res.statusCode}');
  final json = jsonDecode(res.body) as Map<String, dynamic>;
  final data = Map<String, dynamic>.from(json['data'] as Map);
  return ApiFixtureSnapshot.fromJson(data);
}

class ApiFixtureBuilder extends StatefulWidget {
  final int? initialFixtureId;
  final Widget Function(BuildContext context, ApiFixtureSnapshot snap) builder;
  const ApiFixtureBuilder({super.key, this.initialFixtureId, required this.builder});

  @override
  State<ApiFixtureBuilder> createState() => _ApiFixtureBuilderState();
}

class _ApiFixtureBuilderState extends State<ApiFixtureBuilder> {
  late Future<ApiFixtureSnapshot> _future;
  int? _currentId;

  @override
  void initState() {
    super.initState();
    _currentId = widget.initialFixtureId ?? selectedFixtureIdNotifier.value;
    _future = _fetchFixtureSnapshot(_currentId);
    selectedFixtureIdNotifier.addListener(_onSelectedChanged);
  }

  @override
  void dispose() {
    selectedFixtureIdNotifier.removeListener(_onSelectedChanged);
    super.dispose();
  }

  void _onSelectedChanged() {
    final next = selectedFixtureIdNotifier.value;
    if (next == null || next == _currentId) return;
    setState(() {
      _currentId = next;
      _future = _fetchFixtureSnapshot(next);
    });
  }

  Future<void> _refresh() async {
    setState(() => _future = _fetchFixtureSnapshot(_currentId ?? selectedFixtureIdNotifier.value));
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<ApiFixtureSnapshot>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return ListView(padding: const EdgeInsets.all(18), children: const [GlassCard(child: Text('Loading selected live match...', style: TextStyle(fontWeight: FontWeight.w900)))]);
          }
          if (snap.hasError || !snap.hasData) {
            return ListView(padding: const EdgeInsets.all(18), children: [GlassCard(child: Text('API error: ${snap.error}', style: const TextStyle(fontWeight: FontWeight.w900)))]);
          }
          return widget.builder(context, snap.data!);
        },
      ),
    );
  }
}

class DynamicApiHeader extends StatelessWidget {
  final ApiFixtureSnapshot snap;
  const DynamicApiHeader({super.key, required this.snap});
  @override
  Widget build(BuildContext context) {
    return LiveApiTeamsHeader(
      localName: snap.localName,
      visitName: snap.visitName,
      localCode: snap.localCode,
      visitCode: snap.visitCode,
      localImage: snap.localImage,
      visitImage: snap.visitImage,
      scoreLine: snap.scoreLine,
      otherLine: snap.otherLine,
    );
  }
}

class DynamicInfoTab extends StatelessWidget {
  final int? initialFixtureId;
  const DynamicInfoTab({super.key, this.initialFixtureId});
  @override
  Widget build(BuildContext context) {
    return ApiFixtureBuilder(
      initialFixtureId: initialFixtureId,
      builder: (context, snap) => ListView(
        padding: EdgeInsets.zero,
        children: [
          DynamicApiHeader(snap: snap),
          Padding(
            padding: const EdgeInsets.fromLTRB(17, 14, 17, 0),
            child: GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(snap.subtitle, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(snap.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                Text(snap.statusText, style: const TextStyle(color: AppColor.cyan, fontSize: 16, fontWeight: FontWeight.w900)),
              ]),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(17, 14, 17, 0),
            child: GlassCard(child: Column(children: [
              ApiInfoRow(icon: Icons.calendar_month, text: 'Start: ${(snap.raw['starting_at'] ?? '--').toString()}'),
              const Divider(color: AppColor.line),
              ApiInfoRow(icon: Icons.thumb_up_alt, text: 'Toss: ${_tossText(snap)}'),
              const Divider(color: AppColor.line),
              ApiInfoRow(icon: Icons.location_on, text: 'Venue ID: ${(snap.raw['venue_id'] ?? '--').toString()}'),
              const Divider(color: AppColor.line),
              ApiInfoRow(icon: Icons.info, text: 'Type: ${(snap.raw['type'] ?? '--').toString()}'),
            ])),
          ),
          const Padding(padding: EdgeInsets.fromLTRB(18, 18, 18, 8), child: Text('Teams', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 17),
            child: GlassCard(child: Column(children: [
              ApiTeamRow(code: snap.localCode, name: snap.localName, image: snap.localImage),
              const Divider(color: AppColor.line),
              ApiTeamRow(code: snap.visitCode, name: snap.visitName, image: snap.visitImage),
            ])),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

String _tossText(ApiFixtureSnapshot snap) {
  final tossId = snap.raw['toss_won_team_id'];
  String team = tossId == null ? 'Not available' : tossId.toString();
  final localId = (snap.raw['localteam'] as Map?)?['id'];
  final visitId = (snap.raw['visitorteam'] as Map?)?['id'];
  if (tossId == localId) team = snap.localName;
  if (tossId == visitId) team = snap.visitName;
  final elected = (snap.raw['elected'] ?? '').toString();
  return elected.isEmpty ? team : '$team opt to $elected';
}

class ApiInfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const ApiInfoRow({super.key, required this.icon, required this.text});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(children: [Icon(icon, color: AppColor.cyan), const SizedBox(width: 12), Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)))]),
    );
  }
}

class ApiTeamRow extends StatelessWidget {
  final String code;
  final String name;
  final String? image;
  const ApiTeamRow({super.key, required this.code, required this.name, required this.image});
  @override
  Widget build(BuildContext context) {
    return Row(children: [_NetTeamLogo(code: code, image: image), const SizedBox(width: 14), Expanded(child: Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))), const Icon(Icons.chevron_right, color: AppColor.muted)]);
  }
}

class DynamicCommentaryTab extends StatelessWidget {
  final int? initialFixtureId;
  const DynamicCommentaryTab({super.key, this.initialFixtureId});
  @override
  Widget build(BuildContext context) {
    return ApiFixtureBuilder(
      initialFixtureId: initialFixtureId,
      builder: (context, snap) {
        final lastBalls = snap.balls.takeLast(40).reversed.toList();
        return ListView(
          padding: EdgeInsets.zero,
          children: [
            DynamicApiHeader(snap: snap),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 14, 17, 0),
              child: GlassCard(child: Text('${snap.statusText}. ${snap.scoreLine}.', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, height: 1.35))),
            ),
            Padding(padding: const EdgeInsets.fromLTRB(17, 14, 17, 0), child: GlassCard(child: Text(snap.latestEvent.toUpperCase(), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)))),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 14, 17, 0),
              child: GlassCard(
                child: Row(children: [
                  Text(snap.scoreLine, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                  const Spacer(),
                  Text(snap.overLabel, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w900)),
                ]),
              ),
            ),
            if (lastBalls.isEmpty)
              const Padding(padding: EdgeInsets.all(17), child: GlassCard(child: Text('Ball-by-ball data loading from API...', style: TextStyle(fontWeight: FontWeight.w900))))
            else
              for (final ball in lastBalls) ApiCommentaryLine(ball: ball),
            const SizedBox(height: 20),
          ],
        );
      },
    );
  }
}

class ApiCommentaryLine extends StatelessWidget {
  final Map<String, dynamic> ball;
  const ApiCommentaryLine({super.key, required this.ball});
  @override
  Widget build(BuildContext context) {
    final code = _apiBallCode(ball);
    final score = Map<String, dynamic>.from((ball['score'] as Map?) ?? const {});
    final batsman = Map<String, dynamic>.from((ball['batsman'] as Map?) ?? const {});
    final bowler = Map<String, dynamic>.from((ball['bowler'] as Map?) ?? const {});
    final batsmanName = (batsman['fullname'] ?? 'Batter').toString();
    final bowlerName = (bowler['fullname'] ?? 'Bowler').toString();
    final ballNo = (ball['ball'] ?? '--').toString();
    final result = _apiVoiceText(code);
    final rawName = (score['name'] ?? '').toString();
    final text = '$bowlerName to $batsmanName: $result${rawName.isEmpty ? '' : ' • $rawName'}';
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 12, 17, 0),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 42, child: Text(ballNo, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColor.muted))),
        BallCircle(text: code),
        const SizedBox(width: 12),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, height: 1.32))),
      ]),
    );
  }
}

class DynamicScorecardTab extends StatelessWidget {
  final int? initialFixtureId;
  const DynamicScorecardTab({super.key, this.initialFixtureId});
  @override
  Widget build(BuildContext context) {
    return ApiFixtureBuilder(
      initialFixtureId: initialFixtureId,
      builder: (context, snap) {
        final batting = _calculateBattingStats(snap.balls);
        final bowling = _calculateBowlingStats(snap.balls);
        return ListView(
          padding: EdgeInsets.zero,
          children: [
            DynamicApiHeader(snap: snap),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 14, 17, 0),
              child: GlassCard(child: Row(children: [
                Expanded(child: Text(snap.scoreLine, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
                Text(snap.statusText, style: const TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900)),
              ])),
            ),
            const Padding(padding: EdgeInsets.fromLTRB(18, 18, 18, 8), child: Text('Batter', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 17),
              child: GlassCard(padding: EdgeInsets.zero, child: ApiStatsTable(headers: const ['Batter', 'R', 'B', '4s', '6s'], rows: batting)),
            ),
            const Padding(padding: EdgeInsets.fromLTRB(18, 18, 18, 8), child: Text('Bowler', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 17),
              child: GlassCard(padding: EdgeInsets.zero, child: ApiStatsTable(headers: const ['Bowler', 'O', 'R', 'W', 'ER'], rows: bowling)),
            ),
            const Padding(padding: EdgeInsets.fromLTRB(18, 18, 18, 8), child: Text('Runs / Innings', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 17),
              child: GlassCard(child: Column(children: [
                if (snap.runs.isEmpty) const Text('Runs data loading...', style: TextStyle(color: AppColor.muted))
                else for (final run in snap.runs) ApiInfoRow(icon: Icons.scoreboard, text: 'Team ${run['team_id']} • ${_asIntStatic(run['score'])}-${_asIntStatic(run['wickets'])} (${_formatOversStatic(run['overs'])})'),
              ])),
            ),
            const SizedBox(height: 20),
          ],
        );
      },
    );
  }
}

List<List<String>> _calculateBattingStats(List<Map<String, dynamic>> balls) {
  final stats = <int, Map<String, dynamic>>{};
  for (final ball in balls) {
    final batsman = Map<String, dynamic>.from((ball['batsman'] as Map?) ?? const {});
    final id = _asIntStatic(batsman['id'] ?? ball['batsman_id']);
    if (id == 0) continue;
    final name = (batsman['fullname'] ?? 'Batter $id').toString();
    final score = Map<String, dynamic>.from((ball['score'] as Map?) ?? const {});
    final code = _apiBallCode(ball);
    final item = stats.putIfAbsent(id, () => {'name': name, 'r': 0, 'b': 0, '4': 0, '6': 0});
    if (score['ball'] == true) item['b'] = (item['b'] as int) + 1;
    if (code != 'WD' && code != 'NB') item['r'] = (item['r'] as int) + _asIntStatic(score['runs']);
    if (code == '4') item['4'] = (item['4'] as int) + 1;
    if (code == '6') item['6'] = (item['6'] as int) + 1;
  }
  final rows = stats.values.map((s) => [s['name'].toString(), s['r'].toString(), s['b'].toString(), s['4'].toString(), s['6'].toString()]).toList();
  rows.sort((a, b) => int.parse(b[1]).compareTo(int.parse(a[1])));
  return rows.isEmpty ? const [['Data loading', '--', '--', '--', '--']] : rows;
}

List<List<String>> _calculateBowlingStats(List<Map<String, dynamic>> balls) {
  final stats = <int, Map<String, dynamic>>{};
  for (final ball in balls) {
    final bowler = Map<String, dynamic>.from((ball['bowler'] as Map?) ?? const {});
    final id = _asIntStatic(bowler['id'] ?? ball['bowler_id']);
    if (id == 0) continue;
    final name = (bowler['fullname'] ?? 'Bowler $id').toString();
    final score = Map<String, dynamic>.from((ball['score'] as Map?) ?? const {});
    final item = stats.putIfAbsent(id, () => {'name': name, 'balls': 0, 'r': 0, 'w': 0});
    if (score['ball'] == true) item['balls'] = (item['balls'] as int) + 1;
    item['r'] = (item['r'] as int) + _asIntStatic(score['runs']);
    if (score['is_wicket'] == true || score['out'] == true) item['w'] = (item['w'] as int) + 1;
  }
  final rows = stats.values.map((s) {
    final balls = s['balls'] as int;
    final overs = '${balls ~/ 6}.${balls % 6}';
    final runs = s['r'] as int;
    final er = balls == 0 ? '--' : (runs / (balls / 6)).toStringAsFixed(2);
    return [s['name'].toString(), overs, runs.toString(), s['w'].toString(), er];
  }).toList();
  rows.sort((a, b) => a[0].compareTo(b[0]));
  return rows.isEmpty ? const [['Data loading', '--', '--', '--', '--']] : rows;
}

class ApiStatsTable extends StatelessWidget {
  final List<String> headers;
  final List<List<String>> rows;
  const ApiStatsTable({super.key, required this.headers, required this.rows});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(
        color: AppColor.header,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        child: Row(children: [for (final h in headers) Expanded(flex: h == headers.first ? 3 : 1, child: Text(h, style: const TextStyle(fontWeight: FontWeight.w900)))]),
      ),
      for (final r in rows)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(children: [for (var i = 0; i < headers.length; i++) Expanded(flex: i == 0 ? 3 : 1, child: Text(i < r.length ? r[i] : '', style: const TextStyle(fontWeight: FontWeight.w800)))]),
        ),
    ]);
  }
}

class LiveMatchSummary {
  final int id;
  final String title;
  final String subtitle;
  final String status;
  final String score;

  const LiveMatchSummary({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.status,
    required this.score,
  });
}

class LiveMatchSelector extends StatelessWidget {
  final List<LiveMatchSummary> matches;
  final int? selectedFixtureId;
  final ValueChanged<int> onSelect;

  const LiveMatchSelector({
    super.key,
    required this.matches,
    required this.selectedFixtureId,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColor.card2,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColor.line),
      ),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.sports_cricket, color: AppColor.cyan, size: 20),
              SizedBox(width: 8),
              Text('All Live Matches', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 96,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: matches.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final match = matches[index];
                final selected = match.id == selectedFixtureId;
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => onSelect(match.id),
                  child: Container(
                    width: 210,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: selected ? AppColor.card : AppColor.bg2,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: selected ? AppColor.cyan : AppColor.line, width: selected ? 1.5 : 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            if (selected) const Icon(Icons.play_circle_fill, color: AppColor.cyan, size: 16),
                            if (selected) const SizedBox(width: 5),
                            Expanded(
                              child: Text(
                                match.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          match.score,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppColor.green, fontWeight: FontWeight.w900, fontSize: 13),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          match.status,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700, fontSize: 12),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          match.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppColor.muted, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Tap any match to switch. Rain/stumps/break also shown. Auto refresh every 4 sec.',
            style: TextStyle(color: AppColor.muted, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class LiveApiTeamsHeader extends StatelessWidget {
  final String localName;
  final String visitName;
  final String localCode;
  final String visitCode;
  final String? localImage;
  final String? visitImage;
  final String scoreLine;
  final String otherLine;

  const LiveApiTeamsHeader({
    super.key,
    required this.localName,
    required this.visitName,
    required this.localCode,
    required this.visitCode,
    required this.localImage,
    required this.visitImage,
    required this.scoreLine,
    required this.otherLine,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(3, 12, 3, 8),
      child: Row(
        children: [
          _NetTeamLogo(code: localCode, image: localImage),
          const SizedBox(width: 12),
          Expanded(child: Text('$scoreLine\n$localCode', style: const TextStyle(fontWeight: FontWeight.w900, height: 1.35))),
          const Icon(Icons.flash_on, color: AppColor.text, size: 28),
          Expanded(child: Text('$otherLine\n$visitCode', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.35))),
          const SizedBox(width: 12),
          _NetTeamLogo(code: visitCode, image: visitImage),
        ],
      ),
    );
  }
}

class _NetTeamLogo extends StatelessWidget {
  final String code;
  final String? image;
  const _NetTeamLogo({required this.code, required this.image});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      CircleAvatar(
        radius: 31,
        backgroundColor: AppColor.card2,
        backgroundImage: (image == null || image!.isEmpty) ? null : NetworkImage(image!),
        child: (image == null || image!.isEmpty) ? Text(code.substring(0, code.length < 3 ? code.length : 3), style: const TextStyle(fontWeight: FontWeight.w900)) : null,
      ),
      const SizedBox(height: 6),
      Text(code, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
    ]);
  }
}


class TvLiveBox extends StatelessWidget {
  final String eventText;
  final bool soundOn;
  final String battingCode;
  final String bowlingCode;
  final String scoreLine;
  final String otherLine;

  const TvLiveBox({
    super.key,
    required this.eventText,
    required this.soundOn,
    required this.battingCode,
    required this.bowlingCode,
    required this.scoreLine,
    required this.otherLine,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 215,
      decoration: BoxDecoration(color: Colors.black, border: Border.all(color: AppColor.header, width: 5)),
      child: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                Positioned(left: 14, top: 14, child: Icon(soundOn ? Icons.volume_up : Icons.volume_off, color: Colors.white)),
                const Positioned(right: 14, top: 14, child: Row(children: [CircleAvatar(radius: 4, backgroundColor: Colors.red), SizedBox(width: 4), Text('Live')])),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Text(
                      eventText.toUpperCase(),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
                Positioned(left: 18, bottom: 18, child: Text(bowlingCode, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.muted))),
                Positioned(right: 18, bottom: 18, child: Text(battingCode, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.muted))),
              ],
            ),
          ),
          DecoratedBox(
            decoration: const BoxDecoration(color: AppColor.card2),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              child: Row(children: [
                Expanded(child: Text(scoreLine, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
                Text(otherLine, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w900)),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}


class SoundControlCard extends StatelessWidget {
  final bool soundOn;
  final bool apiAutoOn;
  final String apiStatus;
  final VoidCallback onToggle;
  final VoidCallback onAutoToggle;
  final VoidCallback onRefresh;

  const SoundControlCard({
    super.key,
    required this.soundOn,
    required this.apiAutoOn,
    required this.apiStatus,
    required this.onToggle,
    required this.onAutoToggle,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(soundOn ? Icons.volume_up : Icons.volume_off, color: AppColor.cyan),
          const SizedBox(width: 8),
          const Expanded(child: Text('Cricket Voice Sound', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          Switch(value: soundOn, onChanged: (_) => onToggle()),
        ]),
        const SizedBox(height: 6),
        Row(children: [
          const Icon(Icons.cloud_sync, color: AppColor.yellow),
          const SizedBox(width: 8),
          const Expanded(child: Text('Real API Auto Ball-by-Ball', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15))),
          Switch(value: apiAutoOn, onChanged: (_) => onAutoToggle()),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: Text(apiStatus, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700, height: 1.35))),
          IconButton(onPressed: onRefresh, icon: const Icon(Icons.refresh, color: AppColor.cyan)),
        ]),
      ]),
    );
  }
}


class BallStrip extends StatelessWidget {
  final List<String> balls;
  final String overLabel;
  const BallStrip({super.key, required this.balls, required this.overLabel});

  @override
  Widget build(BuildContext context) {
    final showBalls = balls.isEmpty ? const ['LIVE'] : balls;
    return GlassCard(
      padding: const EdgeInsets.all(10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            for (final b in showBalls) BallCircle(text: b),
            const SizedBox(height: 38, child: VerticalDivider(color: AppColor.line, thickness: 1)),
            const SizedBox(width: 8),
            Text(overLabel, style: const TextStyle(fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }
}

class BallCircle extends StatelessWidget {
  final String text;
  const BallCircle({super.key, required this.text});
  @override
  Widget build(BuildContext context) {
    Color bg = AppColor.green;
    final t = text.toUpperCase();
    if (t == '4') bg = AppColor.blue;
    if (t == '6') bg = AppColor.purple;
    if (t == 'W') bg = AppColor.red;
    if (t == 'WD' || t == 'NB' || t == 'LIVE') bg = AppColor.card2;
    return Container(
      margin: const EdgeInsets.only(right: 6),
      width: 42,
      height: 42,
      decoration: BoxDecoration(shape: BoxShape.circle, color: bg, border: Border.all(color: Colors.white24)),
      child: Center(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13))),
    );
  }
}

class BallEmpty extends StatelessWidget {
  const BallEmpty({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(margin: const EdgeInsets.only(right: 6), width: 42, height: 42, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColor.muted)));
  }
}


class LiveStatsCard extends StatelessWidget {
  final String runRateText;
  final String ballsRemainingText;
  const LiveStatsCard({super.key, required this.runRateText, required this.ballsRemainingText});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Row(children: [
      Expanded(child: Text(runRateText, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
      Text(ballsRemainingText, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
    ]));
  }
}

class WinProbCard extends StatelessWidget {
  final String leftCode;
  final String rightCode;
  final int leftPct;
  final int rightPct;
  final String sixOverProjection;
  final String fullOverProjection;
  const WinProbCard({super.key, required this.leftCode, required this.rightCode, required this.leftPct, required this.rightPct, required this.sixOverProjection, required this.fullOverProjection});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Expanded(child: Text('Win Probability  ⓘ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        Text('$leftCode:', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
        const SizedBox(width: 6),
        OddBox('$leftPct%', color: AppColor.red),
        const SizedBox(width: 6),
        Text('$rightCode:', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
        const SizedBox(width: 6),
        OddBox('$rightPct%', color: AppColor.green),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: Text(sixOverProjection, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w900))),
        Expanded(child: Text(fullOverProjection, textAlign: TextAlign.right, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w900))),
      ]),
    ]));
  }
}

class BatterCard extends StatelessWidget {
  const BatterCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const GlassCard(child: Column(children: [
      ScoreHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']),
      ScoreDataRow(cols: ['Sarah Bryce 🏏', '47', '33', '6', '0', '142.42']),
      ScoreDataRow(cols: ['Megan McColl', '1', '1', '0', '0', '100.0']),
      Divider(color: AppColor.line),
      Row(children: [Expanded(child: Text("P'ship: 48(34)", style: TextStyle(color: AppColor.muted))), Text("L' Wkt: Pippa Sproul 0(1)", style: TextStyle(color: AppColor.muted))]),
    ]));
  }
}

class BowlerCard extends StatelessWidget {
  const BowlerCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const GlassCard(child: Column(children: [
      ScoreHeader(cols: ['Bowler', 'O', 'M', 'R', 'W', 'ER']),
      ScoreDataRow(cols: ['Mithali Ayodhya 🎾', '4.0', '0', '34', '2', '8.5']),
    ]));
  }
}

class CommentaryTab extends StatelessWidget {
  const CommentaryTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: const [
        MatchTeamsHeader(scores: true),
        Padding(
          padding: EdgeInsets.fromLTRB(17, 14, 17, 0),
          child: GlassCard(
            child: Text(
              '7:55pm Local Time, 12:25am IST : Scotland have done a great job by posting 151 on the board. Darcey Carter again looked good at the top while Sarah Bryce held the innings together with a brisk 33-ball 47. It is now down to Sri Lanka Women to chase this down.',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, height: 1.35),
            ),
          ),
        ),
        Padding(padding: EdgeInsets.fromLTRB(17, 14, 17, 0), child: GlassCard(child: Text('INNINGS BREAK.', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)))),
        OverSummaryCard(),
        CommentaryLine(over: '19.6', run: '4', text: 'Mithali Ayodhya to Sarah Bryce: Four. Scotland Women finish on 151! Length ball on off, makes room and cuts it wide of extra cover for a boundary'),
        CommentaryLine(over: '19.5', run: '1', text: 'Mithali Ayodhya to Megan McColl: One Run. Full ball outside off, drives it uppishly and straight back.'),
        PlayerHighlightCard(title: 'New batter on crease', name: 'Pippa Sproul', stat1: '3\nMatches', stat2: '30\nRuns'),
        CommentaryLine(over: '19.4', run: 'W', text: 'Mithali Ayodhya to Pippa Sproul: Bowled!. No Run. Full ball on middle and leg, steps across and looks to scoop but misses.'),
        CommentaryLine(over: '19.3', run: '1', text: 'Mithali Ayodhya to Sarah Bryce: One Run. Low full toss on leg, flicks it to deep square leg.'),
        CommentaryLine(over: '19.2', run: '2', text: 'Mithali Ayodhya to Sarah Bryce: Two Runs. Full ball on leg, flicks it wide of long on for a quick couple.'),
        CommentaryLine(over: '19.1', run: '4', text: 'Mithali Ayodhya to Sarah Bryce: Four. Back of length ball outside off, slashes it away over backward point for a boundary.'),
        CommentaryLine(over: '19.1', run: 'wd', text: 'Mithali Ayodhya to Sarah Bryce: Wide Ball. One Run.'),
        PlayerHighlightCard(title: 'Batting - T20 Career', name: 'Sarah Bryce', stat1: '87.01\nStrike Rate', stat2: '11.17\nAvg'),
        SizedBox(height: 20),
      ],
    );
  }
}

class OverSummaryCard extends StatelessWidget {
  const OverSummaryCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(17, 14, 17, 0),
      child: GlassCard(
        child: Row(children: [
          SizedBox(width: 128, height: 90, child: DecoratedBox(
            decoration: BoxDecoration(color: AppColor.bg2, borderRadius: BorderRadius.all(Radius.circular(8))),
            child: Center(child: Text('151-6\nSCOW', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))),
          )),
          SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('End of 20th over: WD 4 2 1 WK 1 4 (13 RUNS)', style: TextStyle(fontWeight: FontWeight.w900)),
            Divider(color: AppColor.line),
            Row(children: [Expanded(child: Text('Sarah Bryce')), Text('47 (33)', style: TextStyle(fontWeight: FontWeight.w900))]),
            SizedBox(height: 8),
            Row(children: [Expanded(child: Text('Megan McColl')), Text('1 (1)', style: TextStyle(fontWeight: FontWeight.w900))]),
            SizedBox(height: 8),
            Row(children: [Expanded(child: Text('Mithali Ayodhya')), Text('4.0-0-34-2', style: TextStyle(fontWeight: FontWeight.w900))]),
          ])),
        ]),
      ),
    );
  }
}

class CommentaryLine extends StatelessWidget {
  final String over;
  final String run;
  final String text;
  const CommentaryLine({super.key, required this.over, required this.run, required this.text});
  @override
  Widget build(BuildContext context) {
    Color bg = AppColor.green;
    if (run == '4') bg = AppColor.blue;
    if (run == 'W') bg = AppColor.red;
    if (run == 'wd') bg = AppColor.card2;
    return Padding(
      padding: const EdgeInsets.fromLTRB(34, 18, 34, 0),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 56, child: Column(children: [
          Text(over, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          CircleAvatar(backgroundColor: bg, child: Text(run, style: const TextStyle(fontWeight: FontWeight.w900))),
        ])),
        const SizedBox(width: 12),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 17, height: 1.35, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}

class PlayerHighlightCard extends StatelessWidget {
  final String title;
  final String name;
  final String stat1;
  final String stat2;
  const PlayerHighlightCard({super.key, required this.title, required this.name, required this.stat1, required this.stat2});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 16, 17, 0),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: const LinearGradient(colors: [Color(0xFF433A82), Color(0xFF7B1238)]),
        ),
        child: Row(children: [
          Container(width: 58, height: 58, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.person, color: AppColor.bg, size: 42)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const Text('Right Handed Bat', style: TextStyle(color: Colors.white70)),
          ])),
          Text(stat1, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.35)),
          const SizedBox(width: 16),
          Text(stat2, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.35)),
        ]),
      ),
    );
  }
}

class ScorecardTab extends StatelessWidget {
  const ScorecardTab({super.key});
  @override
  Widget build(BuildContext context) {
    final batters = [
      ['Darcey Carter', 'c Kaushani Nuthyangana b Sugandika Kumari', '34', '36', '5', '0', '94.44'],
      ['Katherine Fraser', 'c Nilakshi de Silva b Mithali Ayodhya', '12', '9', '2', '0', '133.33'],
      ['Kathryn Bryce', 'c & b Kavisha Dilhari', '23', '23', '3', '1', '100.0'],
      ['Sarah Bryce', 'Not Out', '47', '33', '6', '0', '142.42'],
      ['Ailsa Lister', 'runout (Nilakshi de Silva)', '26', '17', '4', '0', '152.94'],
      ['Priyanaz Chatterji', 'runout (Harshitha Samarawickrama)', '0', '0', '0', '0', '0.0'],
      ['Pippa Sproul', 'b Mithali Ayodhya', '0', '1', '0', '0', '0.0'],
      ['Megan McColl', 'Not Out', '1', '1', '0', '0', '100.0'],
    ];
    final bowlers = [
      ['Mithali Ayodhya', '4.0', '0', '34', '2', '8.5'],
      ['Sugandika Kumari', '4.0', '0', '28', '1', '7.0'],
      ['Kavisha Dilhari', '4.0', '0', '31', '1', '7.75'],
      ['Inoshi Priyadharshani', '4.0', '0', '24', '0', '6.0'],
    ];
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const MatchTeamsHeader(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 17),
          child: Column(
            children: [
              const InningsScoreHeader(team: 'Scotland Women', score: '151/6 (20.0)', open: true),
              Container(
                color: AppColor.card,
                child: Column(
                  children: [
                    const ScoreHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']),
                    for (final b in batters) BatterScoreLine(name: b[0], sub: b[1], r: b[2], balls: b[3], fours: b[4], sixes: b[5], sr: b[6], active: b[1] == 'Not Out'),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(16, 10, 16, 8),
                      child: Row(children: [Text('Extras:', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Spacer(), Text('8 (0 b, 1 lb, 7 wd, 0 nb, 0 p)', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800))]),
                    ),
                    const Divider(color: AppColor.line, height: 1),
                    const Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Did not bat', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                        SizedBox(height: 8),
                        Text('Rachel Slater, Kirstie Gordon, Gabriella Fontenla', style: TextStyle(height: 1.35, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                    const ScoreHeader(cols: ['Bowler', 'O', 'M', 'R', 'W', 'ER']),
                    for (final b in bowlers) BowlerScoreLine(name: b[0], o: b[1], m: b[2], r: b[3], w: b[4], er: b[5]),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

class InningsScoreHeader extends StatelessWidget {
  final String team;
  final String score;
  final bool open;
  const InningsScoreHeader({super.key, required this.team, required this.score, required this.open});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      color: AppColor.card2,
      child: Row(children: [
        Expanded(child: Text(team, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        Text(score, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(width: 8),
        Icon(open ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down),
      ]),
    );
  }
}

class ScoreHeader extends StatelessWidget {
  final List<String> cols;
  const ScoreHeader({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.header,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(children: [
        Expanded(flex: 5, child: Text(cols[0], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
        for (int i = 1; i < cols.length; i++) Expanded(child: Text(cols[i], textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
      ]),
    );
  }
}

class BatterScoreLine extends StatelessWidget {
  final String name;
  final String sub;
  final String r;
  final String balls;
  final String fours;
  final String sixes;
  final String sr;
  final bool active;
  const BatterScoreLine({super.key, required this.name, required this.sub, required this.r, required this.balls, required this.fours, required this.sixes, required this.sr, this.active = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(border: Border(left: BorderSide(color: active ? AppColor.cyan : Colors.transparent, width: 4))),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 9),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 5, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text(sub, style: const TextStyle(color: Color(0xFF8EE4FF), height: 1.25)),
        ])),
        Expanded(child: Text(r, textAlign: TextAlign.right)),
        Expanded(child: Text(balls, textAlign: TextAlign.right)),
        Expanded(child: Text(fours, textAlign: TextAlign.right)),
        Expanded(child: Text(sixes, textAlign: TextAlign.right)),
        Expanded(child: Text(sr, textAlign: TextAlign.right)),
      ]),
    );
  }
}

class BowlerScoreLine extends StatelessWidget {
  final String name;
  final String o;
  final String m;
  final String r;
  final String w;
  final String er;
  const BowlerScoreLine({super.key, required this.name, required this.o, required this.m, required this.r, required this.w, required this.er});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 9),
      child: Row(children: [
        Expanded(flex: 5, child: Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
        Expanded(child: Text(o, textAlign: TextAlign.right)),
        Expanded(child: Text(m, textAlign: TextAlign.right)),
        Expanded(child: Text(r, textAlign: TextAlign.right)),
        Expanded(child: Text(w, textAlign: TextAlign.right)),
        Expanded(child: Text(er, textAlign: TextAlign.right)),
      ]),
    );
  }
}

class ScoreDataRow extends StatelessWidget {
  final List<String> cols;
  const ScoreDataRow({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(children: [
        Expanded(flex: 5, child: Text(cols[0], style: const TextStyle(fontWeight: FontWeight.w800))),
        for (int i = 1; i < cols.length; i++) Expanded(child: Text(cols[i], textAlign: TextAlign.right)),
      ]),
    );
  }
}

class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key});
  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  int expanded = 20;

  @override
  Widget build(BuildContext context) {
    final overs = [
      [20, '13 runs, 1 w', 'SCOW: 151-6'],
      [19, '9 runs', 'SCOW: 138-5'],
      [18, '10 runs', 'SCOW: 129-5'],
      [17, '8 runs', 'SCOW: 119-4'],
      [16, '11 runs', 'SCOW: 111-4'],
      [15, '5 runs', 'SCOW: 100-3'],
      [14, '16 runs', 'SCOW: 95-3'],
      [13, '7 runs', 'SCOW: 84-2'],
      [12, '3 runs', 'SCOW: 77-2'],
      [11, '7 runs', 'SCOW: 74-2'],
      [10, '2 runs, 1 w', 'SCOW: 67-2'],
      [9, '11 runs', 'SCOW: 65-1'],
      [8, '3 runs', 'SCOW: 54-1'],
      [7, '6 runs', 'SCOW: 51-1'],
      [6, '6 runs', 'SCOW: 45-1'],
      [5, '10 runs, 1 w', 'SCOW: 39-1'],
      [4, '4 runs', 'SCOW: 29-0'],
      [3, '4 runs', 'SCOW: 25-0'],
      [2, '14 runs', 'SCOW: 21-0'],
    ];
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const MatchTeamsHeader(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 10),
          child: Row(children: const [Expanded(child: Pill('1st Innings', selected: true))]),
        ),
        for (final o in overs) OverHistoryTile(
          over: o[0] as int,
          runs: o[1] as String,
          score: o[2] as String,
          expanded: expanded == o[0],
          onTap: () => setState(() => expanded = expanded == o[0] ? -1 : o[0] as int),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

class OverHistoryTile extends StatelessWidget {
  final int over;
  final String runs;
  final String score;
  final bool expanded;
  final VoidCallback onTap;
  const OverHistoryTile({super.key, required this.over, required this.runs, required this.score, required this.expanded, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final balls = [
      ['19.6', '4', '151 - 6', '12:24 AM'],
      ['19.5', '1', '147 - 6', '12:23 AM'],
      ['19.4', 'W', '146 - 6', '12:22 AM'],
      ['19.3', '1', '146 - 5', '12:21 AM'],
      ['19.2', '2', '145 - 5', '12:21 AM'],
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 0, 17, 12),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(
          children: [
            InkWell(
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(children: [
                  Text('${over}th Over : ', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  Text(runs, style: const TextStyle(fontSize: 16, color: AppColor.muted, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  Text(score, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  const SizedBox(width: 8),
                  Icon(expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down),
                ]),
              ),
            ),
            if (expanded) ...[
              const Divider(height: 1, color: AppColor.line),
              for (final b in balls) HistoryBallLine(ball: b[0], run: b[1], score: b[2], time: b[3], marketOver: '${over} Over'),
            ],
          ],
        ),
      ),
    );
  }
}

class HistoryBallLine extends StatelessWidget {
  final String ball;
  final String run;
  final String score;
  final String time;
  final String marketOver;
  const HistoryBallLine({super.key, required this.ball, required this.run, required this.score, required this.time, required this.marketOver});
  @override
  Widget build(BuildContext context) {
    Color color = AppColor.green;
    if (run == '4') color = AppColor.blue;
    if (run == 'W') color = AppColor.red;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(children: [
        Column(children: [
          CircleAvatar(backgroundColor: color, child: Text(run, style: const TextStyle(fontWeight: FontWeight.w900))),
          const SizedBox(height: 6),
          Text(time, style: const TextStyle(color: AppColor.muted, fontSize: 12)),
        ]),
        const SizedBox(width: 16),
        Expanded(child: Row(children: [
          Text(score, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(width: 6),
          Text(ball, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)),
        ])),
        Column(children: [
          Row(children: [
            OddBox(marketOver, light: true),
            SizedBox(width: 6),
            OddBox('148', color: AppColor.red),
            SizedBox(width: 6),
            OddBox('149', color: AppColor.green),
          ]),
        ]),
      ]),
    );
  }
}

class OddBox extends StatelessWidget {
  final String text;
  final Color color;
  final bool light;
  const OddBox(this.text, {super.key, this.color = AppColor.card2, this.light = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: text.length > 4 ? 64 : 48,
      height: 34,
      decoration: BoxDecoration(color: light ? Colors.white : color, borderRadius: BorderRadius.circular(6), border: Border.all(color: AppColor.line)),
      child: Center(child: Text(text, style: TextStyle(color: light ? AppColor.bg : Colors.white, fontWeight: FontWeight.w900, fontSize: 13))),
    );
  }
}

class PointsTableTab extends StatelessWidget {
  const PointsTableTab({super.key});
  @override
  Widget build(BuildContext context) {
    final groupA = [
      ['AUSW', '4', '4', '0', '0', '0', '8', '4.724'],
      ['INDW', '4', '3', '1', '0', '0', '6', '2.268'],
      ['RSAW', '4', '3', '1', '0', '0', '6', '0.734'],
      ['BANW', '4', '2', '2', '0', '0', '4', '-0.849'],
      ['PAKW', '4', '0', '4', '0', '0', '0', '-2.831'],
      ['NEDW', '4', '0', '4', '0', '0', '0', '-3.64'],
    ];
    final groupB = [
      ['ENGW', '4', '4', '0', '0', '0', '8', '2.342'],
      ['WIW', '4', '3', '1', '0', '0', '6', '0.008'],
      ['NZW', '4', '2', '2', '0', '0', '4', '0.122'],
      ['SLW', '4', '2', '2', '0', '0', '4', '-0.031'],
      ['SCOW', '4', '1', '3', '0', '0', '2', '-0.956'],
    ];
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const SizedBox(height: 24),
        const Center(child: Text('Group A', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
        const PointsHeader(),
        for (final r in groupA) PointsRow(row: r),
        const SizedBox(height: 22),
        const Center(child: Text('Group B', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
        const PointsHeader(),
        for (final r in groupB) PointsRow(row: r),
        const SizedBox(height: 20),
      ],
    );
  }
}

class PointsHeader extends StatelessWidget {
  const PointsHeader({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.header,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      margin: const EdgeInsets.only(top: 14),
      child: const Row(children: [
        Expanded(flex: 4, child: Text('Teams', style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('P', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('W', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('L', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('T', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('NR', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('PTS', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(flex: 2, child: Text('NRR', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
      ]),
    );
  }
}

class PointsRow extends StatelessWidget {
  final List<String> row;
  const PointsRow({super.key, required this.row});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.card,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      child: Row(children: [
        Expanded(flex: 4, child: Row(children: [
          TeamLogo(code: row[0], size: 34, showCode: false),
          const SizedBox(width: 10),
          Expanded(child: Text(row[0], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
        ])),
        for (int i = 1; i <= 6; i++) Expanded(child: Text(row[i], textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
        Expanded(flex: 2, child: Text(row[7], textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}


class AppPost {
  final String name;
  final String title;
  final String message;
  final String imageUrl;
  final String imageBase64;
  final String imageType;
  final String linkUrl;
  final bool active;
  final int createdAt;

  const AppPost({
    required this.name,
    required this.title,
    required this.message,
    required this.imageUrl,
    required this.imageBase64,
    required this.imageType,
    required this.linkUrl,
    required this.active,
    required this.createdAt,
  });

  String get shortId => name.split('/').isEmpty ? name : name.split('/').last;

  factory AppPost.fromFirestore(Map<String, dynamic> doc) {
    final fields = (doc['fields'] as Map<String, dynamic>?) ?? {};
    String stringValue(String key) {
      final value = fields[key];
      if (value is Map && value['stringValue'] != null) return value['stringValue'].toString();
      if (value is Map && value['integerValue'] != null) return value['integerValue'].toString();
      if (value is Map && value['booleanValue'] != null) return value['booleanValue'].toString();
      return '';
    }

    bool boolValue(String key, {bool fallback = true}) {
      final value = fields[key];
      if (value is Map && value['booleanValue'] != null) return value['booleanValue'] == true;
      return fallback;
    }

    int intValue(String key) {
      final value = fields[key];
      if (value is Map && value['integerValue'] != null) return int.tryParse(value['integerValue'].toString()) ?? 0;
      if (value is Map && value['stringValue'] != null) return int.tryParse(value['stringValue'].toString()) ?? 0;
      return 0;
    }

    return AppPost(
      name: (doc['name'] ?? '').toString(),
      title: stringValue('title'),
      message: stringValue('message'),
      imageUrl: stringValue('imageUrl'),
      imageBase64: stringValue('imageBase64'),
      imageType: stringValue('imageType').isEmpty ? 'image/jpeg' : stringValue('imageType'),
      linkUrl: stringValue('linkUrl'),
      active: boolValue('active'),
      createdAt: intValue('createdAt'),
    );
  }
}

class AdminPostsApi {
  static const String projectId = 'allrounder99-806a4';
  static const String adminPin = 'A99@2026';
  static const String _base = 'https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents';

  static Future<List<AppPost>> fetchPosts() async {
    final uri = Uri.parse('$_base/posts?pageSize=50');
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode == 404) return <AppPost>[];
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Posts connect nahi hua (${res.statusCode})');
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    final docs = (body['documents'] as List?) ?? const [];
    final posts = docs
        .whereType<Map<String, dynamic>>()
        .map(AppPost.fromFirestore)
        .where((post) => post.active && (post.title.trim().isNotEmpty || post.message.trim().isNotEmpty))
        .toList();
    posts.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return posts;
  }

  static Map<String, dynamic> _fields({
    required String title,
    required String message,
    required String imageUrl,
    required bool active,
    required int createdAt,
  }) {
    return {
      'title': {'stringValue': title.trim()},
      'message': {'stringValue': message.trim()},
      'imageUrl': {'stringValue': imageUrl.trim()},
      'active': {'booleanValue': active},
      'createdAt': {'integerValue': createdAt.toString()},
      'adminPin': {'stringValue': adminPin},
    };
  }

  static Future<void> savePost({
    AppPost? existing,
    required String title,
    required String message,
    required String imageUrl,
    bool active = true,
  }) async {
    final createdAt = existing?.createdAt == 0 || existing == null ? DateTime.now().millisecondsSinceEpoch : existing.createdAt;
    final payload = jsonEncode({
      'fields': _fields(title: title, message: message, imageUrl: imageUrl, active: active, createdAt: createdAt),
    });

    final http.Response res;
    if (existing == null) {
      res = await http.post(
        Uri.parse('$_base/posts'),
        headers: const {'Content-Type': 'application/json'},
        body: payload,
      ).timeout(const Duration(seconds: 15));
    } else {
      const masks = 'updateMask.fieldPaths=title&updateMask.fieldPaths=message&updateMask.fieldPaths=imageUrl&updateMask.fieldPaths=active&updateMask.fieldPaths=createdAt&updateMask.fieldPaths=adminPin';
      res = await http.patch(
        Uri.parse('https://firestore.googleapis.com/v1/${existing.name}?$masks'),
        headers: const {'Content-Type': 'application/json'},
        body: payload,
      ).timeout(const Duration(seconds: 15));
    }

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Upload failed (${res.statusCode}). Firebase rules check karo.');
    }
  }
}

class AdminPostsPreview extends StatefulWidget {
  const AdminPostsPreview({super.key});

  @override
  State<AdminPostsPreview> createState() => _AdminPostsPreviewState();
}

class _AdminPostsPreviewState extends State<AdminPostsPreview> {
  List<AppPost> posts = const [];
  String? error;
  bool loading = true;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _load();
    timer = Timer.periodic(const Duration(seconds: 18), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent && mounted) setState(() => loading = true);
    try {
      final data = await AdminPostsApi.fetchPosts();
      if (!mounted) return;
      setState(() {
        posts = data;
        error = null;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = posts.take(3).toList();
    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.campaign_outlined, color: AppColor.cyan),
          const SizedBox(width: 8),
          const Expanded(child: Text('Admin Updates', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          InkWell(onTap: () => _load(), child: const Icon(Icons.refresh, color: AppColor.muted, size: 20)),
        ]),
        const SizedBox(height: 10),
        if (loading)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: LinearProgressIndicator(minHeight: 2),
          )
        else if (visible.isEmpty)
          Text(
            error == null ? 'Admin post upload karoge to yahan user app me show hoga.' : 'Posts abhi connect nahi hue. Firebase rules check karo.',
            style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700),
          )
        else
          ...visible.map((post) => AdminPostCard(post: post)).toList(),
      ]),
    );
  }
}

class AdminPostCard extends StatelessWidget {
  final AppPost post;
  const AdminPostCard({super.key, required this.post});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AppColor.bg2, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColor.line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (post.imageBase64.trim().isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(9),
              child: Image.memory(
                base64Decode(post.imageBase64),
                width: double.infinity,
                fit: BoxFit.fitWidth,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
          )
        else if (post.imageUrl.trim().isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(9),
              child: Image.network(
                post.imageUrl,
                width: double.infinity,
                fit: BoxFit.fitWidth,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
          ),
        Text(post.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
        if (post.message.trim().isNotEmpty) ...[
          const SizedBox(height: 5),
          Text(post.message, style: const TextStyle(color: AppColor.muted, height: 1.35, fontWeight: FontWeight.w700)),
        ],

        if (post.linkUrl.trim().isNotEmpty) ...[
          const SizedBox(height: 10),
          InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () async {
              var raw = post.linkUrl.trim();
              if (!raw.startsWith('http://') && !raw.startsWith('https://')) {
                raw = 'https://$raw';
              }
              final uri = Uri.parse(raw);
              await launchUrl(uri, mode: LaunchMode.externalApplication);
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
              decoration: BoxDecoration(
                color: AppColor.cyan.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColor.cyan.withOpacity(0.45)),
              ),
              child: const Row(children: [
                Icon(Icons.open_in_new, color: AppColor.cyan, size: 18),
                SizedBox(width: 8),
                Expanded(child: Text('Open Link', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900))),
              ]),
            ),
          ),
        ],
      ]),
    );
  }
}


class TeamLogo extends StatelessWidget {
  final String code;
  final double size;
  final bool showCode;
  const TeamLogo({super.key, required this.code, this.size = 52, this.showCode = true});

  @override
  Widget build(BuildContext context) {
    final display = code.toUpperCase();
    return SizedBox(
      width: size + 12,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _circle(display),
          if (showCode) ...[
            const SizedBox(height: 4),
            Text(display, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: size < 40 ? 9 : 11, fontWeight: FontWeight.w900)),
          ],
        ],
      ),
    );
  }

  Widget _circle(String c) {
    if (c.contains('SCO')) return _scotland();
    if (c.contains('SL')) return _sriLanka();
    if (c.contains('IND')) return _emoji('🇮🇳');
    if (c.contains('AUS')) return _emoji('🇦🇺');
    if (c.contains('PAK')) return _emoji('🇵🇰');
    if (c.contains('ENG')) return _england();
    if (c.contains('NZ')) return _emoji('🇳🇿');
    if (c.contains('WI')) return _emoji('🏝️');
    if (c.contains('RSA') || c.contains('SA')) return _emoji('🇿🇦');
    if (c.contains('BAN')) return _emoji('🇧🇩');
    if (c.contains('NED')) return _emoji('🇳🇱');

    Color color = AppColor.blue;
    if (c == 'CSK') color = AppColor.yellow;
    if (c == 'MI') color = const Color(0xFF0458A7);
    if (c == 'RCB') color = const Color(0xFFD71920);
    if (c == 'KKR') color = const Color(0xFF3A1A78);
    if (c == 'SRH') color = const Color(0xFFF26522);
    if (c == 'RR') color = const Color(0xFFE91E8F);
    if (c == 'DC') color = const Color(0xFF17449B);
    if (c == 'GT') color = const Color(0xFF0B2545);
    if (c == 'LSG') color = const Color(0xFF00AEEF);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, border: Border.all(color: Colors.white24)),
      child: Center(child: Text(c.length > 4 ? c.substring(0, 4) : c, style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.white))),
    );
  }

  Widget _emoji(String emoji) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: Colors.white54)),
      child: Center(child: Text(emoji, style: TextStyle(fontSize: size * 0.56))),
    );
  }

  Widget _scotland() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF0F66B7), border: Border.all(color: Colors.white24)),
      child: ClipOval(
        child: Stack(children: [
          Center(child: Transform.rotate(angle: 0.78, child: Container(width: size * 1.5, height: size * 0.13, color: Colors.white))),
          Center(child: Transform.rotate(angle: -0.78, child: Container(width: size * 1.5, height: size * 0.13, color: Colors.white))),
        ]),
      ),
    );
  }

  Widget _sriLanka() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: AppColor.yellow, border: Border.all(color: Colors.white24)),
      child: Center(child: Text('🇱🇰', style: TextStyle(fontSize: size * 0.50))),
    );
  }

  Widget _england() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: Colors.white54)),
      child: ClipOval(
        child: Stack(children: [
          Container(color: Colors.white),
          Center(child: Container(width: size, height: size * 0.16, color: AppColor.red)),
          Center(child: Container(width: size * 0.16, height: size, color: AppColor.red)),
        ]),
      ),
    );
  }
}

class TournamentLogo extends StatelessWidget {
  final double size;
  const TournamentLogo({super.key, this.size = 68});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: const LinearGradient(colors: [Color(0xFFEEFBFF), Color(0xFF7E41E8), Color(0xFFFF3F92)]),
      ),
      child: Center(
        child: Text('T20\nWORLD\nCUP', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: size * 0.16, fontWeight: FontWeight.w900)),
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final bool selected;
  final Color color;
  const Pill(this.text, {super.key, this.selected = false, this.color = AppColor.cyan});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(color: selected ? AppColor.header : AppColor.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: selected ? AppColor.header : AppColor.line)),
      child: Center(child: Text(text, style: TextStyle(color: selected ? Colors.white : AppColor.muted, fontWeight: FontWeight.w900))),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900));
  }
}
