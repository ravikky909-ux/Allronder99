import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const Allrounder99App());
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Allrounder99',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColor.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.cyan, brightness: Brightness.dark),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaler: const TextScaler.linear(0.88)),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const MainShell(),
    );
  }
}

class AppColor {
  static const bg = Color(0xFF11191F);
  static const bg2 = Color(0xFF1F272D);
  static const card = Color(0xFF2E3841);
  static const card2 = Color(0xFF26313A);
  static const line = Color(0xFF172129);
  static const header = Color(0xFF5B6670);
  static const text = Color(0xFFF3F3F6);
  static const muted = Color(0xFFB5BCC4);
  static const cyan = Color(0xFF08C7FF);
  static const green = Color(0xFF159E69);
  static const red = Color(0xFFE94B55);
  static const blue = Color(0xFF2F9EE8);
  static const purple = Color(0xFF7252D5);
  static const yellow = Color(0xFFFFC247);
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const HomePage(),
      const FixturesPage(),
      const SeriesPage(),
      const MorePage(),
    ];

    return Scaffold(
      body: pages[selected],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        height: 68,
        backgroundColor: AppColor.bg2,
        indicatorColor: AppColor.cyan.withOpacity(0.14),
        onDestinationSelected: (value) => setState(() => selected = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: AppColor.cyan), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month, color: AppColor.cyan), label: 'Fixtures'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events, color: AppColor.cyan), label: 'Series'),
          NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz, color: AppColor.cyan), label: 'More'),
        ],
      ),
    );
  }
}

class GradientPage extends StatelessWidget {
  final Widget child;
  const GradientPage({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.bg,
      child: SafeArea(child: child),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;
  final double radius;
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.color,
    this.radius = 9,
  });

  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? AppColor.card,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: AppColor.line.withOpacity(0.4)),
      ),
      child: child,
    );
    if (onTap == null) return card;
    return InkWell(onTap: onTap, borderRadius: BorderRadius.circular(radius), child: card);
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Row(
            children: [
              ClipOval(child: Image.asset('assets/logo.png', width: 54, height: 54, fit: BoxFit.cover)),
              const SizedBox(width: 12),
              const Expanded(child: Text('ALLROUNDER99', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
              const Icon(Icons.search, color: AppColor.text),
              const SizedBox(width: 12),
              const Icon(Icons.notifications_none, color: AppColor.text),
            ],
          ),
          const SizedBox(height: 16),
          const Row(children: [
            Pill('Featured', selected: true),
            SizedBox(width: 8),
            Pill('Live'),
            SizedBox(width: 8),
            Pill('WT20 WC'),
          ]),
          const SizedBox(height: 14),
          MatchHomeCard(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailPage()))),
          const SizedBox(height: 14),
          const AdminPostsPreview(),
          const SizedBox(height: 14),
          const SectionTitle('Today Matches'),
          MatchListTile(title: 'Scotland Women vs Sri Lanka Women', subtitle: 'Womens T20 World Cup 2026 • 25th Match', left: 'SCOW', right: 'SLW'),
          MatchListTile(title: 'India Women vs England Women', subtitle: 'Womens T20 World Cup 2026 • Upcoming', left: 'INDW', right: 'ENGW'),
          MatchListTile(title: 'Australia Women vs New Zealand Women', subtitle: 'Group A • Upcoming', left: 'AUSW', right: 'NZW'),
        ],
      ),
    );
  }
}

class MatchHomeCard extends StatelessWidget {
  final VoidCallback onTap;
  const MatchHomeCard({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      onTap: onTap,
      padding: EdgeInsets.zero,
      radius: 12,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(13),
            child: Row(
              children: const [
                Pill('LIVE', selected: true, color: AppColor.red),
                SizedBox(width: 8),
                Expanded(child: Text('Womens T20 World Cup 2026, 25th Match', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14))),
                Icon(Icons.chevron_right, color: AppColor.muted),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColor.line),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: const [
                TeamLogo(code: 'SCOW'),
                SizedBox(width: 10),
                Expanded(child: Text('SCOW\n151-6 (20.0)', style: TextStyle(fontWeight: FontWeight.w800, height: 1.4))),
                Icon(Icons.flash_on, color: AppColor.text, size: 30),
                Expanded(child: Text('0-0\nSLW', textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, height: 1.4))),
                SizedBox(width: 10),
                TeamLogo(code: 'SLW'),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(color: AppColor.bg2, borderRadius: BorderRadius.vertical(bottom: Radius.circular(12))),
            child: const Center(child: Text('Innings Break • Sri Lanka Women need 152 runs', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900))),
          ),
        ],
      ),
    );
  }
}

class MatchListTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String left;
  final String right;
  const MatchListTile({super.key, required this.title, required this.subtitle, required this.left, required this.right});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailPage())),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            TeamLogo(code: left, size: 42),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 6),
              Text(subtitle, style: const TextStyle(color: AppColor.muted, fontSize: 12.5)),
            ])),
            TeamLogo(code: right, size: 42),
          ],
        ),
      ),
    );
  }
}

class FixturesPage extends StatelessWidget {
  const FixturesPage({super.key});
  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: const [
          Text('Fixtures', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 12),
          MatchListTile(title: 'Scotland Women vs Sri Lanka Women', subtitle: 'Fri, 26 Jun, 11:00 PM at Your Time', left: 'SCOW', right: 'SLW'),
          MatchListTile(title: 'India Women vs England Women', subtitle: 'Womens T20 World Cup 2026', left: 'INDW', right: 'ENGW'),
          MatchListTile(title: 'Australia Women vs Pakistan Women', subtitle: 'Group A', left: 'AUSW', right: 'PAKW'),
        ],
      ),
    );
  }
}

class SeriesPage extends StatelessWidget {
  const SeriesPage({super.key});
  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: const [
          Text('Series', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 12),
          SeriesCard(title: 'Womens T20 World Cup 2026', subtitle: 'International T20 • Live scores and points table'),
          SeriesCard(title: 'Indian T20 League', subtitle: 'IPL team badges ready: CSK, MI, RCB, KKR, SRH, RR, DC, PBKS, GT, LSG'),
          SeriesCard(title: 'Allrounder99 Cricket', subtitle: 'Live commentary, scorecard and match history'),
        ],
      ),
    );
  }
}

class SeriesCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SeriesCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        child: Row(children: [
          const TournamentLogo(size: 58),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(color: AppColor.muted)),
          ])),
          const Icon(Icons.chevron_right, color: AppColor.muted),
        ]),
      ),
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const Text('More', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          const MoreWelcomeCard(),
          SizedBox(height: 14),
          const MoreTile(icon: Icons.flash_on, title: 'Live Matches'),
          const MoreTile(icon: Icons.calendar_month_outlined, title: 'Fixtures & Schedule'),
          const MoreTile(icon: Icons.emoji_events_outlined, title: 'Series & Leagues'),
          const MoreTile(icon: Icons.comment_outlined, title: 'Commentary'),
          const MoreTile(icon: Icons.table_chart_outlined, title: 'Scorecards'),
          const MoreTile(icon: Icons.leaderboard_outlined, title: 'Points Table'),
          const MoreTile(icon: Icons.notifications_active_outlined, title: 'Live Score Alerts', trailing: 'On'),
          const MoreTile(icon: Icons.settings_outlined, title: 'Settings'),
          const MoreTile(icon: Icons.language, title: 'Language', trailing: 'English'),
          const MoreTile(icon: Icons.share_outlined, title: 'Share App'),
          const MoreTile(icon: Icons.star_border, title: 'Rate Us'),
          const MoreTile(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy'),
          const MoreTile(icon: Icons.description_outlined, title: 'Terms & Conditions'),
          const MoreTile(icon: Icons.info_outline, title: 'About Allrounder99', trailing: 'v1.0.0'),
        ],
      ),
    );
  }
}

class MoreWelcomeCard extends StatelessWidget {
  const MoreWelcomeCard({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Row(
        children: [
          ClipOval(child: Image.asset('assets/logo.png', width: 70, height: 70, fit: BoxFit.cover)),
          const SizedBox(width: 14),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Welcome to Allrounder99', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            SizedBox(height: 6),
            Text('Scoring app for live cricket scores, scorecards and match history.', style: TextStyle(color: AppColor.muted, height: 1.35, fontWeight: FontWeight.w700)),
          ])),
        ],
      ),
    );
  }
}

class MoreTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final VoidCallback? onTap;
  const MoreTile({super.key, required this.icon, required this.title, this.trailing, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: AppColor.cyan),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
            if (trailing != null) Text(trailing!, style: const TextStyle(color: AppColor.muted)),
            const Icon(Icons.chevron_right, color: AppColor.muted),
          ],
        ),
      ),
    );
  }
}

class MatchDetailPage extends StatefulWidget {
  const MatchDetailPage({super.key});

  @override
  State<MatchDetailPage> createState() => _MatchDetailPageState();
}

class _MatchDetailPageState extends State<MatchDetailPage> {
  int tab = 0;
  late final PageController pageController;
  final tabs = const ['Info', 'Live', 'Commentary', 'Scorecard', 'History', 'Points Table'];

  @override
  void initState() {
    super.initState();
    pageController = PageController(initialPage: tab);
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  void openTab(int index) {
    setState(() => tab = index);
    pageController.animateToPage(index, duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const InfoTab(),
      const LiveTab(),
      const CommentaryTab(),
      const ScorecardTab(),
      const HistoryTab(),
      const PointsTableTab(),
    ];

    return Scaffold(
      body: GradientPage(
        child: Column(
          children: [
            SizedBox(
              height: 48,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: tabs.length,
                separatorBuilder: (_, __) => const SizedBox(width: 14),
                itemBuilder: (context, i) => GestureDetector(
                  onTap: () => openTab(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tab == i ? Colors.white : Colors.transparent, width: 3))),
                    child: Text(
                      tabs[i],
                      style: TextStyle(color: tab == i ? AppColor.text : AppColor.muted, fontWeight: FontWeight.w900, fontSize: 17),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: PageView(
                controller: pageController,
                onPageChanged: (value) => setState(() => tab = value),
                children: pages,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MatchTeamsHeader extends StatelessWidget {
  final bool scores;
  const MatchTeamsHeader({super.key, this.scores = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 12, 17, 8),
      child: Row(
        children: [
          const TeamLogo(code: 'SCOW', size: 58),
          const SizedBox(width: 14),
          Expanded(
            child: scores
                ? const Text('151-6 (20.0)\nSCOW', style: TextStyle(fontWeight: FontWeight.w900, height: 1.35))
                : const Text('SCOW', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          ),
          const Icon(Icons.flash_on, color: AppColor.text, size: 28),
          Expanded(
            child: scores
                ? const Text('0-0\nSLW', textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, height: 1.35))
                : const Text('SLW', textAlign: TextAlign.right, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 14),
          const TeamLogo(code: 'SLW', size: 58),
        ],
      ),
    );
  }
}

class InfoTab extends StatelessWidget {
  const InfoTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: const [
        MatchTeamsHeader(),
        TournamentInfoCard(),
        SizedBox(height: 14),
        MatchMetaCard(),
        SizedBox(height: 16),
        Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: Text('Team Squads', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        SizedBox(height: 10),
        TeamSquadsCard(),
        SizedBox(height: 16),
        Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: Text('Recent Performance   (Last 5 Matches)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        SizedBox(height: 10),
        RecentPerformanceCard(),
        SizedBox(height: 16),
        Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: Text('Head to Head', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        SizedBox(height: 10),
        HeadToHeadCard(),
        SizedBox(height: 20),
      ],
    );
  }
}

class TournamentInfoCard extends StatelessWidget {
  const TournamentInfoCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        child: Row(
          children: const [
            TournamentLogo(size: 70),
            SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('25th Match, Group B', style: TextStyle(color: AppColor.muted, fontSize: 17)),
              SizedBox(height: 8),
              Text('Scotland Women Vs Sri Lanka Women', style: TextStyle(color: AppColor.muted, fontSize: 17)),
              SizedBox(height: 8),
              Text('Womens T20 World Cup 2026', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            ])),
            Icon(Icons.chevron_right, color: AppColor.muted),
          ],
        ),
      ),
    );
  }
}

class MatchMetaCard extends StatelessWidget {
  const MatchMetaCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(
          children: const [
            MetaLine(icon: Icons.calendar_month, text: 'Fri, 26 Jun, 11:00 PM at Your Time'),
            Divider(height: 1, color: AppColor.line),
            MetaLine(icon: Icons.thumb_up_alt, text: 'Sri Lanka Women opt to bowl', iconColor: Colors.orangeAccent),
            Divider(height: 1, color: AppColor.line),
            MetaLine(icon: Icons.location_on, text: 'Emirates Old Trafford, Manchester, England', iconColor: Colors.red),
          ],
        ),
      ),
    );
  }
}

class MetaLine extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color iconColor;
  const MetaLine({super.key, required this.icon, required this.text, this.iconColor = Colors.white});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Icon(icon, color: iconColor, size: 24),
        const SizedBox(width: 15),
        Expanded(child: Text(text, style: const TextStyle(color: AppColor.muted, fontSize: 16, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}

class TeamSquadsCard extends StatelessWidget {
  const TeamSquadsCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(children: [
          SquadLine(code: 'SLW', name: 'Sri Lanka Women'),
          Divider(height: 1, color: AppColor.line),
          SquadLine(code: 'SCOW', name: 'Scotland Women'),
        ]),
      ),
    );
  }
}

class SquadLine extends StatelessWidget {
  final String code;
  final String name;
  const SquadLine({super.key, required this.code, required this.name});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(13),
      child: Row(children: [
        TeamLogo(code: code, size: 32, showCode: false),
        const SizedBox(width: 8),
        Expanded(child: Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        const Icon(Icons.chevron_right, color: AppColor.muted),
      ]),
    );
  }
}

class RecentPerformanceCard extends StatelessWidget {
  const RecentPerformanceCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: Column(
        children: const [
          FormLine(team: 'Sri Lanka Women', results: ['*', 'W', 'L', 'W', 'L', 'W']),
          SizedBox(height: 8),
          FormLine(team: 'Scotland Women', results: ['*', 'L', 'L', 'L', 'W', 'W']),
        ],
      ),
    );
  }
}

class FormLine extends StatelessWidget {
  final String team;
  final List<String> results;
  const FormLine({super.key, required this.team, required this.results});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      child: Row(
        children: [
          Expanded(child: Text(team, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          for (final r in results) FormBox(r),
          const Icon(Icons.keyboard_arrow_down, color: AppColor.muted),
        ],
      ),
    );
  }
}

class FormBox extends StatelessWidget {
  final String text;
  const FormBox(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    Color bg = Colors.transparent;
    Color fg = Colors.white;
    Color border = Colors.white70;
    if (text == 'W') {
      bg = const Color(0xFFE9FFF0);
      fg = AppColor.green;
      border = AppColor.green;
    } else if (text == 'L') {
      bg = const Color(0xFFFFEEF0);
      fg = AppColor.red;
      border = AppColor.red;
    }
    return Container(
      margin: const EdgeInsets.only(right: 6),
      width: 34,
      height: 34,
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(4), border: Border.all(color: border)),
      child: Center(child: Text(text, style: TextStyle(color: fg, fontWeight: FontWeight.w900))),
    );
  }
}

class HeadToHeadCard extends StatelessWidget {
  const HeadToHeadCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 17),
      child: GlassCard(
        child: Row(
          children: const [
            SizedBox(width: 95, child: Text('2\nMatches', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
            SizedBox(width: 16),
            Expanded(child: Column(children: [
              H2HLine(code: 'SLW', won: 'Won 2', value: 1.0),
              Divider(height: 20, color: AppColor.line),
              H2HLine(code: 'SCOW', won: 'Won 0', value: 0.05),
            ])),
          ],
        ),
      ),
    );
  }
}

class H2HLine extends StatelessWidget {
  final String code;
  final String won;
  final double value;
  const H2HLine({super.key, required this.code, required this.won, required this.value});
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      TeamLogo(code: code, size: 42),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(won, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        LinearProgressIndicator(value: value, minHeight: 14, color: AppColor.purple, backgroundColor: AppColor.bg2, borderRadius: BorderRadius.circular(9)),
      ])),
    ]);
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
      children: const [
        MatchTeamsHeader(scores: true),
        TvLiveBox(),
        SizedBox(height: 10),
        BallStrip(),
        SizedBox(height: 10),
        LiveStatsCard(),
        SizedBox(height: 10),
        WinProbCard(),
        SizedBox(height: 10),
        BatterCard(),
        SizedBox(height: 10),
        BowlerCard(),
        SizedBox(height: 12),
      ],
    );
  }
}

class TvLiveBox extends StatelessWidget {
  const TvLiveBox({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 215,
      decoration: BoxDecoration(color: Colors.black, border: Border.all(color: AppColor.header, width: 5)),
      child: Column(
        children: const [
          Expanded(
            child: Stack(
              children: [
                Positioned(left: 14, top: 14, child: Icon(Icons.volume_off, color: Colors.white)),
                Positioned(right: 14, top: 14, child: Row(children: [CircleAvatar(radius: 4, backgroundColor: Colors.red), SizedBox(width: 4), Text('Live')])),
                Center(child: Text('INNINGS BREAK', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900))),
                Positioned(left: 18, bottom: 18, child: Text('SLW', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.muted))),
                Positioned(right: 18, bottom: 18, child: Text('SCOW', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.muted))),
              ],
            ),
          ),
          DecoratedBox(
            decoration: BoxDecoration(color: AppColor.card2),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              child: Row(children: [
                Text('SCOW 151-6 (20.0)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                Spacer(),
                Text('SLW 0-0', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w900)),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class BallStrip extends StatelessWidget {
  const BallStrip({super.key});
  @override
  Widget build(BuildContext context) {
    final balls = ['WD', '4', '2', '1', 'W', '1', '4'];
    return GlassCard(
      padding: const EdgeInsets.all(10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            for (final b in balls) BallCircle(text: b),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('= 13', style: TextStyle(fontWeight: FontWeight.w900))),
            const SizedBox(height: 38, child: VerticalDivider(color: AppColor.line, thickness: 1)),
            const SizedBox(width: 8),
            const Text('Over 20', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(width: 8),
            const BallCircle(text: '4'),
            const BallEmpty(),
            const BallEmpty(),
            const BallEmpty(),
          ],
        ),
      ),
    );
  }
}

class BallCircle extends StatelessWidget {
  final String text;
  const BallCircle({super.key, required this.text});
  @override
  Widget build(BuildContext context) {
    Color bg = AppColor.green;
    if (text == '4') bg = AppColor.blue;
    if (text == '6') bg = AppColor.purple;
    if (text == 'W') bg = AppColor.red;
    if (text == 'WD') bg = AppColor.card2;
    return Container(
      margin: const EdgeInsets.only(right: 6),
      width: 42,
      height: 42,
      decoration: BoxDecoration(shape: BoxShape.circle, color: bg, border: Border.all(color: Colors.white24)),
      child: Center(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900))),
    );
  }
}

class BallEmpty extends StatelessWidget {
  const BallEmpty({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(margin: const EdgeInsets.only(right: 6), width: 42, height: 42, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColor.muted)));
  }
}

class LiveStatsCard extends StatelessWidget {
  const LiveStatsCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const GlassCard(child: Row(children: [
      Expanded(child: Text('Run Rate: 7.55', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
      Text('Balls Rem: 120', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
    ]));
  }
}

class WinProbCard extends StatelessWidget {
  const WinProbCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const GlassCard(child: Row(children: [
      Text('Win Probability  ⓘ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
      Spacer(),
      Text('SLW:', style: TextStyle(fontSize: 16)),
      SizedBox(width: 8),
      OddBox('75', color: AppColor.red),
      SizedBox(width: 6),
      OddBox('76', color: AppColor.green),
    ]));
  }
}

class BatterCard extends StatelessWidget {
  const BatterCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const GlassCard(child: Column(children: [
      ScoreHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']),
      ScoreDataRow(cols: ['Sarah Bryce 🏏', '47', '33', '6', '0', '142.42']),
      ScoreDataRow(cols: ['Megan McColl', '1', '1', '0', '0', '100.0']),
      Divider(color: AppColor.line),
      Row(children: [Expanded(child: Text("P'ship: 48(34)", style: TextStyle(color: AppColor.muted))), Text("L' Wkt: Pippa Sproul 0(1)", style: TextStyle(color: AppColor.muted))]),
    ]));
  }
}

class BowlerCard extends StatelessWidget {
  const BowlerCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const GlassCard(child: Column(children: [
      ScoreHeader(cols: ['Bowler', 'O', 'M', 'R', 'W', 'ER']),
      ScoreDataRow(cols: ['Mithali Ayodhya 🎾', '4.0', '0', '34', '2', '8.5']),
    ]));
  }
}

class CommentaryTab extends StatelessWidget {
  const CommentaryTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: const [
        MatchTeamsHeader(scores: true),
        Padding(
          padding: EdgeInsets.fromLTRB(17, 14, 17, 0),
          child: GlassCard(
            child: Text(
              '7:55pm Local Time, 12:25am IST : Scotland have done a great job by posting 151 on the board. Darcey Carter again looked good at the top while Sarah Bryce held the innings together with a brisk 33-ball 47. It is now down to Sri Lanka Women to chase this down.',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, height: 1.35),
            ),
          ),
        ),
        Padding(padding: EdgeInsets.fromLTRB(17, 14, 17, 0), child: GlassCard(child: Text('INNINGS BREAK.', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)))),
        OverSummaryCard(),
        CommentaryLine(over: '19.6', run: '4', text: 'Mithali Ayodhya to Sarah Bryce: Four. Scotland Women finish on 151! Length ball on off, makes room and cuts it wide of extra cover for a boundary'),
        CommentaryLine(over: '19.5', run: '1', text: 'Mithali Ayodhya to Megan McColl: One Run. Full ball outside off, drives it uppishly and straight back.'),
        PlayerHighlightCard(title: 'New batter on crease', name: 'Pippa Sproul', stat1: '3\nMatches', stat2: '30\nRuns'),
        CommentaryLine(over: '19.4', run: 'W', text: 'Mithali Ayodhya to Pippa Sproul: Bowled!. No Run. Full ball on middle and leg, steps across and looks to scoop but misses.'),
        CommentaryLine(over: '19.3', run: '1', text: 'Mithali Ayodhya to Sarah Bryce: One Run. Low full toss on leg, flicks it to deep square leg.'),
        CommentaryLine(over: '19.2', run: '2', text: 'Mithali Ayodhya to Sarah Bryce: Two Runs. Full ball on leg, flicks it wide of long on for a quick couple.'),
        CommentaryLine(over: '19.1', run: '4', text: 'Mithali Ayodhya to Sarah Bryce: Four. Back of length ball outside off, slashes it away over backward point for a boundary.'),
        CommentaryLine(over: '19.1', run: 'wd', text: 'Mithali Ayodhya to Sarah Bryce: Wide Ball. One Run.'),
        PlayerHighlightCard(title: 'Batting - T20 Career', name: 'Sarah Bryce', stat1: '87.01\nStrike Rate', stat2: '11.17\nAvg'),
        SizedBox(height: 20),
      ],
    );
  }
}

class OverSummaryCard extends StatelessWidget {
  const OverSummaryCard({super.key});
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(17, 14, 17, 0),
      child: GlassCard(
        child: Row(children: [
          SizedBox(width: 128, height: 90, child: DecoratedBox(
            decoration: BoxDecoration(color: AppColor.bg2, borderRadius: BorderRadius.all(Radius.circular(8))),
            child: Center(child: Text('151-6\nSCOW', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))),
          )),
          SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('End of 20th over: WD 4 2 1 WK 1 4 (13 RUNS)', style: TextStyle(fontWeight: FontWeight.w900)),
            Divider(color: AppColor.line),
            Row(children: [Expanded(child: Text('Sarah Bryce')), Text('47 (33)', style: TextStyle(fontWeight: FontWeight.w900))]),
            SizedBox(height: 8),
            Row(children: [Expanded(child: Text('Megan McColl')), Text('1 (1)', style: TextStyle(fontWeight: FontWeight.w900))]),
            SizedBox(height: 8),
            Row(children: [Expanded(child: Text('Mithali Ayodhya')), Text('4.0-0-34-2', style: TextStyle(fontWeight: FontWeight.w900))]),
          ])),
        ]),
      ),
    );
  }
}

class CommentaryLine extends StatelessWidget {
  final String over;
  final String run;
  final String text;
  const CommentaryLine({super.key, required this.over, required this.run, required this.text});
  @override
  Widget build(BuildContext context) {
    Color bg = AppColor.green;
    if (run == '4') bg = AppColor.blue;
    if (run == 'W') bg = AppColor.red;
    if (run == 'wd') bg = AppColor.card2;
    return Padding(
      padding: const EdgeInsets.fromLTRB(34, 18, 34, 0),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 56, child: Column(children: [
          Text(over, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          CircleAvatar(backgroundColor: bg, child: Text(run, style: const TextStyle(fontWeight: FontWeight.w900))),
        ])),
        const SizedBox(width: 12),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 17, height: 1.35, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}

class PlayerHighlightCard extends StatelessWidget {
  final String title;
  final String name;
  final String stat1;
  final String stat2;
  const PlayerHighlightCard({super.key, required this.title, required this.name, required this.stat1, required this.stat2});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 16, 17, 0),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: const LinearGradient(colors: [Color(0xFF433A82), Color(0xFF7B1238)]),
        ),
        child: Row(children: [
          Container(width: 58, height: 58, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.person, color: AppColor.bg, size: 42)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const Text('Right Handed Bat', style: TextStyle(color: Colors.white70)),
          ])),
          Text(stat1, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.35)),
          const SizedBox(width: 16),
          Text(stat2, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.35)),
        ]),
      ),
    );
  }
}

class ScorecardTab extends StatelessWidget {
  const ScorecardTab({super.key});
  @override
  Widget build(BuildContext context) {
    final batters = [
      ['Darcey Carter', 'c Kaushani Nuthyangana b Sugandika Kumari', '34', '36', '5', '0', '94.44'],
      ['Katherine Fraser', 'c Nilakshi de Silva b Mithali Ayodhya', '12', '9', '2', '0', '133.33'],
      ['Kathryn Bryce', 'c & b Kavisha Dilhari', '23', '23', '3', '1', '100.0'],
      ['Sarah Bryce', 'Not Out', '47', '33', '6', '0', '142.42'],
      ['Ailsa Lister', 'runout (Nilakshi de Silva)', '26', '17', '4', '0', '152.94'],
      ['Priyanaz Chatterji', 'runout (Harshitha Samarawickrama)', '0', '0', '0', '0', '0.0'],
      ['Pippa Sproul', 'b Mithali Ayodhya', '0', '1', '0', '0', '0.0'],
      ['Megan McColl', 'Not Out', '1', '1', '0', '0', '100.0'],
    ];
    final bowlers = [
      ['Mithali Ayodhya', '4.0', '0', '34', '2', '8.5'],
      ['Sugandika Kumari', '4.0', '0', '28', '1', '7.0'],
      ['Kavisha Dilhari', '4.0', '0', '31', '1', '7.75'],
      ['Inoshi Priyadharshani', '4.0', '0', '24', '0', '6.0'],
    ];
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const MatchTeamsHeader(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 17),
          child: Column(
            children: [
              const InningsScoreHeader(team: 'Scotland Women', score: '151/6 (20.0)', open: true),
              Container(
                color: AppColor.card,
                child: Column(
                  children: [
                    const ScoreHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']),
                    for (final b in batters) BatterScoreLine(name: b[0], sub: b[1], r: b[2], balls: b[3], fours: b[4], sixes: b[5], sr: b[6], active: b[1] == 'Not Out'),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(16, 10, 16, 8),
                      child: Row(children: [Text('Extras:', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), Spacer(), Text('8 (0 b, 1 lb, 7 wd, 0 nb, 0 p)', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800))]),
                    ),
                    const Divider(color: AppColor.line, height: 1),
                    const Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Did not bat', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                        SizedBox(height: 8),
                        Text('Rachel Slater, Kirstie Gordon, Gabriella Fontenla', style: TextStyle(height: 1.35, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                    const ScoreHeader(cols: ['Bowler', 'O', 'M', 'R', 'W', 'ER']),
                    for (final b in bowlers) BowlerScoreLine(name: b[0], o: b[1], m: b[2], r: b[3], w: b[4], er: b[5]),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

class InningsScoreHeader extends StatelessWidget {
  final String team;
  final String score;
  final bool open;
  const InningsScoreHeader({super.key, required this.team, required this.score, required this.open});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      color: AppColor.card2,
      child: Row(children: [
        Expanded(child: Text(team, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
        Text(score, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(width: 8),
        Icon(open ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down),
      ]),
    );
  }
}

class ScoreHeader extends StatelessWidget {
  final List<String> cols;
  const ScoreHeader({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.header,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(children: [
        Expanded(flex: 5, child: Text(cols[0], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
        for (int i = 1; i < cols.length; i++) Expanded(child: Text(cols[i], textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
      ]),
    );
  }
}

class BatterScoreLine extends StatelessWidget {
  final String name;
  final String sub;
  final String r;
  final String balls;
  final String fours;
  final String sixes;
  final String sr;
  final bool active;
  const BatterScoreLine({super.key, required this.name, required this.sub, required this.r, required this.balls, required this.fours, required this.sixes, required this.sr, this.active = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(border: Border(left: BorderSide(color: active ? AppColor.cyan : Colors.transparent, width: 4))),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 9),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 5, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text(sub, style: const TextStyle(color: Color(0xFF8EE4FF), height: 1.25)),
        ])),
        Expanded(child: Text(r, textAlign: TextAlign.right)),
        Expanded(child: Text(balls, textAlign: TextAlign.right)),
        Expanded(child: Text(fours, textAlign: TextAlign.right)),
        Expanded(child: Text(sixes, textAlign: TextAlign.right)),
        Expanded(child: Text(sr, textAlign: TextAlign.right)),
      ]),
    );
  }
}

class BowlerScoreLine extends StatelessWidget {
  final String name;
  final String o;
  final String m;
  final String r;
  final String w;
  final String er;
  const BowlerScoreLine({super.key, required this.name, required this.o, required this.m, required this.r, required this.w, required this.er});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 9),
      child: Row(children: [
        Expanded(flex: 5, child: Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
        Expanded(child: Text(o, textAlign: TextAlign.right)),
        Expanded(child: Text(m, textAlign: TextAlign.right)),
        Expanded(child: Text(r, textAlign: TextAlign.right)),
        Expanded(child: Text(w, textAlign: TextAlign.right)),
        Expanded(child: Text(er, textAlign: TextAlign.right)),
      ]),
    );
  }
}

class ScoreDataRow extends StatelessWidget {
  final List<String> cols;
  const ScoreDataRow({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(children: [
        Expanded(flex: 5, child: Text(cols[0], style: const TextStyle(fontWeight: FontWeight.w800))),
        for (int i = 1; i < cols.length; i++) Expanded(child: Text(cols[i], textAlign: TextAlign.right)),
      ]),
    );
  }
}

class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key});
  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  int expanded = 20;

  @override
  Widget build(BuildContext context) {
    final overs = [
      [20, '13 runs, 1 w', 'SCOW: 151-6'],
      [19, '9 runs', 'SCOW: 138-5'],
      [18, '10 runs', 'SCOW: 129-5'],
      [17, '8 runs', 'SCOW: 119-4'],
      [16, '11 runs', 'SCOW: 111-4'],
      [15, '5 runs', 'SCOW: 100-3'],
      [14, '16 runs', 'SCOW: 95-3'],
      [13, '7 runs', 'SCOW: 84-2'],
      [12, '3 runs', 'SCOW: 77-2'],
      [11, '7 runs', 'SCOW: 74-2'],
      [10, '2 runs, 1 w', 'SCOW: 67-2'],
      [9, '11 runs', 'SCOW: 65-1'],
      [8, '3 runs', 'SCOW: 54-1'],
      [7, '6 runs', 'SCOW: 51-1'],
      [6, '6 runs', 'SCOW: 45-1'],
      [5, '10 runs, 1 w', 'SCOW: 39-1'],
      [4, '4 runs', 'SCOW: 29-0'],
      [3, '4 runs', 'SCOW: 25-0'],
      [2, '14 runs', 'SCOW: 21-0'],
    ];
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const MatchTeamsHeader(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 10),
          child: Row(children: const [Expanded(child: Pill('1st Innings', selected: true))]),
        ),
        for (final o in overs) OverHistoryTile(
          over: o[0] as int,
          runs: o[1] as String,
          score: o[2] as String,
          expanded: expanded == o[0],
          onTap: () => setState(() => expanded = expanded == o[0] ? -1 : o[0] as int),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

class OverHistoryTile extends StatelessWidget {
  final int over;
  final String runs;
  final String score;
  final bool expanded;
  final VoidCallback onTap;
  const OverHistoryTile({super.key, required this.over, required this.runs, required this.score, required this.expanded, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final balls = [
      ['19.6', '4', '151 - 6', '12:24 AM'],
      ['19.5', '1', '147 - 6', '12:23 AM'],
      ['19.4', 'W', '146 - 6', '12:22 AM'],
      ['19.3', '1', '146 - 5', '12:21 AM'],
      ['19.2', '2', '145 - 5', '12:21 AM'],
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(17, 0, 17, 12),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(
          children: [
            InkWell(
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(children: [
                  Text('${over}th Over : ', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  Text(runs, style: const TextStyle(fontSize: 16, color: AppColor.muted, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  Text(score, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  const SizedBox(width: 8),
                  Icon(expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down),
                ]),
              ),
            ),
            if (expanded) ...[
              const Divider(height: 1, color: AppColor.line),
              for (final b in balls) HistoryBallLine(ball: b[0], run: b[1], score: b[2], time: b[3], marketOver: '${over} Over'),
            ],
          ],
        ),
      ),
    );
  }
}

class HistoryBallLine extends StatelessWidget {
  final String ball;
  final String run;
  final String score;
  final String time;
  final String marketOver;
  const HistoryBallLine({super.key, required this.ball, required this.run, required this.score, required this.time, required this.marketOver});
  @override
  Widget build(BuildContext context) {
    Color color = AppColor.green;
    if (run == '4') color = AppColor.blue;
    if (run == 'W') color = AppColor.red;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(children: [
        Column(children: [
          CircleAvatar(backgroundColor: color, child: Text(run, style: const TextStyle(fontWeight: FontWeight.w900))),
          const SizedBox(height: 6),
          Text(time, style: const TextStyle(color: AppColor.muted, fontSize: 12)),
        ]),
        const SizedBox(width: 16),
        Expanded(child: Row(children: [
          Text(score, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(width: 6),
          Text(ball, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)),
        ])),
        Column(children: [
          Row(children: [
            OddBox(marketOver, light: true),
            SizedBox(width: 6),
            OddBox('148', color: AppColor.red),
            SizedBox(width: 6),
            OddBox('149', color: AppColor.green),
          ]),
        ]),
      ]),
    );
  }
}

class OddBox extends StatelessWidget {
  final String text;
  final Color color;
  final bool light;
  const OddBox(this.text, {super.key, this.color = AppColor.card2, this.light = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: text.length > 4 ? 64 : 48,
      height: 34,
      decoration: BoxDecoration(color: light ? Colors.white : color, borderRadius: BorderRadius.circular(6), border: Border.all(color: AppColor.line)),
      child: Center(child: Text(text, style: TextStyle(color: light ? AppColor.bg : Colors.white, fontWeight: FontWeight.w900, fontSize: 13))),
    );
  }
}

class PointsTableTab extends StatelessWidget {
  const PointsTableTab({super.key});
  @override
  Widget build(BuildContext context) {
    final groupA = [
      ['AUSW', '4', '4', '0', '0', '0', '8', '4.724'],
      ['INDW', '4', '3', '1', '0', '0', '6', '2.268'],
      ['RSAW', '4', '3', '1', '0', '0', '6', '0.734'],
      ['BANW', '4', '2', '2', '0', '0', '4', '-0.849'],
      ['PAKW', '4', '0', '4', '0', '0', '0', '-2.831'],
      ['NEDW', '4', '0', '4', '0', '0', '0', '-3.64'],
    ];
    final groupB = [
      ['ENGW', '4', '4', '0', '0', '0', '8', '2.342'],
      ['WIW', '4', '3', '1', '0', '0', '6', '0.008'],
      ['NZW', '4', '2', '2', '0', '0', '4', '0.122'],
      ['SLW', '4', '2', '2', '0', '0', '4', '-0.031'],
      ['SCOW', '4', '1', '3', '0', '0', '2', '-0.956'],
    ];
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const SizedBox(height: 24),
        const Center(child: Text('Group A', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
        const PointsHeader(),
        for (final r in groupA) PointsRow(row: r),
        const SizedBox(height: 22),
        const Center(child: Text('Group B', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
        const PointsHeader(),
        for (final r in groupB) PointsRow(row: r),
        const SizedBox(height: 20),
      ],
    );
  }
}

class PointsHeader extends StatelessWidget {
  const PointsHeader({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.header,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      margin: const EdgeInsets.only(top: 14),
      child: const Row(children: [
        Expanded(flex: 4, child: Text('Teams', style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('P', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('W', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('L', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('T', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('NR', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(child: Text('PTS', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
        Expanded(flex: 2, child: Text('NRR', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
      ]),
    );
  }
}

class PointsRow extends StatelessWidget {
  final List<String> row;
  const PointsRow({super.key, required this.row});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.card,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      child: Row(children: [
        Expanded(flex: 4, child: Row(children: [
          TeamLogo(code: row[0], size: 34, showCode: false),
          const SizedBox(width: 10),
          Expanded(child: Text(row[0], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
        ])),
        for (int i = 1; i <= 6; i++) Expanded(child: Text(row[i], textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
        Expanded(flex: 2, child: Text(row[7], textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}


class AppPost {
  final String name;
  final String title;
  final String message;
  final String imageUrl;
  final bool active;
  final int createdAt;

  const AppPost({
    required this.name,
    required this.title,
    required this.message,
    required this.imageUrl,
    required this.active,
    required this.createdAt,
  });

  String get shortId => name.split('/').isEmpty ? name : name.split('/').last;

  factory AppPost.fromFirestore(Map<String, dynamic> doc) {
    final fields = (doc['fields'] as Map<String, dynamic>?) ?? {};
    String stringValue(String key) {
      final value = fields[key];
      if (value is Map && value['stringValue'] != null) return value['stringValue'].toString();
      if (value is Map && value['integerValue'] != null) return value['integerValue'].toString();
      if (value is Map && value['booleanValue'] != null) return value['booleanValue'].toString();
      return '';
    }

    bool boolValue(String key, {bool fallback = true}) {
      final value = fields[key];
      if (value is Map && value['booleanValue'] != null) return value['booleanValue'] == true;
      return fallback;
    }

    int intValue(String key) {
      final value = fields[key];
      if (value is Map && value['integerValue'] != null) return int.tryParse(value['integerValue'].toString()) ?? 0;
      if (value is Map && value['stringValue'] != null) return int.tryParse(value['stringValue'].toString()) ?? 0;
      return 0;
    }

    return AppPost(
      name: (doc['name'] ?? '').toString(),
      title: stringValue('title'),
      message: stringValue('message'),
      imageUrl: stringValue('imageUrl'),
      active: boolValue('active'),
      createdAt: intValue('createdAt'),
    );
  }
}

class AdminPostsApi {
  static const String projectId = 'allrounder99-806a4';
  static const String adminPin = 'A99@2026';
  static const String _base = 'https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents';

  static Future<List<AppPost>> fetchPosts() async {
    final uri = Uri.parse('$_base/posts?pageSize=50');
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode == 404) return <AppPost>[];
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Posts connect nahi hua (${res.statusCode})');
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    final docs = (body['documents'] as List?) ?? const [];
    final posts = docs
        .whereType<Map<String, dynamic>>()
        .map(AppPost.fromFirestore)
        .where((post) => post.active && (post.title.trim().isNotEmpty || post.message.trim().isNotEmpty))
        .toList();
    posts.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return posts;
  }

  static Map<String, dynamic> _fields({
    required String title,
    required String message,
    required String imageUrl,
    required bool active,
    required int createdAt,
  }) {
    return {
      'title': {'stringValue': title.trim()},
      'message': {'stringValue': message.trim()},
      'imageUrl': {'stringValue': imageUrl.trim()},
      'active': {'booleanValue': active},
      'createdAt': {'integerValue': createdAt.toString()},
      'adminPin': {'stringValue': adminPin},
    };
  }

  static Future<void> savePost({
    AppPost? existing,
    required String title,
    required String message,
    required String imageUrl,
    bool active = true,
  }) async {
    final createdAt = existing?.createdAt == 0 || existing == null ? DateTime.now().millisecondsSinceEpoch : existing.createdAt;
    final payload = jsonEncode({
      'fields': _fields(title: title, message: message, imageUrl: imageUrl, active: active, createdAt: createdAt),
    });

    final http.Response res;
    if (existing == null) {
      res = await http.post(
        Uri.parse('$_base/posts'),
        headers: const {'Content-Type': 'application/json'},
        body: payload,
      ).timeout(const Duration(seconds: 15));
    } else {
      const masks = 'updateMask.fieldPaths=title&updateMask.fieldPaths=message&updateMask.fieldPaths=imageUrl&updateMask.fieldPaths=active&updateMask.fieldPaths=createdAt&updateMask.fieldPaths=adminPin';
      res = await http.patch(
        Uri.parse('https://firestore.googleapis.com/v1/${existing.name}?$masks'),
        headers: const {'Content-Type': 'application/json'},
        body: payload,
      ).timeout(const Duration(seconds: 15));
    }

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Upload failed (${res.statusCode}). Firebase rules check karo.');
    }
  }
}

class AdminPostsPreview extends StatefulWidget {
  const AdminPostsPreview({super.key});

  @override
  State<AdminPostsPreview> createState() => _AdminPostsPreviewState();
}

class _AdminPostsPreviewState extends State<AdminPostsPreview> {
  List<AppPost> posts = const [];
  String? error;
  bool loading = true;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _load();
    timer = Timer.periodic(const Duration(seconds: 18), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent && mounted) setState(() => loading = true);
    try {
      final data = await AdminPostsApi.fetchPosts();
      if (!mounted) return;
      setState(() {
        posts = data;
        error = null;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = posts.take(3).toList();
    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.campaign_outlined, color: AppColor.cyan),
          const SizedBox(width: 8),
          const Expanded(child: Text('Admin Updates', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          InkWell(onTap: () => _load(), child: const Icon(Icons.refresh, color: AppColor.muted, size: 20)),
        ]),
        const SizedBox(height: 10),
        if (loading)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: LinearProgressIndicator(minHeight: 2),
          )
        else if (visible.isEmpty)
          Text(
            error == null ? 'Admin post upload karoge to yahan user app me show hoga.' : 'Posts abhi connect nahi hue. Firebase rules check karo.',
            style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700),
          )
        else
          ...visible.map((post) => AdminPostCard(post: post)).toList(),
      ]),
    );
  }
}

class AdminPostCard extends StatelessWidget {
  final AppPost post;
  const AdminPostCard({super.key, required this.post});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AppColor.bg2, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColor.line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (post.imageUrl.trim().isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(9),
              child: Image.network(
                post.imageUrl,
                height: 120,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
          ),
        Text(post.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
        if (post.message.trim().isNotEmpty) ...[
          const SizedBox(height: 5),
          Text(post.message, style: const TextStyle(color: AppColor.muted, height: 1.35, fontWeight: FontWeight.w700)),
        ],
      ]),
    );
  }
}


class TeamLogo extends StatelessWidget {
  final String code;
  final double size;
  final bool showCode;
  const TeamLogo({super.key, required this.code, this.size = 52, this.showCode = true});

  @override
  Widget build(BuildContext context) {
    final display = code.toUpperCase();
    return SizedBox(
      width: size + 12,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _circle(display),
          if (showCode) ...[
            const SizedBox(height: 4),
            Text(display, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: size < 40 ? 9 : 11, fontWeight: FontWeight.w900)),
          ],
        ],
      ),
    );
  }

  Widget _circle(String c) {
    if (c.contains('SCO')) return _scotland();
    if (c.contains('SL')) return _sriLanka();
    if (c.contains('IND')) return _emoji('🇮🇳');
    if (c.contains('AUS')) return _emoji('🇦🇺');
    if (c.contains('PAK')) return _emoji('🇵🇰');
    if (c.contains('ENG')) return _england();
    if (c.contains('NZ')) return _emoji('🇳🇿');
    if (c.contains('WI')) return _emoji('🏝️');
    if (c.contains('RSA') || c.contains('SA')) return _emoji('🇿🇦');
    if (c.contains('BAN')) return _emoji('🇧🇩');
    if (c.contains('NED')) return _emoji('🇳🇱');

    Color color = AppColor.blue;
    if (c == 'CSK') color = AppColor.yellow;
    if (c == 'MI') color = const Color(0xFF0458A7);
    if (c == 'RCB') color = const Color(0xFFD71920);
    if (c == 'KKR') color = const Color(0xFF3A1A78);
    if (c == 'SRH') color = const Color(0xFFF26522);
    if (c == 'RR') color = const Color(0xFFE91E8F);
    if (c == 'DC') color = const Color(0xFF17449B);
    if (c == 'GT') color = const Color(0xFF0B2545);
    if (c == 'LSG') color = const Color(0xFF00AEEF);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, border: Border.all(color: Colors.white24)),
      child: Center(child: Text(c.length > 4 ? c.substring(0, 4) : c, style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.white))),
    );
  }

  Widget _emoji(String emoji) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: Colors.white54)),
      child: Center(child: Text(emoji, style: TextStyle(fontSize: size * 0.56))),
    );
  }

  Widget _scotland() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF0F66B7), border: Border.all(color: Colors.white24)),
      child: ClipOval(
        child: Stack(children: [
          Center(child: Transform.rotate(angle: 0.78, child: Container(width: size * 1.5, height: size * 0.13, color: Colors.white))),
          Center(child: Transform.rotate(angle: -0.78, child: Container(width: size * 1.5, height: size * 0.13, color: Colors.white))),
        ]),
      ),
    );
  }

  Widget _sriLanka() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: AppColor.yellow, border: Border.all(color: Colors.white24)),
      child: Center(child: Text('🇱🇰', style: TextStyle(fontSize: size * 0.50))),
    );
  }

  Widget _england() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: Colors.white54)),
      child: ClipOval(
        child: Stack(children: [
          Container(color: Colors.white),
          Center(child: Container(width: size, height: size * 0.16, color: AppColor.red)),
          Center(child: Container(width: size * 0.16, height: size, color: AppColor.red)),
        ]),
      ),
    );
  }
}

class TournamentLogo extends StatelessWidget {
  final double size;
  const TournamentLogo({super.key, this.size = 68});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: const LinearGradient(colors: [Color(0xFFEEFBFF), Color(0xFF7E41E8), Color(0xFFFF3F92)]),
      ),
      child: Center(
        child: Text('T20\nWORLD\nCUP', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: size * 0.16, fontWeight: FontWeight.w900)),
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final bool selected;
  final Color color;
  const Pill(this.text, {super.key, this.selected = false, this.color = AppColor.cyan});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(color: selected ? AppColor.header : AppColor.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: selected ? AppColor.header : AppColor.line)),
      child: Center(child: Text(text, style: TextStyle(color: selected ? Colors.white : AppColor.muted, fontWeight: FontWeight.w900))),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900));
  }
}
