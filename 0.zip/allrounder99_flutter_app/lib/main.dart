
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const Allrounder99AdminApp());
}

class AppColor {
  static const bg = Color(0xFF07111F);
  static const bg2 = Color(0xFF0D1B2A);
  static const card = Color(0xFF152535);
  static const cyan = Color(0xFF16D9FF);
  static const green = Color(0xFF18A66A);
  static const red = Color(0xFFE8495B);
  static const yellow = Color(0xFFFFD166);
  static const text = Color(0xFFEAF2F8);
  static const muted = Color(0xFFAAB7C4);
  static const line = Color(0x263B4A5A);
}

class Allrounder99AdminApp extends StatelessWidget {
  const Allrounder99AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Allrounder99 Admin',
      debugShowCheckedModeBanner: false,
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaler: const TextScaler.linear(0.92)),
          child: child ?? const SizedBox.shrink(),
        );
      },
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColor.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.cyan, brightness: Brightness.dark),
        fontFamily: 'Roboto',
      ),
      home: const AdminPanelPage(),
    );
  }
}

class AppPost {
  final String name;
  final String title;
  final String message;
  final String imageUrl;
  final String imageBase64;
  final String imageType;
  final bool active;
  final int createdAt;

  const AppPost({
    required this.name,
    required this.title,
    required this.message,
    required this.imageUrl,
    required this.imageBase64,
    required this.imageType,
    required this.active,
    required this.createdAt,
  });

  factory AppPost.fromFirestore(Map<String, dynamic> doc) {
    final fields = (doc['fields'] as Map<String, dynamic>?) ?? {};
    String stringValue(String key) {
      final value = fields[key];
      if (value is Map && value['stringValue'] != null) return value['stringValue'].toString();
      if (value is Map && value['integerValue'] != null) return value['integerValue'].toString();
      return '';
    }

    bool boolValue(String key, {bool fallback = true}) {
      final value = fields[key];
      if (value is Map && value['booleanValue'] != null) return value['booleanValue'] == true;
      return fallback;
    }

    int intValue(String key) {
      final value = fields[key];
      if (value is Map && value['integerValue'] != null) return int.tryParse(value['integerValue'].toString()) ?? 0;
      if (value is Map && value['stringValue'] != null) return int.tryParse(value['stringValue'].toString()) ?? 0;
      return 0;
    }

    return AppPost(
      name: (doc['name'] ?? '').toString(),
      title: stringValue('title'),
      message: stringValue('message'),
      imageUrl: stringValue('imageUrl'),
      imageBase64: stringValue('imageBase64'),
      imageType: stringValue('imageType').isEmpty ? 'image/jpeg' : stringValue('imageType'),
      active: boolValue('active'),
      createdAt: intValue('createdAt'),
    );
  }
}

class AdminPostsApi {
  static const String projectId = 'allrounder99-806a4';
  static const String adminPin = 'A99@2026';
  static const String _base = 'https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents';

  static Future<List<AppPost>> fetchPosts() async {
    final uri = Uri.parse('$_base/posts?pageSize=50');
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode == 404) return <AppPost>[];
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Posts connect nahi hua (${res.statusCode})');
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    final docs = (body['documents'] as List?) ?? const [];
    final posts = docs
        .whereType<Map<String, dynamic>>()
        .map(AppPost.fromFirestore)
        .where((post) => post.active && (post.title.trim().isNotEmpty || post.message.trim().isNotEmpty))
        .toList();
    posts.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return posts;
  }

  static Map<String, dynamic> _fields({
    required String title,
    required String message,
    required String imageUrl,
    required String imageBase64,
    required String imageType,
    required bool active,
    required int createdAt,
  }) {
    return {
      'title': {'stringValue': title.trim()},
      'message': {'stringValue': message.trim()},
      'imageUrl': {'stringValue': imageUrl.trim()},
      'imageBase64': {'stringValue': imageBase64.trim()},
      'imageType': {'stringValue': imageType.trim().isEmpty ? 'image/jpeg' : imageType.trim()},
      'active': {'booleanValue': active},
      'createdAt': {'integerValue': createdAt.toString()},
      'adminPin': {'stringValue': adminPin},
    };
  }

  static Future<void> savePost({
    AppPost? existing,
    required String title,
    required String message,
    required String imageUrl,
    required String imageBase64,
    required String imageType,
    bool active = true,
  }) async {
    final createdAt = existing == null || existing.createdAt == 0 ? DateTime.now().millisecondsSinceEpoch : existing.createdAt;
    final payload = jsonEncode({
      'fields': _fields(title: title, message: message, imageUrl: imageUrl, imageBase64: imageBase64, imageType: imageType, active: active, createdAt: createdAt),
    });

    final http.Response res;
    if (existing == null) {
      res = await http.post(
        Uri.parse('$_base/posts'),
        headers: const {'Content-Type': 'application/json'},
        body: payload,
      ).timeout(const Duration(seconds: 15));
    } else {
      const masks = 'updateMask.fieldPaths=title&updateMask.fieldPaths=message&updateMask.fieldPaths=imageUrl&updateMask.fieldPaths=imageBase64&updateMask.fieldPaths=imageType&updateMask.fieldPaths=active&updateMask.fieldPaths=createdAt&updateMask.fieldPaths=adminPin';
      res = await http.patch(
        Uri.parse('https://firestore.googleapis.com/v1/${existing.name}?$masks'),
        headers: const {'Content-Type': 'application/json'},
        body: payload,
      ).timeout(const Duration(seconds: 15));
    }

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Upload failed (${res.statusCode}). Firebase Rules check karo.');
    }
  }
}

class AdminPanelPage extends StatefulWidget {
  const AdminPanelPage({super.key});

  @override
  State<AdminPanelPage> createState() => _AdminPanelPageState();
}

class _AdminPanelPageState extends State<AdminPanelPage> {
  final pinController = TextEditingController();
  final titleController = TextEditingController();
  final messageController = TextEditingController();
  final imageController = TextEditingController();

  String imageBase64 = '';
  String imageType = 'image/jpeg';
  bool processingImage = false;

  bool unlocked = false;
  bool saving = false;
  bool loading = false;
  String status = '';
  List<AppPost> posts = const [];
  AppPost? editingPost;

  @override
  void dispose() {
    pinController.dispose();
    titleController.dispose();
    messageController.dispose();
    imageController.dispose();
    super.dispose();
  }

  Future<void> _refreshPosts() async {
    setState(() => loading = true);
    try {
      final data = await AdminPostsApi.fetchPosts();
      if (!mounted) return;
      setState(() {
        posts = data;
        status = data.isEmpty ? 'Abhi koi post nahi hai.' : 'Posts loaded';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => status = e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _unlock() {
    if (pinController.text.trim() == AdminPostsApi.adminPin) {
      setState(() {
        unlocked = true;
        status = 'Admin unlocked';
      });
      _refreshPosts();
    } else {
      setState(() => status = 'Wrong PIN');
    }
  }


  Future<void> _pickImageFromGallery() async {
    try {
      setState(() {
        processingImage = true;
        status = 'Opening gallery...';
      });

      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (picked == null) {
        if (mounted) {
          setState(() {
            processingImage = false;
            status = 'No image selected';
          });
        }
        return;
      }

      final bytes = await File(picked.path).readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) {
        if (mounted) {
          setState(() {
            processingImage = false;
            status = 'Image read nahi hua';
          });
        }
        return;
      }

      img.Image resized = decoded;
      if (decoded.width > 900) {
        resized = img.copyResize(decoded, width: 900);
      }
      var jpgBytes = img.encodeJpg(resized, quality: 62);

      if (jpgBytes.length > 850000) {
        resized = img.copyResize(decoded, width: 650);
        jpgBytes = img.encodeJpg(resized, quality: 52);
      }

      if (jpgBytes.length > 950000) {
        if (mounted) {
          setState(() {
            processingImage = false;
            status = 'Image bahut large hai. Small image select karo.';
          });
        }
        return;
      }

      if (!mounted) return;
      setState(() {
        imageBase64 = base64Encode(jpgBytes);
        imageType = 'image/jpeg';
        imageController.clear();
        processingImage = false;
        status = 'Gallery image selected ✅';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        processingImage = false;
        status = 'Gallery image failed: $e';
      });
    }
  }

  void _removeSelectedImage() {
    setState(() {
      imageBase64 = '';
      imageType = 'image/jpeg';
      status = 'Image removed';
    });
  }

  Future<void> _savePost() async {
    final title = titleController.text.trim();
    final message = messageController.text.trim();
    final image = imageController.text.trim();

    if (title.isEmpty && message.isEmpty) {
      setState(() => status = 'Title ya message likho');
      return;
    }

    setState(() {
      saving = true;
      status = editingPost == null ? 'Uploading...' : 'Updating...';
    });

    try {
      await AdminPostsApi.savePost(existing: editingPost, title: title, message: message, imageUrl: image, imageBase64: imageBase64, imageType: imageType);
      titleController.clear();
      messageController.clear();
      imageController.clear();
      imageBase64 = '';
      imageType = 'image/jpeg';
      editingPost = null;
      await _refreshPosts();
      if (!mounted) return;
      setState(() => status = 'Done ✅ User app me show hoga');
    } catch (e) {
      if (!mounted) return;
      setState(() => status = e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void _edit(AppPost post) {
    setState(() {
      editingPost = post;
      titleController.text = post.title;
      messageController.text = post.message;
      imageController.text = post.imageUrl;
      imageBase64 = post.imageBase64;
      imageType = post.imageType;
      status = 'Editing post';
    });
  }

  Future<void> _hide(AppPost post) async {
    setState(() {
      saving = true;
      status = 'Hiding post...';
    });
    try {
      await AdminPostsApi.savePost(existing: post, title: post.title, message: post.message, imageUrl: post.imageUrl, imageBase64: post.imageBase64, imageType: post.imageType, active: false);
      await _refreshPosts();
      if (mounted) setState(() => status = 'Post hidden');
    } catch (e) {
      if (mounted) setState(() => status = e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  InputDecoration _decoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: AppColor.cyan),
      filled: true,
      fillColor: AppColor.bg2,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColor.line)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF07111F), Color(0xFF0B2130)]),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(children: [
                Image.asset('assets/logo.png', width: 62, height: 62, errorBuilder: (_, __, ___) => const Icon(Icons.admin_panel_settings, size: 58, color: AppColor.cyan)),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Allrounder99 Admin', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                    SizedBox(height: 4),
                    Text('Post upload panel', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)),
                  ]),
                ),
                if (unlocked) IconButton(onPressed: _refreshPosts, icon: const Icon(Icons.refresh)),
              ]),
              const SizedBox(height: 18),
              if (!unlocked) _loginCard() else _uploadPanel(),
              if (unlocked) ...[
                const SizedBox(height: 16),
                _statusCard(),
                const SizedBox(height: 16),
                _postsList(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _loginCard() {
    return _card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Admin Login', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        const Text('Post upload karne ke liye admin PIN enter karo.', style: TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        TextField(controller: pinController, obscureText: true, decoration: _decoration('Admin PIN', Icons.lock_outline)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _unlock, icon: const Icon(Icons.login), label: const Text('Unlock'))),
        if (status.isNotEmpty) ...[
          const SizedBox(height: 10),
          Text(status, style: const TextStyle(color: AppColor.yellow, fontWeight: FontWeight.w900)),
        ],
      ]),
    );
  }

  Widget _uploadPanel() {
    return _card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(editingPost == null ? 'Upload Post' : 'Edit Post', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        TextField(controller: titleController, decoration: _decoration('Post title', Icons.title)),
        const SizedBox(height: 10),
        TextField(controller: messageController, minLines: 3, maxLines: 6, decoration: _decoration('Post message', Icons.message_outlined)),
        const SizedBox(height: 10),
        TextField(controller: imageController, decoration: _decoration('Image URL optional', Icons.link)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: processingImage ? null : _pickImageFromGallery,
              icon: processingImage ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.photo_library_outlined),
              label: Text(processingImage ? 'Processing...' : 'Choose from Gallery'),
            ),
          ),
          if (imageBase64.isNotEmpty) ...[
            const SizedBox(width: 8),
            IconButton(onPressed: _removeSelectedImage, icon: const Icon(Icons.delete_outline, color: AppColor.red)),
          ],
        ]),
        if (imageBase64.isNotEmpty) ...[
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.memory(base64Decode(imageBase64), height: 150, width: double.infinity, fit: BoxFit.cover),
          ),
        ],
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: saving ? null : _savePost,
              icon: saving ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.cloud_upload_outlined),
              label: Text(editingPost == null ? 'Upload Post' : 'Update Post'),
            ),
          ),
          if (editingPost != null) ...[
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: () {
                setState(() {
                  editingPost = null;
                  titleController.clear();
                  messageController.clear();
                  imageController.clear();
                  imageBase64 = '';
                  imageType = 'image/jpeg';
                });
              },
              child: const Text('Cancel'),
            ),
          ],
        ]),
      ]),
    );
  }

  Widget _statusCard() {
    return _card(
      padding: const EdgeInsets.all(12),
      child: Row(children: [
        Icon(loading ? Icons.sync : Icons.info_outline, color: AppColor.cyan),
        const SizedBox(width: 10),
        Expanded(child: Text(status.isEmpty ? 'Ready' : status, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColor.muted))),
      ]),
    );
  }

  Widget _postsList() {
    if (loading && posts.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (posts.isEmpty) {
      return _card(child: const Text('Abhi koi post nahi hai.', style: TextStyle(color: AppColor.muted)));
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Uploaded Posts', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        ...posts.map((post) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _card(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  AdminPostCard(post: post),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(onPressed: () => _edit(post), icon: const Icon(Icons.edit_outlined), label: const Text('Edit'))),
                    const SizedBox(width: 8),
                    Expanded(child: OutlinedButton.icon(onPressed: () => _hide(post), icon: const Icon(Icons.visibility_off_outlined), label: const Text('Hide'))),
                  ]),
                ]),
              ),
            )),
      ],
    );
  }

  Widget _card({required Widget child, EdgeInsetsGeometry padding = const EdgeInsets.all(16)}) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: AppColor.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColor.line),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 18, offset: Offset(0, 8))],
      ),
      child: child,
    );
  }
}

class AdminPostCard extends StatelessWidget {
  final AppPost post;
  const AdminPostCard({super.key, required this.post});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (post.imageBase64.trim().isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.memory(
              base64Decode(post.imageBase64),
              height: 140,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
        )
      else if (post.imageUrl.trim().isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              post.imageUrl,
              height: 140,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
        ),
      Text(post.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
      if (post.message.trim().isNotEmpty) ...[
        const SizedBox(height: 6),
        Text(post.message, style: const TextStyle(color: AppColor.muted, height: 1.35, fontWeight: FontWeight.w700)),
      ],
    ]);
  }
}
