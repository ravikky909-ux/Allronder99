# Allrounder99 Cricket Scoring App

This is a Flutter starter package for the **Allrounder99** Android cricket scoring app.
It includes a dark black + electric-blue UI, splash screen, home, fixtures, series, match details, scorecard/history, and a working manual scoring screen.

## What is included

- 4.5 second animated splash screen with Allrounder99 logo
- Home screen with featured match, filters, trending series, shorts, and bottom navigation
- Fixtures screen: day-wise match list
- Series screen: series-wise list with search UI
- Match detail screen: Live, Scorecard, History, Info, Commentary, Points Table tabs
- Manual scoring screen with 0/1/2/3/4/6, Wicket, Wide, No Ball, Bye, Leg Bye, Undo, and copy/share summary
- More screen with WhatsApp and website links
- Mock cricket data ready to replace with API data later

## How to build APK

1. Install Flutter SDK and Android Studio.
2. Create a fresh Flutter project:

```bash
flutter create allrounder99
```

3. Copy `lib/main.dart`, `assets/logo.png`, and `pubspec.yaml` from this package into the new `allrounder99` project.

4. Get packages:

```bash
flutter pub get
```

5. Test run:

```bash
flutter run
```

6. Build APK:

```bash
flutter build apk --release
```

Your APK will be here:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Important links in app

- WhatsApp: https://go.wa.link/allrounder99
- Website: https://Gamerush99.com

## Next production steps

- Add live cricket API integration
- Add Firebase/Supabase backend
- Add persistent match saving with Hive/SQLite
- Add app icon and native launch screen
- Add admin panel if live data is manually controlled
