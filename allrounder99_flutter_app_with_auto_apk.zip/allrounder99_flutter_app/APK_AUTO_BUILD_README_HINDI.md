# Allrounder99 APK Auto Build — Sabse Easy Tarika

Aapko coding ya Android Studio chalana nahi aata to ye method use karo.

## Step 1: ZIP extract karo
`allrounder99_flutter_app.zip` ko laptop/PC par extract karo.

## Step 2: GitHub par upload karo
1. github.com open karo
2. New repository banao: `allrounder99`
3. Extracted folder ke saare files upload karo
4. Commit changes dabao

## Step 3: APK build start karo
1. Repo ke andar **Actions** tab open karo
2. Left side me **Build Allrounder99 APK** select karo
3. **Run workflow** dabao
4. 5–10 minute wait karo

## Step 4: APK download karo
Build complete hone ke baad page ke bottom me **Artifacts** section dikhega.
Usme **Allrounder99-APK** download karo.
ZIP ke andar `app-release.apk` milega.

## APK install kaise karna
1. APK phone me bhejo
2. Phone me **Install unknown apps** allow karo
3. `app-release.apk` install karo

## Included app features
- 4.5 sec splash screen
- Allrounder99 logo
- Black + blue theme
- Home, Fixtures, Series, More
- Match detail: Live, Scorecard, History
- Manual scoring panel
- 0/1/2/3/4/6/Wicket/Wide/No Ball/Bye/Leg Bye
- Undo and copy/share summary

Note: Ye starter APK hai. Isme demo/mock match data hai. Live real API baad me integrate karni hogi.
