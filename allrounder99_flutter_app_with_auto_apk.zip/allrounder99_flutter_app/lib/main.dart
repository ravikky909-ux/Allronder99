import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const Allrounder99App());
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Allrounder99',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.cyan,
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),
      home: const SplashScreen(),
    );
  }
}

class AppColors {
  static const Color bg = Color(0xFF05070B);
  static const Color bg2 = Color(0xFF07111A);
  static const Color panel = Color(0xFF0B141E);
  static const Color panel2 = Color(0xFF101B27);
  static const Color border = Color(0xFF203543);
  static const Color cyan = Color(0xFF00D9FF);
  static const Color cyan2 = Color(0xFF00A8D7);
  static const Color muted = Color(0xFF9AA6B2);
  static const Color green = Color(0xFF30C66B);
  static const Color orange = Color(0xFFCA842C);
  static const Color red = Color(0xFFE44E57);
  static const Color purple = Color(0xFF7857D8);
}

TextStyle get h1 => const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: -0.3);
TextStyle get h2 => const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: -0.2);
TextStyle get h3 => const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white);
TextStyle get body => const TextStyle(fontSize: 15, color: Colors.white);
TextStyle get muted => const TextStyle(fontSize: 14, color: AppColors.muted);

String oversText(int legalBalls) => '${legalBalls ~/ 6}.${legalBalls % 6}';

BoxDecoration premiumDecoration({bool active = false, double radius = 18}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: active
          ? [AppColors.cyan.withOpacity(0.22), AppColors.panel, AppColors.bg2]
          : [AppColors.panel2.withOpacity(0.96), AppColors.panel.withOpacity(0.98)],
    ),
    border: Border.all(color: active ? AppColors.cyan : AppColors.border, width: active ? 1.4 : 1),
    boxShadow: active
        ? [BoxShadow(color: AppColors.cyan.withOpacity(0.18), blurRadius: 24, offset: const Offset(0, 10))]
        : [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 8))],
  );
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 4500));
    _scale = Tween<double>(begin: 0.82, end: 1.0).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _opacity = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.35, curve: Curves.easeOut)));
    _controller.forward();
    Timer(const Duration(milliseconds: 4500), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const RootShell()));
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.0,
            colors: [Color(0xFF063E4B), AppColors.bg],
          ),
        ),
        child: Center(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (_, child) {
              return Opacity(
                opacity: _opacity.value,
                child: Transform.scale(
                  scale: _scale.value,
                  child: Container(
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.35), blurRadius: 70, spreadRadius: 8)],
                    ),
                    child: Image.asset('assets/logo.png', width: 220, fit: BoxFit.contain),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class Team {
  final String name;
  final String shortName;
  final Color color;
  final String initials;
  const Team(this.name, this.shortName, this.color, this.initials);
}

class MatchItem {
  final String series;
  final String matchNo;
  final String time;
  final Team teamA;
  final Team teamB;
  final String scoreA;
  final String scoreB;
  final String result;
  final String status;
  final String venue;
  const MatchItem({
    required this.series,
    required this.matchNo,
    required this.time,
    required this.teamA,
    required this.teamB,
    required this.scoreA,
    required this.scoreB,
    required this.result,
    required this.status,
    required this.venue,
  });
}

class SeriesItem {
  final String name;
  final String dates;
  final String matches;
  final String status;
  final Color color;
  final String initials;
  const SeriesItem(this.name, this.dates, this.matches, this.status, this.color, this.initials);
}

const Team freedom = Team('Freedom', 'Freedom', Color(0xFFFF8C9D), 'WF');
const Team orcas = Team('Orcas', 'Orcas', Color(0xFFE14347), 'SO');
const Team royals = Team('Capital Amaravati Royals', 'Royals', Color(0xFFB6133B), 'CAR');
const Team sunshiners = Team('Vijayawada Sunshiners', 'Sunshiners', Color(0xFF2348C8), 'VS');
const Team warwickshire = Team('Warwickshire Women', 'Warwickshire', Color(0xFFEFF4FF), 'WW');
const Team surrey = Team('Surrey Women', 'Surrey', Color(0xFF5A2E19), 'SW');

const MatchItem featuredMatch = MatchItem(
  series: 'Major League Cricket 2026',
  matchNo: '9th Match',
  time: '07:00 AM',
  teamA: orcas,
  teamB: freedom,
  scoreA: '227-6 (20.0)',
  scoreB: '139-10 (16.2)',
  result: 'Seattle Orcas won by 88 runs',
  status: 'Finished',
  venue: 'Dallas, USA',
);

final List<MatchItem> fixtures = [
  const MatchItem(
    series: 'Major League Cricket 2026',
    matchNo: '9th Match',
    time: '07:00 AM',
    teamA: freedom,
    teamB: orcas,
    scoreA: '139-10 (16.2 Overs)',
    scoreB: '227-6 (20.0 Overs)',
    result: 'Seattle Orcas won by 88 runs',
    status: 'Finished',
    venue: 'Dallas, USA',
  ),
  const MatchItem(
    series: 'Andhra Premier League 2026',
    matchNo: '25th Match',
    time: '02:00 PM',
    teamA: royals,
    teamB: sunshiners,
    scoreA: '',
    scoreB: '',
    result: '',
    status: 'Upcoming',
    venue: 'Amaravathi, India',
  ),
  const MatchItem(
    series: 'Women T20 Blast 2026',
    matchNo: '28th Match',
    time: '03:30 PM',
    teamA: warwickshire,
    teamB: surrey,
    scoreA: '',
    scoreB: '',
    result: '',
    status: 'Upcoming',
    venue: 'Birmingham, England',
  ),
  const MatchItem(
    series: 'The Hundred Women 2026',
    matchNo: '15th Match',
    time: '07:00 PM',
    teamA: Team('Southern Brave Women', 'Southern Brave', Color(0xFF79D900), 'SB'),
    teamB: Team('London Spirit Women', 'London Spirit', Color(0xFF1643F5), 'LS'),
    scoreA: '',
    scoreB: '',
    result: '',
    status: 'Upcoming',
    venue: 'Southampton, England',
  ),
];

final List<SeriesItem> seriesItems = [
  const SeriesItem('Vidarbha Premier League 2026', '01 Jun - 14 Jun', '25 Matches', 'Finished', Color(0xFFC99622), 'VPL'),
  const SeriesItem('T20 Mumbai 2026', '01 Jun - 13 Jun', '23 Matches', 'Finished', Color(0xFF1767D1), 'T20'),
  const SeriesItem('Asian Legends League 2026', '02 Jun - 14 Jun', '19 Matches', 'Postponed', Color(0xFFC91E2B), 'ALL'),
  const SeriesItem('Ireland Inter-Provincial T20 Trophy 2026', '02 Jun - 17 Jun', '9 Matches', 'Finished', Color(0xFF0C8D3F), 'IRE'),
  const SeriesItem('Madhya Pradesh T20 League 2026', '03 Jun - 26 Jun', '48 Matches', 'Ongoing', Color(0xFF0F399C), 'MPT'),
  const SeriesItem('Sri Lanka tour of West Indies 2026', '04 Jun - 18 Jun', '5 Matches', 'Ongoing', Color(0xFF9B174A), 'SL'),
];

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(
        openMatch: _openMatch,
        startManualScoring: _startManualScoring,
      ),
      const ShortsScreen(),
      FixturesScreen(openMatch: _openMatch),
      SeriesScreen(openSeries: () => setState(() => _index = 2)),
      MoreScreen(startManualScoring: _startManualScoring),
    ];

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: screens[_index]),
          Align(
            alignment: Alignment.bottomCenter,
            child: PremiumBottomNav(currentIndex: _index, onTap: (i) => setState(() => _index = i)),
          ),
        ],
      ),
    );
  }

  void _openMatch() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchDetailScreen()));
  }

  void _startManualScoring() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ManualScoringScreen()));
  }
}

class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.topRight,
          radius: 1.1,
          colors: [Color(0xFF072A35), AppColors.bg],
        ),
      ),
      child: SafeArea(child: child),
    );
  }
}

class AppHeader extends StatelessWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
      child: Row(
        children: [
          Image.asset('assets/logo.png', width: 174, height: 56, fit: BoxFit.contain),
          const Spacer(),
          IconButtonGlass(icon: Icons.search, onTap: () {}),
          const SizedBox(width: 10),
          IconButtonGlass(icon: Icons.settings_outlined, onTap: () {}),
        ],
      ),
    );
  }
}

class IconButtonGlass extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const IconButtonGlass({super.key, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.white.withOpacity(0.04),
          border: Border.all(color: AppColors.border),
        ),
        child: Icon(icon, color: Colors.white, size: 28),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final VoidCallback openMatch;
  final VoidCallback startManualScoring;
  const HomeScreen({super.key, required this.openMatch, required this.startManualScoring});

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 110),
        children: [
          const AppHeader(),
          const TopTabs(labels: ['Featured', 'Live', 'WT20 WC'], activeIndex: 0),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GestureDetector(onTap: openMatch, child: FeaturedMatchCard(match: featuredMatch)),
          ),
          const SizedBox(height: 18),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: const [
                FilterChipPill(label: 'All', icon: Icons.grid_view_rounded, active: true),
                FilterChipPill(label: 'T20', icon: Icons.sports_cricket_rounded),
                FilterChipPill(label: 'ODI', icon: Icons.sports_baseball_rounded),
                FilterChipPill(label: 'Test', icon: Icons.sports_rounded),
                FilterChipPill(label: 'Leagues', icon: Icons.emoji_events_outlined),
              ],
            ),
          ),
          const SizedBox(height: 22),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: PrimaryActionCard(
              title: 'Start Manual Scoring',
              subtitle: 'Create local match and score ball by ball',
              icon: Icons.sports_cricket_rounded,
              onTap: startManualScoring,
            ),
          ),
          const SizedBox(height: 22),
          const SectionHeader(title: 'Trending Series'),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: TrendingSeriesCard(),
          ),
          const SizedBox(height: 22),
          const SectionHeader(title: 'Popular Shorts'),
          SizedBox(
            height: 180,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              children: const [
                ShortCard(title: 'First hurdle on fire! 🔥', duration: '0:29', color: Color(0xFF1473AA), icon: Icons.sports_cricket),
                ShortCard(title: '12 record wickets 🚀', duration: '0:26', color: Color(0xFFB96826), icon: Icons.sports_baseball),
                ShortCard(title: 'Sanju Samson 👑', duration: '0:31', color: Color(0xFF174DB6), icon: Icons.handshake_rounded),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FeaturedMatchCard extends StatelessWidget {
  final MatchItem match;
  const FeaturedMatchCard({super.key, required this.match});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: premiumDecoration(active: true, radius: 18),
      child: Column(
        children: [
          StatusPill(label: match.status),
          const SizedBox(height: 10),
          Text('${match.series} • ${match.matchNo}', style: muted.copyWith(fontSize: 15)),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: ScoreTeamBlock(team: match.teamA, score: match.scoreA)),
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.cyan.withOpacity(0.1)),
                child: const Icon(Icons.bolt, color: AppColors.cyan, size: 38),
              ),
              Expanded(child: ScoreTeamBlock(team: match.teamB, score: match.scoreB, alignRight: true)),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: Colors.black.withOpacity(0.2),
              border: Border.all(color: AppColors.cyan.withOpacity(0.45)),
            ),
            child: Text(match.result, textAlign: TextAlign.center, style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}

class ScoreTeamBlock extends StatelessWidget {
  final Team team;
  final String score;
  final bool alignRight;
  const ScoreTeamBlock({super.key, required this.team, required this.score, this.alignRight = false});

  @override
  Widget build(BuildContext context) {
    final parts = score.split(' ');
    final mainScore = parts.isNotEmpty ? parts.first : '';
    final overs = score.replaceFirst(mainScore, '').trim();
    return Column(
      crossAxisAlignment: alignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        TeamBadge(team: team, size: 70),
        const SizedBox(height: 8),
        Text(mainScore, style: h1.copyWith(fontSize: 30)),
        Text(overs, style: muted.copyWith(color: Colors.white70)),
        const SizedBox(height: 8),
        Text(team.shortName, style: h3.copyWith(fontSize: 18)),
      ],
    );
  }
}

class TeamBadge extends StatelessWidget {
  final Team team;
  final double size;
  const TeamBadge({super.key, required this.team, this.size = 56});

  @override
  Widget build(BuildContext context) {
    final isLight = team.color.computeLuminance() > 0.55;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [team.color.withOpacity(0.95), team.color.withOpacity(0.58)]),
        border: Border.all(color: Colors.white.withOpacity(0.18), width: 1.3),
        boxShadow: [BoxShadow(color: team.color.withOpacity(0.25), blurRadius: 14)],
      ),
      alignment: Alignment.center,
      child: Text(
        team.initials,
        textAlign: TextAlign.center,
        style: TextStyle(color: isLight ? Colors.black : Colors.white, fontWeight: FontWeight.w900, fontSize: size * 0.25),
      ),
    );
  }
}

class TopTabs extends StatelessWidget {
  final List<String> labels;
  final int activeIndex;
  const TopTabs({super.key, required this.labels, required this.activeIndex});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          Row(
            children: List.generate(labels.length, (i) {
              final active = i == activeIndex;
              return Expanded(
                child: Column(
                  children: [
                    Text(labels[i], style: h3.copyWith(color: active ? AppColors.cyan : Colors.white54, fontSize: 17)),
                    const SizedBox(height: 12),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: active ? 110 : 0,
                      height: 3,
                      decoration: BoxDecoration(color: AppColors.cyan, borderRadius: BorderRadius.circular(2)),
                    ),
                  ],
                ),
              );
            }),
          ),
          Container(height: 1, color: AppColors.border),
        ],
      ),
    );
  }
}

class FilterChipPill extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool active;
  const FilterChipPill({super.key, required this.label, this.icon, this.active = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 12),
      decoration: premiumDecoration(active: active, radius: 14),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, color: active ? Colors.white : Colors.white70, size: 18),
            const SizedBox(width: 8),
          ],
          Text(label, style: body.copyWith(fontWeight: FontWeight.w700, color: active ? Colors.white : Colors.white70)),
        ],
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  const SectionHeader({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(
        children: [
          Text(title, style: h2),
          const Spacer(),
          Text('View all', style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w700)),
          const SizedBox(width: 6),
          const Icon(Icons.arrow_forward_ios_rounded, color: AppColors.cyan, size: 16),
        ],
      ),
    );
  }
}

class TrendingSeriesCard extends StatelessWidget {
  const TrendingSeriesCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: premiumDecoration(radius: 18),
      child: Row(
        children: [
          Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(colors: [Color(0xFFFFE9FF), Color(0xFF5FD9FF)]),
            ),
            child: const Center(child: Text('T20\nWC\n2026', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF09131A), fontWeight: FontWeight.w900, fontSize: 18))),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Women’s T20 World Cup 2026', style: h3),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.calendar_month, size: 16, color: Colors.white70),
                    const SizedBox(width: 6),
                    Text('12 Jun - 05 Jul 2026  •  33 Matches', style: muted),
                  ],
                ),
                const SizedBox(height: 12),
                Text('Top teams. Epic battles. One Dream.', style: body.copyWith(color: AppColors.cyan)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: Colors.white70, size: 32),
        ],
      ),
    );
  }
}

class ShortCard extends StatelessWidget {
  final String title;
  final String duration;
  final Color color;
  final IconData icon;
  const ShortCard({super.key, required this.title, required this.duration, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      margin: const EdgeInsets.only(right: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(colors: [color.withOpacity(0.95), Colors.black]),
                border: Border.all(color: Colors.white24),
              ),
              child: Stack(
                children: [
                  Center(child: Icon(icon, color: Colors.white.withOpacity(0.9), size: 54)),
                  Positioned(left: 10, bottom: 10, child: CircleAvatar(radius: 16, backgroundColor: Colors.black.withOpacity(0.7), child: const Icon(Icons.play_arrow, color: Colors.white, size: 20))),
                  Positioned(right: 8, bottom: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3), decoration: BoxDecoration(color: Colors.black.withOpacity(0.8), borderRadius: BorderRadius.circular(8)), child: Text(duration, style: const TextStyle(fontSize: 12, color: Colors.white)))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: body.copyWith(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class PrimaryActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  const PrimaryActionCard({super.key, required this.title, required this.subtitle, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: premiumDecoration(active: true, radius: 18),
        child: Row(
          children: [
            CircleAvatar(radius: 25, backgroundColor: AppColors.cyan.withOpacity(0.16), child: Icon(icon, color: AppColors.cyan, size: 30)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: h3), const SizedBox(height: 4), Text(subtitle, style: muted)]),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, color: AppColors.cyan, size: 18),
          ],
        ),
      ),
    );
  }
}

class FixturesScreen extends StatelessWidget {
  final VoidCallback openMatch;
  const FixturesScreen({super.key, required this.openMatch});

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 112),
        children: [
          const AppHeader(),
          const TopTabs(labels: ['Day wise', 'Series wise', 'Team wise'], activeIndex: 0),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  FilterChipPill(label: 'All', active: true),
                  SizedBox(width: 10),
                  FilterChipPill(label: 'T20'),
                  SizedBox(width: 10),
                  FilterChipPill(label: 'ODI'),
                  SizedBox(width: 10),
                  FilterChipPill(label: 'Test'),
                  SizedBox(width: 10),
                  FilterChipPill(label: 'Hundred'),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            child: Row(children: [const Icon(Icons.calendar_month, color: Colors.white70), const SizedBox(width: 10), Text('Fri, 26 Jun 2026', style: h2)]),
          ),
          ...fixtures.map((m) => Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                child: GestureDetector(onTap: m.status == 'Finished' ? openMatch : null, child: FixtureCard(match: m)),
              )),
        ],
      ),
    );
  }
}

class FixtureCard extends StatelessWidget {
  final MatchItem match;
  const FixtureCard({super.key, required this.match});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: premiumDecoration(radius: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(match.series, style: h3),
                  const SizedBox(height: 4),
                  Text('${match.matchNo} • ${match.time}', style: muted),
                ]),
              ),
              StatusPill(label: match.status),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              TeamBadge(team: match.teamA, size: 58),
              const SizedBox(width: 12),
              Expanded(child: Text(match.teamA.shortName, style: h3.copyWith(fontSize: 17))),
              if (match.scoreA.isNotEmpty) Text(match.scoreA, style: h3.copyWith(fontSize: 17)),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 14), child: Icon(Icons.bolt, color: AppColors.cyan, size: 30)),
              if (match.scoreB.isNotEmpty) Text(match.scoreB, style: h3.copyWith(fontSize: 17)),
              Expanded(child: Text(match.teamB.shortName, textAlign: TextAlign.right, style: h3.copyWith(fontSize: 17))),
              const SizedBox(width: 12),
              TeamBadge(team: match.teamB, size: 58),
            ],
          ),
          const SizedBox(height: 14),
          Divider(color: AppColors.border),
          if (match.result.isNotEmpty)
            Center(child: Text(match.result, style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w800)))
          else
            Row(children: [const Icon(Icons.location_on_outlined, color: Colors.white70, size: 20), const SizedBox(width: 7), Text('Venue - ', style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w800)), Expanded(child: Text(match.venue, style: body))]),
        ],
      ),
    );
  }
}

class SeriesScreen extends StatelessWidget {
  final VoidCallback openSeries;
  const SeriesScreen({super.key, required this.openSeries});

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 112),
        children: [
          const AppHeader(),
          const TopTabs(labels: ['Day wise', 'Series wise', 'Team wise'], activeIndex: 1),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  FilterChipPill(label: 'All', active: true),
                  SizedBox(width: 10),
                  FilterChipPill(label: 'International'),
                  SizedBox(width: 10),
                  FilterChipPill(label: 'T20 Leagues'),
                  SizedBox(width: 10),
                  FilterChipPill(label: 'Domestic'),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              decoration: premiumDecoration(radius: 14),
              child: Row(children: [const Icon(Icons.search, color: Colors.white60), const SizedBox(width: 14), Text('Search Series', style: muted.copyWith(fontSize: 17))]),
            ),
          ),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text('June 2026', style: h2)),
          const SizedBox(height: 12),
          ...seriesItems.map((s) => Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: GestureDetector(onTap: openSeries, child: SeriesListCard(item: s)),
              )),
        ],
      ),
    );
  }
}

class SeriesListCard extends StatelessWidget {
  final SeriesItem item;
  const SeriesListCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: premiumDecoration(radius: 16),
      child: Row(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: LinearGradient(colors: [item.color, item.color.withOpacity(0.45)]), border: Border.all(color: Colors.white24)),
            child: Center(child: Text(item.initials, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900))),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.name, style: h3),
              const SizedBox(height: 8),
              Row(children: [const Icon(Icons.calendar_month, size: 16, color: Colors.white70), const SizedBox(width: 6), Text(item.dates, style: muted)]),
              const SizedBox(height: 5),
              Row(children: [const Icon(Icons.sports_baseball, size: 16, color: Colors.white70), const SizedBox(width: 6), Text(item.matches, style: muted)]),
            ]),
          ),
          StatusPill(label: item.status),
        ],
      ),
    );
  }
}

class StatusPill extends StatelessWidget {
  final String label;
  const StatusPill({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    Color c;
    switch (label.toLowerCase()) {
      case 'finished':
        c = AppColors.green;
        break;
      case 'upcoming':
        c = AppColors.orange;
        break;
      case 'live':
        c = AppColors.red;
        break;
      case 'ongoing':
        c = AppColors.red;
        break;
      case 'postponed':
        c = Colors.grey;
        break;
      default:
        c = AppColors.cyan;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: c.withOpacity(0.18), border: Border.all(color: c.withOpacity(0.85))),
      child: Text(label, style: TextStyle(color: c, fontWeight: FontWeight.w800, fontSize: 13)),
    );
  }
}

class MatchDetailScreen extends StatelessWidget {
  const MatchDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      initialIndex: 1,
      child: Scaffold(
        body: AppBackground(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(6, 8, 10, 0),
                child: Row(
                  children: [
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28)),
                    Expanded(
                      child: Column(children: [Text('Freedom vs Orcas', style: h3.copyWith(fontSize: 20)), Text('9th Match', style: muted)]),
                    ),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert, color: Colors.white, size: 28)),
                  ],
                ),
              ),
              TabBar(
                isScrollable: true,
                indicatorColor: AppColors.cyan,
                indicatorWeight: 3,
                labelColor: AppColors.cyan,
                unselectedLabelColor: Colors.white60,
                labelStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                tabs: const [
                  Tab(text: 'Info'),
                  Tab(text: 'Live'),
                  Tab(text: 'Commentary'),
                  Tab(text: 'Scorecard'),
                  Tab(text: 'History'),
                  Tab(text: 'Points Table'),
                ],
              ),
              const Expanded(
                child: TabBarView(
                  children: [
                    InfoTab(),
                    LiveTab(),
                    CommentaryTab(),
                    ScorecardTab(),
                    HistoryTab(),
                    PointsTableTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const FeaturedMatchCard(match: featuredMatch),
        const SizedBox(height: 14),
        const OverStrip(),
        const SizedBox(height: 14),
        const StatRow(items: {'Runs Needed': '89', 'Balls Rem.': '22', 'CRR': '8.51', 'RRR': '24.27', 'Target': '228'}),
        const SizedBox(height: 14),
        MiniTable(title: 'BATTING • Freedom', columns: const ['R', 'B', '4s', '6s', 'SR'], rows: const [
          ['🏏 Amila Aponso', '31', '13', '2', '2', '238.47'],
          ['S. Netravalkar (LHB)', '0', '0', '0', '0', '0.00'],
        ], footerLeft: 'P’ship: 0(0)', footerRight: 'Last Wkt: S. Netravalkar 7(5)'),
        const SizedBox(height: 14),
        MiniTable(title: 'BOWLING • Orcas', columns: const ['O', 'R', 'Wkt', 'Eco'], rows: const [
          ['Cameron Gannon 🔴', '2.2', '16', '2', '6.86'],
        ]),
        const SizedBox(height: 14),
        const ToolsCard(),
      ],
    );
  }
}

class OverStrip extends StatelessWidget {
  const OverStrip({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: premiumDecoration(radius: 14),
      child: Row(
        children: [
          const Icon(Icons.play_arrow, color: AppColors.green),
          const BallDot('0'),
          const BallDot('4', color: AppColors.cyan2),
          Text('= 6', style: h3.copyWith(fontSize: 15)),
          Container(width: 1, height: 30, margin: const EdgeInsets.symmetric(horizontal: 12), color: AppColors.border),
          Text('Over 17', style: h3.copyWith(fontSize: 16)),
          const SizedBox(width: 10),
          const BallDot('6', color: AppColors.purple),
          const BallDot('W', color: AppColors.red),
          const BallDot(''),
          const BallDot(''),
          const BallDot(''),
          const Spacer(),
          Text('= 6', style: h3.copyWith(fontSize: 15)),
        ],
      ),
    );
  }
}

class BallDot extends StatelessWidget {
  final String value;
  final Color? color;
  const BallDot(this.value, {super.key, this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 35,
      height: 35,
      margin: const EdgeInsets.only(right: 8),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: value.isEmpty ? Colors.transparent : (color ?? Colors.white.withOpacity(0.75)),
        border: Border.all(color: Colors.white38),
      ),
      child: Center(child: Text(value, style: TextStyle(color: value == '0' && color == null ? Colors.black : Colors.white, fontWeight: FontWeight.w900))),
    );
  }
}

class StatRow extends StatelessWidget {
  final Map<String, String> items;
  const StatRow({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: premiumDecoration(radius: 14),
      child: Row(
        children: items.entries.map((e) => Expanded(
          child: Column(
            children: [
              Text(e.key, textAlign: TextAlign.center, style: muted.copyWith(fontSize: 12)),
              const SizedBox(height: 8),
              Text(e.value, style: h3.copyWith(fontSize: 20)),
            ],
          ),
        )).toList(),
      ),
    );
  }
}

class MiniTable extends StatelessWidget {
  final String title;
  final List<String> columns;
  final List<List<String>> rows;
  final String? footerLeft;
  final String? footerRight;
  const MiniTable({super.key, required this.title, required this.columns, required this.rows, this.footerLeft, this.footerRight});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: premiumDecoration(radius: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Expanded(child: Text(title, style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w900))), ...columns.map((c) => SizedBox(width: 44, child: Text(c, textAlign: TextAlign.center, style: muted.copyWith(color: Colors.white70))))]),
          Divider(color: AppColors.border),
          ...rows.map((r) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [Expanded(child: Text(r.first, style: body.copyWith(fontWeight: FontWeight.w700))), ...r.skip(1).map((v) => SizedBox(width: 44, child: Text(v, textAlign: TextAlign.center, style: body)))]),
          )),
          if (footerLeft != null || footerRight != null) ...[
            Divider(color: AppColors.border),
            Row(children: [Expanded(child: Text(footerLeft ?? '', style: muted)), Text(footerRight ?? '', style: muted)]),
          ],
        ],
      ),
    );
  }
}

class ToolsCard extends StatelessWidget {
  const ToolsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: premiumDecoration(radius: 14),
      child: Column(
        children: const [
          ToolRow(icon: Icons.emoji_events_outlined, title: 'Series'),
          ToolRow(icon: Icons.bar_chart_rounded, title: 'Points Table'),
          ToolRow(icon: Icons.record_voice_over_outlined, title: 'Voice Commentary'),
        ],
      ),
    );
  }
}

class ToolRow extends StatelessWidget {
  final IconData icon;
  final String title;
  const ToolRow({super.key, required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: Colors.white70),
      title: Text(title, style: body.copyWith(fontWeight: FontWeight.w700)),
      trailing: const Icon(Icons.chevron_right, color: Colors.white70),
    );
  }
}

class ScorecardTab extends StatelessWidget {
  const ScorecardTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const FeaturedMatchCard(match: featuredMatch),
        const SizedBox(height: 14),
        MiniTable(title: 'BATTING • Freedom', columns: const ['R', 'B', '4s', '6s', 'SR'], rows: const [
          ['K. Nair c Miller b Gannon', '7', '5', '1', '0', '140.0'],
          ['M. John b Gannon', '12', '10', '2', '0', '120.0'],
          ['A. Aponso st Miller b Gannon', '31', '13', '2', '2', '238.47'],
          ['S. Netravalkar b Gannon', '7', '5', '1', '0', '140.0'],
        ], footerLeft: 'Extras: 11', footerRight: 'Total: 139-10 (16.2)'),
        const SizedBox(height: 14),
        MiniTable(title: 'BOWLING • Orcas', columns: const ['O', 'M', 'R', 'W', 'Eco'], rows: const [
          ['Cameron Gannon', '2.2', '0', '16', '2', '6.86'],
          ['Harmeet Singh', '4.0', '0', '28', '2', '7.00'],
          ['Imad Wasim', '3.0', '0', '22', '1', '7.33'],
        ]),
      ],
    );
  }
}

class HistoryTab extends StatelessWidget {
  const HistoryTab({super.key});

  @override
  Widget build(BuildContext context) {
    final rows = [
      ['1', '0 1 0 4 0 1', '11 runs', '11/0'],
      ['2', '0 0 W 1 0 2', 'K. Nair c Miller b Gannon', '14/1'],
      ['3', '4 0 1 W 0 0', 'M. John b Gannon', '20/2'],
      ['4', '1 1 0 6 0 1', '17 runs', '37/2'],
      ['5', '0 4 0 1 W 0', 'A. Aponso st Miller b Gannon', '42/3'],
      ['16', '1 0 W 0 0 0', 'S. Netravalkar b Gannon', '118/9'],
      ['17', '0 0 0 0 1 W', 'K. Ramharack b Gannon', '129/10'],
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: premiumDecoration(active: true, radius: 16),
          child: Row(children: [Text('227-6\n(20.0)', style: h2), const Spacer(), Text('Seattle Orcas won\nby 88 runs', textAlign: TextAlign.center, style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w900)), const Spacer(), Text('139-10\n(16.2)', textAlign: TextAlign.right, style: h2)]),
        ),
        const SizedBox(height: 16),
        Row(children: [Expanded(child: FilterChipPill(label: 'Freedom Innings\n139-10 (16.2)', active: true)), const SizedBox(width: 10), const Expanded(child: FilterChipPill(label: 'Orcas Innings\n227-6 (20.0)'))]),
        const SizedBox(height: 18),
        Text('Over by Over - Freedom Innings', style: h3.copyWith(fontSize: 20)),
        const SizedBox(height: 10),
        Container(
          decoration: premiumDecoration(radius: 14),
          child: Column(children: rows.map((r) => OverHistoryRow(no: r[0], balls: r[1], note: r[2], score: r[3])).toList()),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: premiumDecoration(radius: 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text('Fall of Wickets', style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w900))), Text('Partnerships', style: muted)]),
            Divider(color: AppColors.border),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: const [
                FallWicket(score: '1-14', name: 'K. Nair', over: '1.5 ov'),
                FallWicket(score: '2-20', name: 'M. John', over: '2.3 ov'),
                FallWicket(score: '3-42', name: 'A. Aponso', over: '4.6 ov'),
                FallWicket(score: '4-78', name: 'L. Chambers', over: '8.4 ov'),
                FallWicket(score: '10-129', name: 'K. Ramharack', over: '16.2 ov'),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 14),
        const StatRow(items: {'Runs': '139', 'Balls': '98', 'Extras': '11', 'SR': '141.84', 'Overs': '16.2'}),
      ],
    );
  }
}

class OverHistoryRow extends StatelessWidget {
  final String no;
  final String balls;
  final String note;
  final String score;
  const OverHistoryRow({super.key, required this.no, required this.balls, required this.note, required this.score});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.border.withOpacity(0.8)))),
      child: Row(children: [
        SizedBox(width: 24, child: Text(no, style: body.copyWith(fontWeight: FontWeight.w900))),
        ...balls.split(' ').map((b) => BallMini(value: b)),
        const SizedBox(width: 8),
        Expanded(child: Text(note, maxLines: 1, overflow: TextOverflow.ellipsis, style: muted.copyWith(color: Colors.white70))),
        Text(score, style: body.copyWith(fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class BallMini extends StatelessWidget {
  final String value;
  const BallMini({super.key, required this.value});

  @override
  Widget build(BuildContext context) {
    Color c = Colors.white24;
    if (value == '4') c = AppColors.cyan2;
    if (value == '6') c = AppColors.purple;
    if (value == 'W') c = AppColors.red;
    if (value == '1' || value == '2' || value == '3') c = const Color(0xFF216EAE);
    return Container(
      width: 26,
      height: 26,
      margin: const EdgeInsets.only(right: 6),
      decoration: BoxDecoration(shape: BoxShape.circle, color: c),
      child: Center(child: Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: Colors.white))),
    );
  }
}

class FallWicket extends StatelessWidget {
  final String score;
  final String name;
  final String over;
  const FallWicket({super.key, required this.score, required this.name, required this.over});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(score, style: h3.copyWith(color: AppColors.cyan)),
        Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: body.copyWith(fontSize: 13)),
        Text('($over)', style: muted.copyWith(fontSize: 12)),
      ]),
    );
  }
}

class InfoTab extends StatelessWidget {
  const InfoTab({super.key});
  @override
  Widget build(BuildContext context) => const SimpleTabMessage(title: 'Match Info', message: 'Venue, toss, squads, umpires and match notes will be shown here.');
}

class CommentaryTab extends StatelessWidget {
  const CommentaryTab({super.key});
  @override
  Widget build(BuildContext context) => const SimpleTabMessage(title: 'Commentary', message: 'Ball-by-ball text commentary will appear here after API or admin scoring integration.');
}

class PointsTableTab extends StatelessWidget {
  const PointsTableTab({super.key});
  @override
  Widget build(BuildContext context) => const SimpleTabMessage(title: 'Points Table', message: 'Series points table can be connected with backend or cricket API later.');
}

class SimpleTabMessage extends StatelessWidget {
  final String title;
  final String message;
  const SimpleTabMessage({super.key, required this.title, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: premiumDecoration(active: true, radius: 18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.sports_cricket, size: 48, color: AppColors.cyan), const SizedBox(height: 14), Text(title, style: h2), const SizedBox(height: 10), Text(message, textAlign: TextAlign.center, style: muted.copyWith(fontSize: 16))]),
        ),
      ),
    );
  }
}

class BatterStats {
  String name;
  int runs;
  int balls;
  int fours;
  int sixes;
  bool out;
  BatterStats(this.name, {this.runs = 0, this.balls = 0, this.fours = 0, this.sixes = 0, this.out = false});
  BatterStats clone() => BatterStats(name, runs: runs, balls: balls, fours: fours, sixes: sixes, out: out);
}

class BowlerStats {
  String name;
  int balls;
  int runs;
  int wickets;
  BowlerStats(this.name, {this.balls = 0, this.runs = 0, this.wickets = 0});
  BowlerStats clone() => BowlerStats(name, balls: balls, runs: runs, wickets: wickets);
}

class ScoreEvent {
  final String label;
  final int runs;
  final bool legal;
  final bool wicket;
  final String scoreText;
  const ScoreEvent(this.label, this.runs, this.legal, this.wicket, this.scoreText);
}

class ScoreSnapshot {
  final int score;
  final int wickets;
  final int legalBalls;
  final List<String> balls;
  final BatterStats striker;
  final BatterStats nonStriker;
  final BowlerStats bowler;
  final int nextBatterNo;
  ScoreSnapshot(this.score, this.wickets, this.legalBalls, this.balls, this.striker, this.nonStriker, this.bowler, this.nextBatterNo);
}

class ManualScoringScreen extends StatefulWidget {
  const ManualScoringScreen({super.key});

  @override
  State<ManualScoringScreen> createState() => _ManualScoringScreenState();
}

class _ManualScoringScreenState extends State<ManualScoringScreen> {
  int score = 0;
  int wickets = 0;
  int legalBalls = 0;
  int nextBatterNo = 3;
  BatterStats striker = BatterStats('Batter 1');
  BatterStats nonStriker = BatterStats('Batter 2');
  BowlerStats bowler = BowlerStats('Bowler 1');
  final List<String> balls = [];
  final List<ScoreSnapshot> undoStack = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Row(
              children: [
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28)),
                Expanded(child: Column(children: [Text('Manual Scoring', style: h3.copyWith(fontSize: 21)), Text('Allrounder99 Local Match', style: muted)])),
                IconButton(onPressed: _copySummary, icon: const Icon(Icons.share, color: AppColors.cyan)),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: premiumDecoration(active: true, radius: 18),
              child: Column(
                children: [
                  Text('ALLROUNDER99 LIVE SCORE', style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  Text('$score-$wickets', style: h1.copyWith(fontSize: 54)),
                  Text('${oversText(legalBalls)} Overs', style: h3.copyWith(color: Colors.white70)),
                  const SizedBox(height: 14),
                  const Divider(color: AppColors.border),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                    _scoreSmall('CRR', _crr()),
                    _scoreSmall('Legal Balls', '$legalBalls'),
                    _scoreSmall('Wickets', '$wickets'),
                  ]),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _currentOverCard(),
            const SizedBox(height: 14),
            MiniTable(title: 'BATTING', columns: const ['R', 'B', '4s', '6s', 'SR'], rows: [
              ['🏏 ${striker.name} *', '${striker.runs}', '${striker.balls}', '${striker.fours}', '${striker.sixes}', _sr(striker)],
              [nonStriker.name, '${nonStriker.runs}', '${nonStriker.balls}', '${nonStriker.fours}', '${nonStriker.sixes}', _sr(nonStriker)],
            ], footerLeft: 'Tap runs to score', footerRight: 'Undo available'),
            const SizedBox(height: 14),
            MiniTable(title: 'BOWLING', columns: const ['O', 'R', 'Wkt', 'Eco'], rows: [
              ['${bowler.name} 🔴', oversText(bowler.balls), '${bowler.runs}', '${bowler.wickets}', _eco()],
            ]),
            const SizedBox(height: 18),
            Text('Scoring Panel', style: h2),
            const SizedBox(height: 12),
            _buttonsGrid(),
          ],
        ),
      ),
    );
  }

  Widget _scoreSmall(String title, String value) {
    return Column(children: [Text(title, style: muted), const SizedBox(height: 6), Text(value, style: h3.copyWith(color: AppColors.cyan))]);
  }

  Widget _currentOverCard() {
    final last = balls.length > 9 ? balls.sublist(balls.length - 9) : balls;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: premiumDecoration(radius: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Current Over / Timeline', style: body.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: last.isEmpty ? [Text('No ball scored yet', style: muted)] : last.map((b) => BallMini(value: b)).toList()),
      ]),
    );
  }

  Widget _buttonsGrid() {
    final buttons = [
      ['0', '0'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['6', '6'],
      ['Wicket', 'W'], ['Wide', 'Wd'], ['No Ball', 'Nb'], ['Bye', 'B'], ['Leg Bye', 'LB'], ['Undo', 'Undo'],
      ['Change Bowler', 'Bowler'], ['Retire Batter', 'Retire'], ['End Innings', 'End'],
    ];
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: buttons.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 2.15, crossAxisSpacing: 10, mainAxisSpacing: 10),
      itemBuilder: (_, i) {
        final label = buttons[i][0];
        final key = buttons[i][1];
        final isDanger = key == 'W' || key == 'End';
        final isAction = ['Undo', 'Bowler', 'Retire'].contains(key);
        return InkWell(
          onTap: () => _handleButton(key),
          borderRadius: BorderRadius.circular(14),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: isDanger ? AppColors.red.withOpacity(0.14) : isAction ? Colors.white.withOpacity(0.05) : AppColors.cyan.withOpacity(0.12),
              border: Border.all(color: isDanger ? AppColors.red : isAction ? AppColors.border : AppColors.cyan.withOpacity(0.7)),
            ),
            child: Center(child: Text(label, textAlign: TextAlign.center, style: body.copyWith(fontWeight: FontWeight.w900, color: isDanger ? AppColors.red : Colors.white))),
          ),
        );
      },
    );
  }

  void _handleButton(String key) {
    switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '6':
        _apply(ScoreEvent(key, int.parse(key), true, false, key), battingRuns: int.parse(key));
        break;
      case 'W':
        _apply(const ScoreEvent('Wicket', 0, true, true, 'W'), battingRuns: 0);
        break;
      case 'Wd':
        _apply(const ScoreEvent('Wide', 1, false, false, 'Wd'), battingRuns: 0);
        break;
      case 'Nb':
        _apply(const ScoreEvent('No Ball', 1, false, false, 'Nb'), battingRuns: 0);
        break;
      case 'B':
        _apply(const ScoreEvent('Bye', 1, true, false, 'B'), battingRuns: 0, rotate: true);
        break;
      case 'LB':
        _apply(const ScoreEvent('Leg Bye', 1, true, false, 'LB'), battingRuns: 0, rotate: true);
        break;
      case 'Undo':
        _undo();
        break;
      case 'Bowler':
        _showMessage('Bowler changed for next over demo.');
        break;
      case 'Retire':
        _saveSnapshot();
        setState(() => striker = BatterStats('Batter ${nextBatterNo++}'));
        break;
      case 'End':
        _copySummary();
        break;
    }
  }

  void _apply(ScoreEvent event, {required int battingRuns, bool rotate = false}) {
    if (wickets >= 10) return;
    _saveSnapshot();
    setState(() {
      score += event.runs;
      bowler.runs += event.runs;
      balls.add(event.scoreText);
      if (event.legal) {
        legalBalls++;
        bowler.balls++;
        striker.balls++;
      }
      if (battingRuns > 0) {
        striker.runs += battingRuns;
        if (battingRuns == 4) striker.fours++;
        if (battingRuns == 6) striker.sixes++;
        if (battingRuns.isOdd) rotate = true;
      }
      if (event.wicket) {
        wickets++;
        bowler.wickets++;
        striker.out = true;
        if (wickets < 10) striker = BatterStats('Batter ${nextBatterNo++}');
      }
      if (event.legal && legalBalls % 6 == 0) rotate = !rotate;
      if (rotate) _swapStrike();
    });
  }

  void _swapStrike() {
    final temp = striker;
    striker = nonStriker;
    nonStriker = temp;
  }

  void _saveSnapshot() {
    undoStack.add(ScoreSnapshot(score, wickets, legalBalls, List<String>.from(balls), striker.clone(), nonStriker.clone(), bowler.clone(), nextBatterNo));
  }

  void _undo() {
    if (undoStack.isEmpty) return;
    final last = undoStack.removeLast();
    setState(() {
      score = last.score;
      wickets = last.wickets;
      legalBalls = last.legalBalls;
      balls
        ..clear()
        ..addAll(last.balls);
      striker = last.striker.clone();
      nonStriker = last.nonStriker.clone();
      bowler = last.bowler.clone();
      nextBatterNo = last.nextBatterNo;
    });
  }

  String _crr() {
    if (legalBalls == 0) return '0.00';
    return (score / (legalBalls / 6)).toStringAsFixed(2);
  }

  String _sr(BatterStats b) {
    if (b.balls == 0) return '0.00';
    return ((b.runs / b.balls) * 100).toStringAsFixed(2);
  }

  String _eco() {
    if (bowler.balls == 0) return '0.00';
    return (bowler.runs / (bowler.balls / 6)).toStringAsFixed(2);
  }

  void _copySummary() async {
    final summary = 'Allrounder99 Live Score\n\nTeam A $score-$wickets (${oversText(legalBalls)})\n\nStriker: ${striker.name} ${striker.runs}(${striker.balls})\nBowler: ${bowler.name} ${oversText(bowler.balls)}-${bowler.runs}-${bowler.wickets}\n\nPowered by Allrounder99';
    await Clipboard.setData(ClipboardData(text: summary));
    _showMessage('Score summary copied. Paste it on WhatsApp.');
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppColors.panel2));
  }
}

class ShortsScreen extends StatelessWidget {
  const ShortsScreen({super.key});
  @override
  Widget build(BuildContext context) => AppBackground(child: ListView(padding: const EdgeInsets.fromLTRB(16, 24, 16, 112), children: [const AppHeader(), Text('Shorts', style: h1), const SizedBox(height: 12), const SimpleInPageCard(title: 'Video shorts section', subtitle: 'Add cricket reels, highlights, thumbnails and play screen here.')]);
}

class MoreScreen extends StatelessWidget {
  final VoidCallback startManualScoring;
  const MoreScreen({super.key, required this.startManualScoring});
  @override
  Widget build(BuildContext context) => AppBackground(child: ListView(padding: const EdgeInsets.fromLTRB(16, 24, 16, 112), children: [
    const AppHeader(),
    Text('More', style: h1),
    const SizedBox(height: 14),
    PrimaryActionCard(title: 'Manual Scoring', subtitle: 'Start local cricket scoring panel', icon: Icons.sports_cricket, onTap: startManualScoring),
    const SizedBox(height: 14),
    const SimpleInPageCard(title: 'WhatsApp Link', subtitle: 'https://go.wa.link/allrounder99'),
    const SizedBox(height: 12),
    const SimpleInPageCard(title: 'Website Link', subtitle: 'https://Gamerush99.com'),
    const SizedBox(height: 12),
    const SimpleInPageCard(title: 'About Allrounder99', subtitle: 'Professional cricket scoring app with live score, fixtures, series, history and manual scoring.')
  ]));
}

class SimpleInPageCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SimpleInPageCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: premiumDecoration(radius: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: h3), const SizedBox(height: 8), SelectableText(subtitle, style: muted.copyWith(fontSize: 15))]),
    );
  }
}

class PremiumBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  const PremiumBottomNav({super.key, required this.currentIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final items = [
      [Icons.home_rounded, 'Home'],
      [Icons.slideshow_rounded, 'Shorts'],
      [Icons.calendar_month_rounded, 'Fixtures'],
      [Icons.emoji_events_rounded, 'Series'],
      [Icons.more_horiz_rounded, 'More'],
    ];
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(colors: [Color(0xFF07131D), Color(0xFF0B1721)]),
          border: Border.all(color: AppColors.border),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, -4))],
        ),
        child: Row(
          children: List.generate(items.length, (i) {
            final active = i == currentIndex;
            return Expanded(
              child: InkWell(
                onTap: () => onTap(i),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(items[i][0] as IconData, color: active ? AppColors.cyan : Colors.white70, size: 27),
                    const SizedBox(height: 4),
                    Text(items[i][1] as String, style: TextStyle(color: active ? AppColors.cyan : Colors.white70, fontWeight: active ? FontWeight.w900 : FontWeight.w600, fontSize: 12)),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
