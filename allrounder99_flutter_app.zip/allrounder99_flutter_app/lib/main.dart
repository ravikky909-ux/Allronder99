import 'package:flutter/material.dart';

void main() {
  runApp(const Allrounder99App());
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Allrounder99',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF061015),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF08C7FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const MainShell(),
    );
  }
}

class AppColor {
  static const bg = Color(0xFF061015);
  static const bg2 = Color(0xFF0A1B24);
  static const card = Color(0xFF17232C);
  static const line = Color(0xFF2F3C46);
  static const cyan = Color(0xFF08C7FF);
  static const muted = Color(0xFF9BA7B2);
  static const red = Color(0xFFE64040);
  static const green = Color(0xFF25C06D);
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = const [
      HomePage(),
      FixturesPage(),
      SeriesPage(),
      MorePage(),
    ];

    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        backgroundColor: AppColor.card,
        indicatorColor: AppColor.cyan.withOpacity(0.18),
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: AppColor.cyan), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month, color: AppColor.cyan), label: 'Fixtures'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events, color: AppColor.cyan), label: 'Series'),
          NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz, color: AppColor.cyan), label: 'More'),
        ],
      ),
    );
  }
}

class GradientPage extends StatelessWidget {
  final Widget child;
  const GradientPage({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF050B10), Color(0xFF071B24), Color(0xFF061015)],
        ),
      ),
      child: SafeArea(child: child),
    );
  }
}

class TopLogo extends StatelessWidget {
  const TopLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ClipOval(child: Image.asset('assets/logo.png', width: 54, height: 54, fit: BoxFit.cover)),
        const SizedBox(width: 10),
        const Text('ALLROUNDER99', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.onTap});

  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: AppColor.card.withOpacity(0.96),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColor.line),
        boxShadow: [BoxShadow(color: AppColor.cyan.withOpacity(0.06), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: child,
    );
    if (onTap == null) return box;
    return InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: box);
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const Row(children: [TopLogo(), Spacer(), Icon(Icons.search), SizedBox(width: 12), Icon(Icons.settings_outlined)]),
          const SizedBox(height: 18),
          const Row(children: [Pill('Featured', selected: true), SizedBox(width: 8), Pill('Live'), SizedBox(width: 8), Pill('WT20 WC')]),
          const SizedBox(height: 12),
          GlassCard(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailPage())),
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(13),
                  child: Row(children: const [
                    Pill('LIVE', selected: true, color: AppColor.red),
                    SizedBox(width: 8),
                    Expanded(child: Text('Andhra Premier League 2026, 25th Match', style: TextStyle(fontWeight: FontWeight.w800))),
                    Icon(Icons.chevron_right, color: AppColor.muted),
                  ]),
                ),
                const Divider(height: 1, color: AppColor.line),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: const [
                    TeamBadge(code: 'CAMR', color: Color(0xFFC51238)),
                    SizedBox(width: 10),
                    Expanded(child: Text('CAMR\nBowling', style: TextStyle(fontWeight: FontWeight.w800, height: 1.4))),
                    Icon(Icons.flash_on, size: 30),
                    Expanded(child: Text('46-1\n5.1 Over\nVJS', textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, height: 1.4))),
                    SizedBox(width: 10),
                    TeamBadge(code: 'VJS', color: Color(0xFF1E9C65)),
                  ]),
                ),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: const BoxDecoration(color: Color(0xFF0E1820), borderRadius: BorderRadius.vertical(bottom: Radius.circular(18))),
                  child: const Center(child: Text('VJS 46-1 (5.1) • Live now • 1 Run', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900))),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const SectionTitle('Quick Options'),
          const OptionGrid(),
        ],
      ),
    );
  }
}

class TeamBadge extends StatelessWidget {
  final String code;
  final Color color;
  const TeamBadge({super.key, required this.code, required this.color});

  @override
  Widget build(BuildContext context) {
    final darkText = color.computeLuminance() > 0.55;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [color, color.withOpacity(0.65)]),
            border: Border.all(color: Colors.white24),
          ),
          child: Center(
            child: Text(
              code,
              style: TextStyle(
                color: darkText ? Colors.black : Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: code.length > 3 ? 11 : 15,
              ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(code, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
      ],
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final bool selected;
  final Color color;
  const Pill(this.text, {super.key, this.selected = false, this.color = AppColor.cyan});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: selected ? color.withOpacity(0.20) : AppColor.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: selected ? color : AppColor.line),
      ),
      child: Text(text, style: TextStyle(color: selected ? color : AppColor.muted, fontWeight: FontWeight.w900)),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 10),
      child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
    );
  }
}

class OptionGrid extends StatelessWidget {
  const OptionGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Live Matches', Icons.flash_on),
      ('Commentary', Icons.comment_outlined),
      ('Scorecards', Icons.table_chart_outlined),
      ('Points Table', Icons.leaderboard_outlined),
      ('Fixtures', Icons.calendar_month_outlined),
      ('Series', Icons.emoji_events_outlined),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 2.3),
      itemBuilder: (context, i) => GlassCard(
        padding: const EdgeInsets.all(10),
        child: Row(children: [
          Icon(items[i].$2, color: AppColor.cyan),
          const SizedBox(width: 8),
          Expanded(child: Text(items[i].$1, style: const TextStyle(fontWeight: FontWeight.w900))),
        ]),
      ),
    );
  }
}

class FixturesPage extends StatelessWidget {
  const FixturesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: const [
          Text('Fixtures', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 12),
          FixtureCard(title: 'Andhra Premier League 2026', teams: 'CAMR vs VJS', status: 'Live now - VJS 46-1 after 5.1 overs'),
          FixtureCard(title: 'Women T20 World Cup 2026', teams: 'India vs Ireland', status: 'Upcoming'),
          FixtureCard(title: 'England Test Series', teams: 'ENG vs NZ', status: '3rd Test Match'),
        ],
      ),
    );
  }
}

class FixtureCard extends StatelessWidget {
  final String title;
  final String teams;
  final String status;
  const FixtureCard({super.key, required this.title, required this.teams, required this.status});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        child: Row(children: [
          const Icon(Icons.sports_cricket, color: AppColor.cyan),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(teams, style: const TextStyle(color: AppColor.muted)),
            const SizedBox(height: 6),
            Text(status, style: const TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w800)),
          ])),
        ]),
      ),
    );
  }
}

class SeriesPage extends StatelessWidget {
  const SeriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: const [
          Text('Series', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 12),
          FixtureCard(title: 'Women T20 World Cup 2026', teams: 'International', status: '12 Jun - 05 Jul 2026'),
          FixtureCard(title: 'Andhra Premier League 2026', teams: 'Domestic T20', status: 'Live matches available'),
          FixtureCard(title: 'England vs New Zealand 2026', teams: 'Test Series', status: '3rd Test Match'),
        ],
      ),
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const Text('More', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          GlassCard(
            child: Row(children: [
              ClipOval(child: Image.asset('assets/logo.png', width: 70, height: 70, fit: BoxFit.cover)),
              const SizedBox(width: 14),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Welcome to Allrounder99', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                SizedBox(height: 6),
                Text('Scoring app for live cricket scores, scorecards and match history.', style: TextStyle(color: AppColor.muted, height: 1.35, fontWeight: FontWeight.w700)),
              ])),
            ]),
          ),
          const SizedBox(height: 14),
          const MoreTile(icon: Icons.flash_on, title: 'Live Matches'),
          const MoreTile(icon: Icons.calendar_month_outlined, title: 'Fixtures & Schedule'),
          const MoreTile(icon: Icons.emoji_events_outlined, title: 'Series & Leagues'),
          const MoreTile(icon: Icons.comment_outlined, title: 'Commentary'),
          const MoreTile(icon: Icons.table_chart_outlined, title: 'Scorecards'),
          const MoreTile(icon: Icons.leaderboard_outlined, title: 'Points Table'),
          const MoreTile(icon: Icons.notifications_active_outlined, title: 'Live Score Alerts', trailing: 'On'),
          const MoreTile(icon: Icons.settings_outlined, title: 'Settings'),
          const MoreTile(icon: Icons.language, title: 'Language', trailing: 'English'),
          const MoreTile(icon: Icons.share_outlined, title: 'Share App'),
          const MoreTile(icon: Icons.star_border, title: 'Rate Us'),
          const MoreTile(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy'),
          const MoreTile(icon: Icons.description_outlined, title: 'Terms & Conditions'),
          const MoreTile(icon: Icons.info_outline, title: 'About Allrounder99', trailing: 'v1.0.0'),
        ],
      ),
    );
  }
}

class MoreTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  const MoreTile({super.key, required this.icon, required this.title, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Row(children: [
          Icon(icon, color: AppColor.cyan),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
          if (trailing != null) Text(trailing!, style: const TextStyle(color: AppColor.muted)),
          const Icon(Icons.chevron_right, color: AppColor.muted),
        ]),
      ),
    );
  }
}

class MatchDetailPage extends StatefulWidget {
  const MatchDetailPage({super.key});

  @override
  State<MatchDetailPage> createState() => _MatchDetailPageState();
}

class _MatchDetailPageState extends State<MatchDetailPage> {
  int tab = 1;
  late final PageController controller;
  final tabs = const ['Info', 'Live', 'Commentary', 'Scorecard', 'History'];

  @override
  void initState() {
    super.initState();
    controller = PageController(initialPage: tab);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void openTab(int i) {
    setState(() => tab = i);
    controller.animateToPage(i, duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: Column(
          children: [
            Row(children: const [
              BackButton(),
              Expanded(child: Text('CAMR vs VJS\n25th Match • Live', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
              Icon(Icons.star_border),
              SizedBox(width: 12),
              Icon(Icons.more_vert),
            ]),
            SizedBox(
              height: 48,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: tabs.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (context, i) => GestureDetector(
                  onTap: () => openTab(i),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 11),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tab == i ? AppColor.cyan : Colors.transparent, width: 3))),
                    child: Text(tabs[i], style: TextStyle(color: tab == i ? Colors.white : AppColor.muted, fontWeight: FontWeight.w900)),
                  ),
                ),
              ),
            ),
            Expanded(
              child: PageView(
                controller: controller,
                onPageChanged: (i) => setState(() => tab = i),
                children: const [
                  InfoView(),
                  LiveView(),
                  CommentaryView(),
                  ScorecardView(),
                  HistoryView(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class InfoView extends StatelessWidget {
  const InfoView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Match Info\nCAMR vs VJS', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)));
  }
}

class LiveView extends StatelessWidget {
  const LiveView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: const [
        GlassCard(child: Center(child: Text('1 Run', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900)))),
        SizedBox(height: 12),
        GlassCard(child: Text('VJS 46-1 (5.1)  •  CAMR bowling', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
        SizedBox(height: 12),
        GlassCard(child: Text('Run Rate: 8.9\nBalls Remaining: 89', style: TextStyle(fontSize: 18, height: 1.6, fontWeight: FontWeight.w800))),
      ],
    );
  }
}

class CommentaryView extends StatelessWidget {
  const CommentaryView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: const [
        CommentaryRow(over: '5.1', run: '1', text: 'Bowler to batter: 1 Run. Good running between the wickets.'),
        CommentaryRow(over: '4.6', run: '4', text: 'Boundary! Excellent shot through cover.'),
        CommentaryRow(over: '4.5', run: '0', text: 'No run. Dot ball.'),
        CommentaryRow(over: '4.4', run: '6', text: 'Six! Clean hit over long-on.'),
        CommentaryRow(over: '4.3', run: '1', text: 'Single taken.'),
      ],
    );
  }
}

class CommentaryRow extends StatelessWidget {
  final String over;
  final String run;
  final String text;
  const CommentaryRow({super.key, required this.over, required this.run, required this.text});

  @override
  Widget build(BuildContext context) {
    final isDot = run == '0';
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 48, child: Column(children: [
          Text(over, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          CircleAvatar(backgroundColor: isDot ? Colors.white : AppColor.green, child: Text(run, style: TextStyle(color: isDot ? Colors.black : Colors.white, fontWeight: FontWeight.w900))),
        ])),
        const SizedBox(width: 12),
        Expanded(child: Text(text, style: const TextStyle(height: 1.35, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}

class ScorecardView extends StatelessWidget {
  const ScorecardView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: const [
        GlassCard(child: Text('VJS 46/1 (5.1)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
        SizedBox(height: 12),
        ScoreRow(name: 'Ashwin Hebbar', r: '16', b: '9', sr: '177.78'),
        ScoreRow(name: 'Harshavardhan Maddila', r: '23', b: '15', sr: '153.34'),
        Divider(color: AppColor.line),
        ScoreRow(name: 'M Toshith Yadav', r: '20', b: '2.1', sr: 'Eco 9.24'),
      ],
    );
  }
}

class ScoreRow extends StatelessWidget {
  final String name;
  final String r;
  final String b;
  final String sr;
  const ScoreRow({super.key, required this.name, required this.r, required this.b, required this.sr});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Row(children: [
        Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w900))),
        Text('R $r   B $b   $sr', style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)),
      ]),
    );
  }
}

class HistoryView extends StatelessWidget {
  const HistoryView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: const [
        Row(children: [Expanded(child: Pill('1st Innings')), SizedBox(width: 10), Expanded(child: Pill('2nd Innings', selected: true))]),
        SizedBox(height: 12),
        HistoryCard(),
      ],
    );
  }
}

class HistoryCard extends StatelessWidget {
  const HistoryCard({super.key});

  @override
  Widget build(BuildContext context) {
    final balls = const [('0.6', '4', '16-0'), ('0.5', '6', '12-0'), ('0.4', '1', '6-0'), ('0.3', '4', '5-0'), ('0.2', '0', '1-0'), ('0.1', '1', '1-0')];
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('1st Over : 16 runs', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const Divider(color: AppColor.line),
          for (final b in balls)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(children: [
                CircleAvatar(backgroundColor: b.$2 == '0' ? Colors.white : AppColor.green, child: Text(b.$2, style: TextStyle(color: b.$2 == '0' ? Colors.black : Colors.white, fontWeight: FontWeight.w900))),
                const SizedBox(width: 12),
                Expanded(child: Text('${b.$3}   ${b.$1}', style: const TextStyle(fontWeight: FontWeight.w900))),
                const Text('VJS', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900)),
              ]),
            ),
        ],
      ),
    );
  }
}
