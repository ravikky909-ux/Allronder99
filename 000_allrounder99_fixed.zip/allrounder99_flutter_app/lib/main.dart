import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const Allrounder99App());
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Allrounder99',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: C.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: C.cyan, brightness: Brightness.dark),
      ),
      home: const SplashPage(),
    );
  }
}

class C {
  static const bg = Color(0xFF05070B);
  static const card = Color(0xFF0B1520);
  static const card2 = Color(0xFF101D2A);
  static const border = Color(0xFF203545);
  static const cyan = Color(0xFF00D9FF);
  static const cyan2 = Color(0xFF009FD0);
  static const green = Color(0xFF32C66B);
  static const orange = Color(0xFFCE862E);
  static const red = Color(0xFFE84E57);
  static const purple = Color(0xFF7A56D9);
  static const muted = Color(0xFFA7B0BA);
}

TextStyle titleStyle(double size) => TextStyle(fontSize: size, fontWeight: FontWeight.w900, color: Colors.white, height: 1.15);
TextStyle normalStyle({Color color = Colors.white, double size = 15, FontWeight weight = FontWeight.w600}) => TextStyle(fontSize: size, fontWeight: weight, color: color, height: 1.25);

BoxDecoration cardDec({bool active = false, double radius = 18}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: active
          ? [C.cyan.withOpacity(.24), C.card, C.bg]
          : [C.card2.withOpacity(.96), C.card.withOpacity(.98)],
    ),
    border: Border.all(color: active ? C.cyan : C.border, width: active ? 1.4 : 1),
    boxShadow: [BoxShadow(color: Colors.black.withOpacity(.35), blurRadius: 18, offset: const Offset(0, 8))],
  );
}

String overText(int balls) => '${balls ~/ 6}.${balls % 6}';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  late final AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 4500))..forward();
    Timer(const Duration(milliseconds: 4500), () {
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const RootPage()));
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(center: Alignment.center, radius: 1.1, colors: [Color(0xFF064653), C.bg]),
        ),
        child: Center(
          child: AnimatedBuilder(
            animation: controller,
            builder: (context, child) {
              final value = Curves.easeOutCubic.transform(controller.value);
              return Opacity(
                opacity: value.clamp(0.0, 1.0),
                child: Transform.scale(
                  scale: 0.82 + (value * .18),
                  child: Container(
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: C.cyan.withOpacity(.35), blurRadius: 70, spreadRadius: 8)]),
                    child: Image.asset('assets/logo.png', width: 230, fit: BoxFit.contain),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class RootPage extends StatefulWidget {
  const RootPage({super.key});

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const HomePage(),
      const FixturesPage(),
      const SeriesPage(),
      const ScoringPage(),
      const MorePage(),
    ];
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: pages[index]),
          Align(alignment: Alignment.bottomCenter, child: BottomNav(index: index, onTap: (i) => setState(() => index = i))),
        ],
      ),
    );
  }
}

class AppBg extends StatelessWidget {
  final Widget child;
  const AppBg({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: RadialGradient(center: Alignment.topRight, radius: 1.1, colors: [Color(0xFF062B38), C.bg])),
      child: SafeArea(child: child),
    );
  }
}

class Header extends StatelessWidget {
  const Header({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          Image.asset('assets/logo.png', width: 174, height: 58, fit: BoxFit.contain),
          const Spacer(),
          IconBox(icon: Icons.search, onTap: () {}),
          const SizedBox(width: 10),
          IconBox(icon: Icons.settings_outlined, onTap: () {}),
        ],
      ),
    );
  }
}

class IconBox extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const IconBox({super.key, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 50,
        height: 50,
        decoration: cardDec(radius: 16),
        child: Icon(icon, color: Colors.white, size: 27),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBg(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 118),
        children: [
          const Header(),
          const TopTabs(labels: ['Featured', 'Live', 'WT20 WC'], active: 0),
          Padding(
            padding: const EdgeInsets.all(16),
            child: MatchCard(
              status: 'FINISHED',
              series: 'Major League Cricket 2026 • 9th Match',
              leftTeam: 'Orcas',
              leftScore: '227-6',
              leftOvers: '(20.0)',
              rightTeam: 'Freedom',
              rightScore: '139-10',
              rightOvers: '(16.2)',
              result: 'Seattle Orcas won by 88 runs',
              active: true,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchPage())),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 10, runSpacing: 10, children: [
              Pill('All', active: true, icon: Icons.grid_view),
              Pill('T20', icon: Icons.sports_cricket),
              Pill('ODI', icon: Icons.circle),
              Pill('Test', icon: Icons.shield),
              Pill('Leagues', icon: Icons.emoji_events),
            ]),
          ),
          const SizedBox(height: 22),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ActionCard(
              title: 'Start Manual Scoring',
              subtitle: 'Score local cricket match ball by ball',
              icon: Icons.sports_cricket,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ScoringPage(fullScreen: true))),
            ),
          ),
          const SizedBox(height: 22),
          const SectionTitle('Trending Series'),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: SeriesCard(title: 'Women T20 World Cup 2026', dates: '12 Jun - 05 Jul 2026', matches: '33 Matches', status: 'Ongoing', initials: 'T20'),
          ),
          const SizedBox(height: 22),
          const SectionTitle('Popular Shorts'),
          SizedBox(
            height: 170,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              children: const [
                ShortTile(title: 'First hurdle on fire', color: Color(0xFF1378A8)),
                ShortTile(title: '12 record wickets', color: Color(0xFFBA7227)),
                ShortTile(title: 'Top cricket moments', color: Color(0xFF1648B7)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TopTabs extends StatelessWidget {
  final List<String> labels;
  final int active;
  const TopTabs({super.key, required this.labels, required this.active});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          Row(
            children: List.generate(labels.length, (i) {
              final on = i == active;
              return Expanded(
                child: Column(
                  children: [
                    Text(labels[i], style: normalStyle(color: on ? C.cyan : Colors.white60, size: 17, weight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    AnimatedContainer(duration: const Duration(milliseconds: 200), height: 3, width: on ? 110 : 0, decoration: BoxDecoration(color: C.cyan, borderRadius: BorderRadius.circular(4))),
                  ],
                ),
              );
            }),
          ),
          Container(height: 1, color: C.border),
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final IconData? icon;
  final bool active;
  const Pill(this.text, {super.key, this.icon, this.active = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
      decoration: cardDec(active: active, radius: 14),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 18, color: Colors.white), const SizedBox(width: 7)],
        Text(text, style: normalStyle(weight: FontWeight.w800, color: active ? Colors.white : Colors.white70)),
      ]),
    );
  }
}

class MatchCard extends StatelessWidget {
  final String status;
  final String series;
  final String leftTeam;
  final String leftScore;
  final String leftOvers;
  final String rightTeam;
  final String rightScore;
  final String rightOvers;
  final String result;
  final bool active;
  final VoidCallback? onTap;
  const MatchCard({super.key, required this.status, required this.series, required this.leftTeam, required this.leftScore, required this.leftOvers, required this.rightTeam, required this.rightScore, required this.rightOvers, required this.result, this.active = false, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: cardDec(active: active, radius: 18),
        child: Column(children: [
          Status(status),
          const SizedBox(height: 10),
          Text(series, textAlign: TextAlign.center, style: normalStyle(color: C.muted, size: 14)),
          const SizedBox(height: 18),
          Row(children: [
            TeamBlock(name: leftTeam, score: leftScore, overs: leftOvers, color: C.red),
            Container(width: 54, height: 54, decoration: BoxDecoration(shape: BoxShape.circle, color: C.cyan.withOpacity(.12)), child: const Icon(Icons.bolt, color: C.cyan, size: 36)),
            TeamBlock(name: rightTeam, score: rightScore, overs: rightOvers, color: Color(0xFFFF8C9D), right: true),
          ]),
          const SizedBox(height: 18),
          Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: Colors.black.withOpacity(.22), border: Border.all(color: C.cyan.withOpacity(.45))), child: Text(result, textAlign: TextAlign.center, style: normalStyle(color: C.cyan, weight: FontWeight.w900))),
        ]),
      ),
    );
  }
}

class TeamBlock extends StatelessWidget {
  final String name;
  final String score;
  final String overs;
  final Color color;
  final bool right;
  const TeamBlock({super.key, required this.name, required this.score, required this.overs, required this.color, this.right = false});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(crossAxisAlignment: right ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
        CircleAvatar(radius: 31, backgroundColor: color, child: Text(name.substring(0, 1), style: titleStyle(28))),
        const SizedBox(height: 9),
        Text(score, style: titleStyle(30)),
        Text(overs, style: normalStyle(color: Colors.white70, size: 14)),
        const SizedBox(height: 8),
        Text(name, style: normalStyle(size: 18, weight: FontWeight.w900)),
      ]),
    );
  }
}

class Status extends StatelessWidget {
  final String text;
  const Status(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    Color color = C.cyan;
    final low = text.toLowerCase();
    if (low.contains('finish')) color = C.green;
    if (low.contains('upcoming')) color = C.orange;
    if (low.contains('live')) color = C.red;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: color.withOpacity(.16), border: Border.all(color: color), borderRadius: BorderRadius.circular(10)), child: Text(text, style: normalStyle(color: color, size: 13, weight: FontWeight.w900)));
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(children: [Text(title, style: titleStyle(22)), const Spacer(), Text('View all', style: normalStyle(color: C.cyan, weight: FontWeight.w800)), const SizedBox(width: 6), const Icon(Icons.chevron_right, color: C.cyan)]),
    );
  }
}

class ActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  const ActionCard({super.key, required this.title, required this.subtitle, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: cardDec(active: true, radius: 18),
        child: Row(children: [CircleAvatar(radius: 25, backgroundColor: C.cyan.withOpacity(.16), child: Icon(icon, color: C.cyan)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: normalStyle(size: 18, weight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: normalStyle(color: C.muted, size: 14))])), const Icon(Icons.chevron_right, color: C.cyan)]),
      ),
    );
  }
}

class FixturesPage extends StatelessWidget {
  const FixturesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final games = [
      ['Major League Cricket 2026', '9th Match • 07:00 AM', 'Freedom', '139-10', 'Orcas', '227-6', 'Finished', 'Seattle Orcas won by 88 runs'],
      ['Andhra Premier League 2026', '25th Match • 02:00 PM', 'Capital Royals', '', 'Sunshiners', '', 'Upcoming', 'Venue - Amaravathi, India'],
      ['Women T20 Blast 2026', '28th Match • 03:30 PM', 'Warwickshire', '', 'Surrey Women', '', 'Upcoming', 'Venue - Birmingham, England'],
      ['The Hundred Women 2026', '15th Match • 07:00 PM', 'Southern Brave', '', 'London Spirit', '', 'Upcoming', 'Venue - Southampton, England'],
    ];
    return AppBg(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 118),
        children: [
          const Header(),
          const TopTabs(labels: ['Day wise', 'Series wise', 'Team wise'], active: 0),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10), child: Wrap(spacing: 10, children: [Pill('All', active: true), Pill('T20'), Pill('ODI'), Pill('Test')]),
          Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 12), child: Row(children: [const Icon(Icons.calendar_today, color: Colors.white70), const SizedBox(width: 10), Text('Fri, 26 Jun 2026', style: titleStyle(22))])),
          for (final g in games) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 14), child: FixtureTile(data: g)),
        ],
      ),
    );
  }
}

class FixtureTile extends StatelessWidget {
  final List<String> data;
  const FixtureTile({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final finished = data[6] == 'Finished';
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: cardDec(radius: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(data[0], style: normalStyle(size: 18, weight: FontWeight.w900)), Text(data[1], style: normalStyle(color: C.muted, size: 14))])), Status(data[6])]),
        const SizedBox(height: 18),
        Row(children: [CircleAvatar(backgroundColor: C.red, child: Text(data[2].substring(0, 1))), const SizedBox(width: 10), Expanded(child: Text(data[2], style: normalStyle(size: 17, weight: FontWeight.w900))), if (finished) Text(data[3], style: normalStyle(size: 17, weight: FontWeight.w900)), const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Icon(Icons.bolt, color: C.cyan)), if (finished) Text(data[5], style: normalStyle(size: 17, weight: FontWeight.w900)), Expanded(child: Text(data[4], textAlign: TextAlign.right, style: normalStyle(size: 17, weight: FontWeight.w900))), const SizedBox(width: 10), CircleAvatar(backgroundColor: C.cyan2, child: Text(data[4].substring(0, 1)))]),
        Divider(color: C.border),
        Center(child: Text(data[7], style: normalStyle(color: finished ? C.cyan : Colors.white70, weight: FontWeight.w800))),
      ]),
    );
  }
}

class SeriesPage extends StatelessWidget {
  const SeriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final list = const [
      ['Vidarbha Premier League 2026', '01 Jun - 14 Jun', '25 Matches', 'Finished', 'VPL'],
      ['T20 Mumbai 2026', '01 Jun - 13 Jun', '23 Matches', 'Finished', 'T20'],
      ['Asian Legends League 2026', '02 Jun - 14 Jun', '19 Matches', 'Postponed', 'ALL'],
      ['Ireland Inter-Provincial T20 Trophy 2026', '02 Jun - 17 Jun', '9 Matches', 'Finished', 'IRE'],
      ['Madhya Pradesh T20 League 2026', '03 Jun - 26 Jun', '48 Matches', 'Ongoing', 'MPT'],
    ];
    return AppBg(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 118),
        children: [
          const Header(),
          const TopTabs(labels: ['Day wise', 'Series wise', 'Team wise'], active: 1),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10), child: Wrap(spacing: 10, runSpacing: 10, children: [Pill('All', active: true), Pill('International'), Pill('T20 Leagues'), Pill('Domestic')]),
          Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 20), child: Container(padding: const EdgeInsets.all(16), decoration: cardDec(radius: 14), child: Row(children: [const Icon(Icons.search, color: Colors.white54), const SizedBox(width: 12), Text('Search Series', style: normalStyle(color: C.muted, size: 17))]))),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text('June 2026', style: titleStyle(22))),
          const SizedBox(height: 12),
          for (final s in list) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 12), child: SeriesCard(title: s[0], dates: s[1], matches: s[2], status: s[3], initials: s[4])),
        ],
      ),
    );
  }
}

class SeriesCard extends StatelessWidget {
  final String title;
  final String dates;
  final String matches;
  final String status;
  final String initials;
  const SeriesCard({super.key, required this.title, required this.dates, required this.matches, required this.status, required this.initials});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: cardDec(radius: 16),
      child: Row(children: [
        Container(width: 72, height: 72, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(colors: [C.cyan2, Color(0xFF1648B7)])), alignment: Alignment.center, child: Text(initials, style: titleStyle(20))),
        const SizedBox(width: 15),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: normalStyle(size: 18, weight: FontWeight.w900)), const SizedBox(height: 8), Text(dates, style: normalStyle(color: C.muted)), const SizedBox(height: 4), Text(matches, style: normalStyle(color: C.muted))])),
        Status(status),
      ]),
    );
  }
}

class MatchPage extends StatelessWidget {
  const MatchPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        body: AppBg(
          child: Column(children: [
            Row(children: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)), Expanded(child: Column(children: [Text('Freedom vs Orcas', style: titleStyle(20)), Text('9th Match', style: normalStyle(color: C.muted))])), IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert))]),
            const TabBar(isScrollable: true, indicatorColor: C.cyan, labelColor: C.cyan, unselectedLabelColor: Colors.white60, tabs: [Tab(text: 'Live'), Tab(text: 'Scorecard'), Tab(text: 'History'), Tab(text: 'Info')]),
            Expanded(child: TabBarView(children: [const LiveView(), const ScorecardView(), const HistoryView(), Center(child: Text('Venue, toss, squads and notes.', style: normalStyle(color: C.muted)))])),
          ]),
        ),
      ),
    );
  }
}

class LiveView extends StatelessWidget {
  const LiveView({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const MatchCard(status: 'FINISHED', series: 'Major League Cricket 2026 • 9th Match', leftTeam: 'Orcas', leftScore: '227-6', leftOvers: '(20.0)', rightTeam: 'Freedom', rightScore: '139-10', rightOvers: '(16.2)', result: 'Seattle Orcas won by 88 runs', active: true),
      const SizedBox(height: 14),
      const BallStrip(),
      const SizedBox(height: 14),
      const StatGrid(items: {'Runs Needed': '89', 'Balls Rem.': '22', 'CRR': '8.51', 'RRR': '24.27', 'Target': '228'}),
      const SizedBox(height: 14),
      const InfoTable(title: 'BATTING - Freedom', rows: [['Amila Aponso', '31', '13', '2', '2', '238.47'], ['S. Netravalkar', '0', '0', '0', '0', '0.00']]),
      const SizedBox(height: 14),
      const InfoTable(title: 'BOWLING - Orcas', rows: [['Cameron Gannon', '2.2', '16', '2', '6.86']]),
    ]);
  }
}

class BallStrip extends StatelessWidget {
  const BallStrip({super.key});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: cardDec(radius: 14), child: const Row(children: [Ball('0'), Ball('4', color: C.cyan2), Text('  = 6   Over 17  ', style: TextStyle(fontWeight: FontWeight.bold)), Ball('6', color: C.purple), Ball('W', color: C.red), Ball(''), Ball('')]));
}

class Ball extends StatelessWidget {
  final String text;
  final Color? color;
  const Ball(this.text, {super.key, this.color});
  @override
  Widget build(BuildContext context) => Container(width: 34, height: 34, margin: const EdgeInsets.only(right: 7), decoration: BoxDecoration(shape: BoxShape.circle, color: text.isEmpty ? Colors.transparent : (color ?? Colors.white70), border: Border.all(color: Colors.white38)), alignment: Alignment.center, child: Text(text, style: TextStyle(color: text == '0' && color == null ? Colors.black : Colors.white, fontWeight: FontWeight.w900)));
}

class StatGrid extends StatelessWidget {
  final Map<String, String> items;
  const StatGrid({super.key, required this.items});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(vertical: 14), decoration: cardDec(radius: 14), child: Row(children: items.entries.map((e) => Expanded(child: Column(children: [Text(e.key, textAlign: TextAlign.center, style: normalStyle(color: C.muted, size: 12)), const SizedBox(height: 8), Text(e.value, style: titleStyle(19))]))).toList()));
}

class InfoTable extends StatelessWidget {
  final String title;
  final List<List<String>> rows;
  const InfoTable({super.key, required this.title, required this.rows});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: cardDec(radius: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: normalStyle(color: C.cyan, weight: FontWeight.w900)), Divider(color: C.border), for (final r in rows) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Expanded(child: Text(r[0], style: normalStyle(weight: FontWeight.w800))), for (final v in r.skip(1)) SizedBox(width: 44, child: Text(v, textAlign: TextAlign.center, style: normalStyle()))]))]));
}

class ScorecardView extends StatelessWidget {
  const ScorecardView({super.key});
  @override
  Widget build(BuildContext context) => const ListView(padding: EdgeInsets.all(16), children: [InfoTable(title: 'BATTING - Freedom', rows: [['K. Nair', '7', '5', '1', '0', '140'], ['A. Aponso', '31', '13', '2', '2', '238']]), SizedBox(height: 14), InfoTable(title: 'BOWLING - Orcas', rows: [['C. Gannon', '2.2', '16', '2', '6.86'], ['H. Singh', '4.0', '28', '2', '7.00']])]);
}

class HistoryView extends StatelessWidget {
  const HistoryView({super.key});
  @override
  Widget build(BuildContext context) {
    final overs = const [['1', '0 1 0 4 0 1', '11/0'], ['2', '0 0 W 1 0 2', '14/1'], ['3', '4 0 1 W 0 0', '20/2'], ['4', '1 1 0 6 0 1', '37/2'], ['17', '0 0 0 0 1 W', '129/10']];
    return ListView(padding: const EdgeInsets.all(16), children: [Container(padding: const EdgeInsets.all(16), decoration: cardDec(active: true), child: Text('Seattle Orcas won by 88 runs', textAlign: TextAlign.center, style: titleStyle(20))), const SizedBox(height: 14), for (final o in overs) Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12), decoration: cardDec(radius: 12), child: Row(children: [SizedBox(width: 32, child: Text(o[0], style: titleStyle(18))), Expanded(child: Text(o[1], style: normalStyle())), Text(o[2], style: normalStyle(color: C.cyan, weight: FontWeight.w900))]))]);
  }
}

class ScoringPage extends StatefulWidget {
  final bool fullScreen;
  const ScoringPage({super.key, this.fullScreen = false});
  @override
  State<ScoringPage> createState() => _ScoringPageState();
}

class _ScoringPageState extends State<ScoringPage> {
  int runs = 0;
  int wickets = 0;
  int balls = 0;
  final List<String> timeline = [];
  final List<List<dynamic>> undo = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBg(
        child: ListView(padding: EdgeInsets.fromLTRB(16, widget.fullScreen ? 8 : 20, 16, widget.fullScreen ? 24 : 118), children: [
          if (widget.fullScreen) Row(children: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)), Expanded(child: Text('Manual Scoring', textAlign: TextAlign.center, style: titleStyle(21))), IconButton(onPressed: share, icon: const Icon(Icons.share, color: C.cyan))]) else const Header(),
          Container(padding: const EdgeInsets.all(18), decoration: cardDec(active: true), child: Column(children: [Text('ALLROUNDER99 LIVE SCORE', style: normalStyle(color: C.cyan, weight: FontWeight.w900)), const SizedBox(height: 12), Text('$runs-$wickets', style: titleStyle(54)), Text('${overText(balls)} Overs', style: titleStyle(20).copyWith(color: Colors.white70)), Divider(color: C.border), Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [SmallStat('CRR', crr()), SmallStat('Balls', '$balls'), SmallStat('Wkts', '$wickets')])])),
          const SizedBox(height: 14),
          Container(padding: const EdgeInsets.all(14), decoration: cardDec(radius: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Current Over / Timeline', style: normalStyle(color: C.cyan, weight: FontWeight.w900)), const SizedBox(height: 10), Wrap(spacing: 8, runSpacing: 8, children: timeline.isEmpty ? [Text('No ball scored yet', style: normalStyle(color: C.muted))] : timeline.map((e) => Ball(e, color: ballColor(e))).toList())])),
          const SizedBox(height: 18),
          Text('Scoring Panel', style: titleStyle(22)),
          const SizedBox(height: 12),
          GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: 2.15, crossAxisSpacing: 10, mainAxisSpacing: 10, children: ['0', '1', '2', '3', '4', '6', 'W', 'Wide', 'No Ball', 'Bye', 'Leg Bye', 'Undo', 'End'].map(scoreButton).toList()),
        ]),
      ),
    );
  }

  Widget scoreButton(String label) {
    final danger = label == 'W' || label == 'End';
    return InkWell(onTap: () => tap(label), borderRadius: BorderRadius.circular(14), child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: danger ? C.red.withOpacity(.14) : C.cyan.withOpacity(.12), border: Border.all(color: danger ? C.red : C.cyan.withOpacity(.7))), alignment: Alignment.center, child: Text(label, textAlign: TextAlign.center, style: normalStyle(color: danger ? C.red : Colors.white, weight: FontWeight.w900))));
  }

  void save() => undo.add([runs, wickets, balls, List<String>.from(timeline)]);

  void tap(String label) {
    if (label == 'Undo') {
      if (undo.isNotEmpty) {
        final last = undo.removeLast();
        setState(() { runs = last[0] as int; wickets = last[1] as int; balls = last[2] as int; timeline..clear()..addAll((last[3] as List<String>)); });
      }
      return;
    }
    if (label == 'End') { share(); return; }
    save();
    setState(() {
      if (['0', '1', '2', '3', '4', '6'].contains(label)) { runs += int.parse(label); balls++; timeline.add(label); }
      if (label == 'W') { wickets++; balls++; timeline.add('W'); }
      if (label == 'Wide') { runs++; timeline.add('Wd'); }
      if (label == 'No Ball') { runs++; timeline.add('Nb'); }
      if (label == 'Bye') { runs++; balls++; timeline.add('B'); }
      if (label == 'Leg Bye') { runs++; balls++; timeline.add('LB'); }
    });
  }

  String crr() => balls == 0 ? '0.00' : (runs / (balls / 6)).toStringAsFixed(2);
  Color? ballColor(String s) { if (s == '4') return C.cyan2; if (s == '6') return C.purple; if (s == 'W') return C.red; if (s == 'Wd' || s == 'Nb') return C.orange; return null; }
  Future<void> share() async { await Clipboard.setData(ClipboardData(text: 'Allrounder99 Live Score\nTeam A $runs-$wickets (${overText(balls)})\nPowered by Allrounder99')); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Score copied. Paste on WhatsApp.'))); }
}

class SmallStat extends StatelessWidget {
  final String title;
  final String value;
  const SmallStat(this.title, this.value, {super.key});
  @override
  Widget build(BuildContext context) => Column(children: [Text(title, style: normalStyle(color: C.muted, size: 13)), const SizedBox(height: 5), Text(value, style: normalStyle(color: C.cyan, size: 18, weight: FontWeight.w900))]);
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext context) => AppBg(child: ListView(padding: const EdgeInsets.fromLTRB(16, 24, 16, 118), children: const [Header(), SimpleCard('WhatsApp Link', 'https://go.wa.link/allrounder99'), SizedBox(height: 12), SimpleCard('Website Link', 'https://Gamerush99.com'), SizedBox(height: 12), SimpleCard('About App', 'Allrounder99 professional cricket scoring app with fixtures, series, live score and manual scoring.') ]));
}

class ShortTile extends StatelessWidget {
  final String title;
  final Color color;
  const ShortTile({super.key, required this.title, required this.color});
  @override
  Widget build(BuildContext context) => Container(width: 150, margin: const EdgeInsets.only(right: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: LinearGradient(colors: [color, Colors.black]), border: Border.all(color: Colors.white24)), child: const Center(child: Icon(Icons.play_arrow, color: Colors.white, size: 46)))), const SizedBox(height: 8), Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: normalStyle(weight: FontWeight.w800))]));
}

class SimpleCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SimpleCard(this.title, this.subtitle, {super.key});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(18), decoration: cardDec(radius: 16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: titleStyle(20)), const SizedBox(height: 8), SelectableText(subtitle, style: normalStyle(color: C.muted))]));
}

class BottomNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const BottomNav({super.key, required this.index, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final items = const [
      [Icons.home, 'Home'], [Icons.calendar_today, 'Fixtures'], [Icons.emoji_events, 'Series'], [Icons.sports_cricket, 'Score'], [Icons.more_horiz, 'More'],
    ];
    return SafeArea(top: false, child: Container(margin: const EdgeInsets.fromLTRB(8, 0, 8, 8), padding: const EdgeInsets.symmetric(vertical: 10), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF07131D), Color(0xFF0B1721)]), border: Border.all(color: C.border), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.5), blurRadius: 20, offset: const Offset(0, -4))]), child: Row(children: List.generate(items.length, (i) { final active = i == index; return Expanded(child: InkWell(onTap: () => onTap(i), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(items[i][0] as IconData, color: active ? C.cyan : Colors.white70, size: 26), const SizedBox(height: 4), Text(items[i][1] as String, style: normalStyle(color: active ? C.cyan : Colors.white70, size: 12, weight: active ? FontWeight.w900 : FontWeight.w600))]))); }))));
  }
}
