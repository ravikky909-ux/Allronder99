import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'firebase_options.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (_) {}
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    await FirebaseMessaging.instance.subscribeToTopic('all_users');
  } catch (_) {}
  runApp(const Allrounder99App());
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Allrounder99',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColor.bg,
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const SplashScreen(),
    );
  }
}

class AppColor {
  static const bg = Color(0xFF070B0F);
  static const bg2 = Color(0xFF0B1218);
  static const card = Color(0xFF172029);
  static const card2 = Color(0xFF202A33);
  static const line = Color(0xFF34404B);
  static const cyan = Color(0xFF08C7FF);
  static const blue = Color(0xFF058DFF);
  static const text = Color(0xFFE9F1F7);
  static const muted = Color(0xFF9AA6B2);
  static const green = Color(0xFF28A745);
  static const red = Color(0xFFE64040);
  static const orange = Color(0xFFE59A3A);
  static const purple = Color(0xFF7A4DFF);
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 4500), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const MainShell()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: Column(
            children: [
              const Spacer(),
              Container(
                height: 230,
                width: 230,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColor.cyan.withOpacity(0.30),
                      blurRadius: 55,
                      spreadRadius: 8,
                    ),
                  ],
                ),
                child: ClipOval(child: Image.asset('assets/logo.png', fit: BoxFit.contain)),
              ),
              const SizedBox(height: 20),
              const Text(
                'ALLROUNDER99',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  color: AppColor.text,
                  fontStyle: FontStyle.italic,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'CRICKET  •  FAST SCORES  •  REAL TIME',
                style: TextStyle(fontSize: 12, color: AppColor.cyan, fontWeight: FontWeight.w700),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 68),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: const LinearProgressIndicator(
                    minHeight: 4,
                    color: AppColor.cyan,
                    backgroundColor: AppColor.card2,
                  ),
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  late final List<Widget> pages = [
    HomePage(openMatch: openMatch),
    FixturesPage(openMatch: openMatch),
    const SeriesPage(),
    const MorePage(),
  ];

  void openMatch() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchDetailPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF0C1117),
          border: Border(top: BorderSide(color: AppColor.line, width: 0.5)),
        ),
        child: SafeArea(
          top: false,
          child: NavigationBar(
            selectedIndex: index,
            height: 64,
            backgroundColor: Colors.transparent,
            indicatorColor: AppColor.cyan.withOpacity(0.14),
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            onDestinationSelected: (value) => setState(() => index = value),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: AppColor.cyan), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.sports_cricket_outlined), selectedIcon: Icon(Icons.sports_cricket, color: AppColor.cyan), label: 'Fixtures'),
              NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events, color: AppColor.cyan), label: 'Series'),
              NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz, color: AppColor.cyan), label: 'More'),
            ],
          ),
        ),
      ),
    );
  }
}

class GradientPage extends StatelessWidget {
  final Widget child;
  const GradientPage({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF030608), Color(0xFF071017), Color(0xFF051D2A)],
        ),
      ),
      child: child,
    );
  }
}

class TopLogo extends StatelessWidget {
  const TopLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppColor.cyan, width: 1),
          ),
          child: ClipOval(child: Image.asset('assets/logo.png', fit: BoxFit.contain)),
        ),
        const SizedBox(width: 8),
        const Text.rich(
          TextSpan(
            children: [
              TextSpan(text: 'ALLROUNDER', style: TextStyle(color: AppColor.text)),
              TextSpan(text: '99', style: TextStyle(color: AppColor.cyan)),
            ],
          ),
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, letterSpacing: 0.3),
        ),
      ],
    );
  }
}

class CircleTeam extends StatelessWidget {
  final String label;
  final Color color;
  final String? flag;
  const CircleTeam({super.key, required this.label, required this.color, this.flag});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: 50,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [color, color.withOpacity(0.55)]),
        border: Border.all(color: Colors.white.withOpacity(0.20)),
      ),
      child: Center(
        child: Text(flag ?? label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.onTap});

  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: AppColor.card.withOpacity(0.94),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColor.line.withOpacity(0.85), width: 0.75),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: child,
    );
    if (onTap == null) return card;
    return InkWell(borderRadius: BorderRadius.circular(12), onTap: onTap, child: card);
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  const SectionHeader(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
      child: Row(
        children: [
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const Spacer(),
          const Text('View all', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w700, fontSize: 12)),
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final bool selected;
  final Color? color;
  final VoidCallback? onTap;
  const Pill(this.text, {super.key, this.selected = false, this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColor.cyan;
    final child = Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? c.withOpacity(0.95) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: selected ? c : AppColor.line),
      ),
      child: Text(text, style: TextStyle(fontWeight: FontWeight.w700, color: selected ? Colors.white : AppColor.muted, fontSize: 12)),
    );
    return GestureDetector(
      onTap: onTap ?? () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$text selected'), duration: const Duration(milliseconds: 800))),
      child: child,
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback openMatch;
  const HomePage({super.key, required this.openMatch});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
          children: [
            Row(
              children: [
                const TopLogo(),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(color: AppColor.card, borderRadius: BorderRadius.circular(22)),
                  child: const Row(children: [Icon(Icons.search, size: 18), SizedBox(width: 8), Text('Search', style: TextStyle(color: AppColor.muted))]),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SimpleOptionPage(title: 'Settings', subtitle: 'App settings and preferences'))), icon: const Icon(Icons.settings_outlined)),
              ],
            ),
            const SizedBox(height: 18),
            const Row(children: [Pill('Featured', selected: true), SizedBox(width: 10), Pill('Live'), SizedBox(width: 10), Pill('WT20 WC')]),
            const SizedBox(height: 12),
            FeaturedMatchCard(openMatch: openMatch),
            const SizedBox(height: 12),
            const QuickFeatureGrid(),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: const [
                Pill('WT20 WC 2026', selected: true), SizedBox(width: 8), Pill('WT20 WC Winners'), SizedBox(width: 8), Pill('Rankings'),
              ]),
            ),
            const SectionHeader('Trending Series'),
            GlassCard(
              child: Row(
                children: [
                  Container(
                    height: 72,
                    width: 86,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), gradient: const LinearGradient(colors: [Color(0xFF712BFF), Color(0xFFFF2995)])),
                    child: const Center(child: Text('T20\nWC', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text("Women's T20 World Cup 2026", style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      SizedBox(height: 8),
                      Text('12 Jun - 05 Jul 2026', style: TextStyle(color: AppColor.muted)),
                      SizedBox(height: 4),
                      Text('33 Matches', style: TextStyle(color: AppColor.muted)),
                    ]),
                  ),
                  const Icon(Icons.chevron_right, color: AppColor.muted),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class QuickFeatureGrid extends StatelessWidget {
  const QuickFeatureGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.flash_on, 'Live Matches', 'Fast score updates'),
      (Icons.comment_outlined, 'Commentary', 'Ball by ball'),
      (Icons.table_chart_outlined, 'Scorecards', 'Full match score'),
      (Icons.emoji_events_outlined, 'Points Table', 'League standings'),
      (Icons.leaderboard_outlined, 'Rankings', 'ICC & league'),
      (Icons.analytics_outlined, 'Insights & Graphs', 'Trends & analysis'),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 2.45,
      ),
      itemBuilder: (context, i) {
        final item = items[i];
        return GlassCard(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => SimpleOptionPage(title: item.$2, subtitle: featureSubtitle(item.$2))),
          ),
          child: Row(
            children: [
              Icon(item.$1, color: AppColor.cyan, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(item.$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12.5)),
                    const SizedBox(height: 2),
                    Text(item.$3, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColor.muted, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

String featureSubtitle(String t) {
  switch (t) {
    case 'Live Matches': return 'Live score, current over, run rate, target and live match status.';
    case 'Fixtures & Schedule': return 'Day wise, series wise and team wise upcoming fixtures.';
    case 'Series & Leagues': return 'International, domestic and T20 league tournament details.';
    case 'Commentary': return 'Ball by ball commentary with runs, wickets, boundaries and over summary.';
    case 'Scorecards': return 'Batting, bowling, extras, fall of wickets and full innings scorecards.';
    case 'Points Table': return 'Team standings with played, won, lost, NRR and points.';
    case 'Squads': return 'Playing XI, bench players and team squad list.';
    case 'Players': return 'Player profile, batting stats, bowling stats, form and records.';
    case 'Teams': return 'Team profile, squad, schedule, recent form and records.';
    case 'Rankings': return 'Team and player rankings for batting, bowling and all-rounders.';
    case 'Stats & Records': return 'Batting records, bowling records, strike rate, economy and milestones.';
    case 'Match Insights': return 'Win probability, head to head, venue data and match summary.';
    case 'Insights & Graphs': return 'Run rate graph, worm graph, partnerships and match trends.';
    case 'News': return 'Latest cricket news and match stories. Shorts option removed as requested.';
    case 'Voice Commentary': return 'Voice commentary option screen ready.';
    default: return 'This option is working in Allrounder99 demo mode.';
  }
}

class FeaturedMatchCard extends StatelessWidget {
  final VoidCallback openMatch;
  const FeaturedMatchCard({super.key, required this.openMatch});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      onTap: openMatch,
      padding: const EdgeInsets.all(0),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(13),
            child: Row(
              children: const [
                Pill('LIVE', selected: true, color: AppColor.red),
                SizedBox(width: 8),
                Expanded(child: Text('Andhra Premier League 2026, 25th Match', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14))),
                Icon(Icons.chevron_right, color: AppColor.muted),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColor.line),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const CircleTeam(label: 'CAMR', color: Color(0xFFC51238)),
                const SizedBox(width: 10),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('CAMR', style: TextStyle(fontWeight: FontWeight.w700)),
                  SizedBox(height: 8),
                  Text('Bowling', style: TextStyle(color: AppColor.muted)),
                ])),
                const Icon(Icons.flash_on, color: AppColor.text, size: 30),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('46-1', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  Text('5.1 Over', style: TextStyle(color: AppColor.muted)),
                  SizedBox(height: 8),
                  Text('VJS', style: TextStyle(fontWeight: FontWeight.w700)),
                ])),
                const SizedBox(width: 10),
                const CircleTeam(label: 'VJS', color: Color(0xFF1E9C65)),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(color: Color(0xFF0E1820), borderRadius: BorderRadius.vertical(bottom: Radius.circular(12))),
            child: const Center(child: Text('VJS 46-1 (5.1) • Live now • 1 Run', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900))),
          ),
        ],
      ),
    );
  }
}

class ShortTile extends StatelessWidget {
  final String title;
  final Color color;
  const ShortTile({super.key, required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 124,
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color, Colors.black]),
        border: Border.all(color: AppColor.line),
      ),
      child: Stack(
        children: [
          const Center(child: Icon(Icons.play_circle_fill, size: 44, color: Colors.white)),
          Positioned(left: 8, right: 8, bottom: 8, child: Text(title, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12))),
        ],
      ),
    );
  }
}

class ShortsPage extends StatelessWidget {
  const ShortsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Row(children: [Text('Shorts', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Spacer(), Icon(Icons.search)]),
            const SizedBox(height: 14),
            const Row(children: [Pill('Trending', selected: true), SizedBox(width: 8), Pill('Popular'), SizedBox(width: 8), Pill('Recent')]),
            const SizedBox(height: 12),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 0.74,
              children: const [
                ShortTile(title: 'RCB last over thriller', color: Color(0xFFC21E36)),
                ShortTile(title: 'Top 10 catches', color: Color(0xFFE7A928)),
                ShortTile(title: 'MS Dhoni six', color: Color(0xFF4352C8)),
                ShortTile(title: 'Best yorkers', color: Color(0xFF1283C5)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class FixturesPage extends StatelessWidget {
  final VoidCallback openMatch;
  const FixturesPage({super.key, required this.openMatch});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Row(children: [Text('Fixtures', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Spacer(), Icon(Icons.search), SizedBox(width: 12), Icon(Icons.notifications_none)]),
            const SizedBox(height: 12),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [Text('Day wise', style: TextStyle(fontWeight: FontWeight.w800, color: AppColor.cyan)), Text('Series wise'), Text('Team wise')]),
            const SizedBox(height: 12),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: const [Pill('All', selected: true), SizedBox(width: 8), Pill('T20'), SizedBox(width: 8), Pill('ODI'), SizedBox(width: 8), Pill('Test'), SizedBox(width: 8), Pill('Hundred')])),
            const SizedBox(height: 16),
            const Text('Fri, 26 Jun 2026', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            FixtureCard(openMatch: openMatch, title: 'Andhra Premier League 2026', status: 'Live', scoreA: '', teamA: 'CAMR', scoreB: '46-1 (5.1)', teamB: 'VJS', result: 'Live now - VJS 46-1 after 5.1 overs'),
            FixtureCard(openMatch: openMatch, title: 'Andhra Premier League 2026', status: 'Upcoming', scoreA: '', teamA: 'Capital Amaravati Royals', scoreB: '', teamB: 'Vijayawada Sunshiners', result: 'Venue - Amaravathi, India'),
            FixtureCard(openMatch: openMatch, title: 'Women T20 Blast 2026', status: 'Upcoming', scoreA: '', teamA: 'Warwickshire Women', scoreB: '', teamB: 'Surrey Women', result: 'Venue - Birmingham, England'),
          ],
        ),
      ),
    );
  }
}

class FixtureCard extends StatelessWidget {
  final VoidCallback? openMatch;
  final String title, status, scoreA, teamA, scoreB, teamB, result;
  const FixtureCard({super.key, this.openMatch, required this.title, required this.status, required this.scoreA, required this.teamA, required this.scoreB, required this.teamB, required this.result});

  @override
  Widget build(BuildContext context) {
    final statusColor = status == 'Live' ? AppColor.red : (status == 'Finished' ? AppColor.green : AppColor.orange);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        onTap: openMatch,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))), Pill(status, color: statusColor, selected: true)]),
          const SizedBox(height: 4),
          const Text('9th Match - 07:00 AM', style: TextStyle(color: AppColor.muted)),
          const Divider(height: 22, color: AppColor.line),
          Row(children: [
            const CircleTeam(label: 'A', color: Color(0xFFF1A0A6)), const SizedBox(width: 10),
            Expanded(child: Text(scoreA.isEmpty ? teamA : '$scoreA\n$teamA', style: const TextStyle(fontWeight: FontWeight.w800))),
            const Icon(Icons.flash_on, color: AppColor.text),
            Expanded(child: Text(scoreB.isEmpty ? teamB : '$scoreB\n$teamB', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800))), const SizedBox(width: 10),
            const CircleTeam(label: 'B', color: Color(0xFF1E70D8)),
          ]),
          const Divider(height: 22, color: AppColor.line),
          Text(result, style: TextStyle(color: result.startsWith('Venue') ? Color(0xFFFFF3A5) : Color(0xFFFF8BA0), fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class SeriesPage extends StatelessWidget {
  const SeriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Row(children: [Text('Series', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Spacer(), Icon(Icons.search)]),
            const SizedBox(height: 12),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [Text('Day wise'), Text('Series wise', style: TextStyle(fontWeight: FontWeight.w800, color: AppColor.cyan)), Text('Team wise')]),
            const SizedBox(height: 12),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: const [Pill('All', selected: true), SizedBox(width: 8), Pill('International'), SizedBox(width: 8), Pill('T20 Leagues'), SizedBox(width: 8), Pill('Domestic')])),
            const SizedBox(height: 12),
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColor.card, borderRadius: BorderRadius.circular(10)), child: const Row(children: [Icon(Icons.search, color: AppColor.muted), SizedBox(width: 10), Text('Search Series', style: TextStyle(color: AppColor.muted))])),
            const SizedBox(height: 16),
            const Text('June 2026', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            const SeriesTile(name: 'Vidarbha Premier League 2026', dates: '01 Jun - 14 Jun', matches: '25 Matches', status: 'Finished', color: Color(0xFFB78919)),
            const SeriesTile(name: 'T20 Mumbai 2026', dates: '01 Jun - 13 Jun', matches: '23 Matches', status: 'Finished', color: Color(0xFF165CC3)),
            const SeriesTile(name: 'Asian Legends League 2026', dates: '02 Jun - 14 Jun', matches: '19 Matches', status: 'Postponed', color: Color(0xFFC71225)),
            const SeriesTile(name: 'Ireland Inter-Provincial T20 Trophy 2026', dates: '02 Jun - 17 Jun', matches: '9 Matches', status: 'Finished', color: Color(0xFF0B7D3C)),
            const SeriesTile(name: 'Madhya Pradesh T20 League 2026', dates: '03 Jun - 26 Jun', matches: '48 Matches', status: 'Ongoing', color: Color(0xFF123A8D)),
          ],
        ),
      ),
    );
  }
}

class SeriesTile extends StatelessWidget {
  final String name, dates, matches, status;
  final Color color;
  const SeriesTile({super.key, required this.name, required this.dates, required this.matches, required this.status, required this.color});

  @override
  Widget build(BuildContext context) {
    final c = status == 'Finished' ? AppColor.green : (status == 'Ongoing' ? AppColor.red : AppColor.muted);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SimpleOptionPage(title: name, subtitle: '$dates • $matches • $status'))),
        child: Row(children: [
          Container(height: 64, width: 64, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: color), child: Center(child: Text(name.split(' ').first.substring(0, 1), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)), const SizedBox(height: 7), Text(dates, style: const TextStyle(color: AppColor.muted)), const SizedBox(height: 4), Text(matches, style: const TextStyle(color: AppColor.muted)),
          ])),
          Pill(status, color: c),
        ]),
      ),
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    return GradientPage(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Text('More', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 16),
            MenuItem(icon: Icons.admin_panel_settings_outlined, title: 'Admin Panel', trailing: 'New', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPanelPage()))),
            MenuItem(icon: Icons.notifications_active_outlined, title: 'Push Notifications', trailing: 'FCM', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PushNotificationPage()))),
            const MenuItem(icon: Icons.flash_on, title: 'Live Matches'),
            const MenuItem(icon: Icons.calendar_month_outlined, title: 'Fixtures & Schedule'),
            const MenuItem(icon: Icons.emoji_events_outlined, title: 'Series & Leagues'),
            const MenuItem(icon: Icons.comment_outlined, title: 'Commentary'),
            const MenuItem(icon: Icons.table_chart_outlined, title: 'Scorecards'),
            const MenuItem(icon: Icons.leaderboard_outlined, title: 'Points Table'),
            const MenuItem(icon: Icons.groups_2_outlined, title: 'Squads'),
            const MenuItem(icon: Icons.groups_outlined, title: 'Teams'),
            const MenuItem(icon: Icons.person_search_outlined, title: 'Players'),
            const MenuItem(icon: Icons.analytics_outlined, title: 'Stats & Records'),
            const MenuItem(icon: Icons.insights_outlined, title: 'Match Insights'),
            const MenuItem(icon: Icons.show_chart_outlined, title: 'Insights & Graphs'),
            const MenuItem(icon: Icons.newspaper_outlined, title: 'News'),
            const MenuItem(icon: Icons.record_voice_over_outlined, title: 'Voice Commentary'),
            const MenuItem(icon: Icons.notifications_active_outlined, title: 'Live Score Alerts', trailing: 'On'),
            const MenuItem(icon: Icons.account_circle_outlined, title: 'My Profile'),
            const MenuItem(icon: Icons.sports_cricket, title: 'My Matches'),
            const MenuItem(icon: Icons.emoji_events_outlined, title: 'My Series'),
            const MenuItem(icon: Icons.favorite_border, title: 'Favorite Teams'),
            const MenuItem(icon: Icons.bookmark_border, title: 'Watchlist'),
            const MenuItem(icon: Icons.download_outlined, title: 'Downloads'),
            const MenuItem(icon: Icons.leaderboard_outlined, title: 'Rankings'),
            const MenuItem(icon: Icons.settings_outlined, title: 'Settings'),
            const MenuItem(icon: Icons.dark_mode_outlined, title: 'Dark Mode', trailing: 'On'),
            const MenuItem(icon: Icons.language, title: 'Language', trailing: 'English'),
            const MenuItem(icon: Icons.share_outlined, title: 'Share App'),
            const MenuItem(icon: Icons.star_border, title: 'Rate Us'),
            const MenuItem(icon: Icons.support_agent, title: 'Help & Support'),
            const MenuItem(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy'),
            const MenuItem(icon: Icons.description_outlined, title: 'Terms & Conditions'),
            const MenuItem(icon: Icons.info_outline, title: 'About Allrounder99', trailing: 'v1.0.0'),
          ],
        ),
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final VoidCallback? onTap;
  const MenuItem({super.key, required this.icon, required this.title, this.trailing, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        onTap: onTap ?? () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => SimpleOptionPage(title: title, subtitle: _subtitle(title))),
          );
        },
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        child: Row(children: [
          Icon(icon, size: 20, color: AppColor.text),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))),
          Text(trailing ?? '', style: const TextStyle(color: AppColor.muted)),
          const Icon(Icons.chevron_right, color: AppColor.muted),
        ]),
      ),
    );
  }

  String _subtitle(String t) {
    switch (t) {
      case 'Live Matches': return featureSubtitle(t);
      case 'Fixtures & Schedule': return featureSubtitle(t);
      case 'Series & Leagues': return featureSubtitle(t);
      case 'Commentary': return featureSubtitle(t);
      case 'Scorecards': return featureSubtitle(t);
      case 'Points Table': return featureSubtitle(t);
      case 'Squads': return featureSubtitle(t);
      case 'Stats & Records': return featureSubtitle(t);
      case 'Match Insights': return featureSubtitle(t);
      case 'Insights & Graphs': return featureSubtitle(t);
      case 'News': return featureSubtitle(t);
      case 'Voice Commentary': return featureSubtitle(t);
      case 'My Profile': return 'Profile details, photo, phone and account info.';
      case 'My Matches': return 'Saved and followed matches list.';
      case 'My Series': return 'Followed series and tournament list.';
      case 'Live Score Alerts': return 'Live alerts are switched on.';
      case 'Favorite Teams': return 'Choose and manage favorite teams.';
      case 'Watchlist': return 'Matches and players saved to watchlist.';
      case 'Downloads': return 'Offline scorecards and saved match data.';
      case 'Rankings': return featureSubtitle(t);
      case 'Teams': return featureSubtitle(t);
      case 'Players': return featureSubtitle(t);
      case 'Settings': return 'Theme, language, notifications and app preferences.';
      case 'Language': return 'English selected. Hindi can be added in next update.';
      case 'Share App': return 'Share Allrounder99 with friends.';
      case 'Rate Us': return 'Rating screen ready for Play Store link.';
      case 'Help & Support': return 'Support page with contact details.';
      case 'Privacy Policy': return 'Privacy policy page placeholder.';
      case 'Terms & Conditions': return 'Terms and conditions page placeholder.';
      case 'About Allrounder99': return 'Allrounder99 v1.0.0 cricket scoring app.';
      default: return 'This option is working.';
    }
  }
}

class SimpleOptionPage extends StatelessWidget {
  final String title;
  final String subtitle;
  const SimpleOptionPage({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              Row(children: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)), Expanded(child: Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)))]),
              const SizedBox(height: 14),
              GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: const [TopLogo(), Spacer(), Icon(Icons.check_circle, color: AppColor.cyan)]),
                const SizedBox(height: 18),
                Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColor.cyan)),
                const SizedBox(height: 10),
                Text(subtitle, style: const TextStyle(fontSize: 15, color: AppColor.text, height: 1.45)),
                const SizedBox(height: 16),
                const Text('Screen connected successfully. Backend/API integration can be added later.', style: TextStyle(color: AppColor.muted)),
                const SizedBox(height: 16),
                FeatureContent(title: title),
              ])),
            ],
          ),
        ),
      ),
    );
  }
}


class AdminPanelPage extends StatefulWidget {
  const AdminPanelPage({super.key});

  @override
  State<AdminPanelPage> createState() => _AdminPanelPageState();
}

class _AdminPanelPageState extends State<AdminPanelPage> {
  final TextEditingController titleController = TextEditingController(text: 'Allrounder99 Live Alert');
  final TextEditingController bodyController = TextEditingController(text: 'CAMR vs VJS live score updated. Tap to view scorecard.');

  @override
  void dispose() {
    titleController.dispose();
    bodyController.dispose();
    super.dispose();
  }

  void _show(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              Row(children: [
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)),
                const Expanded(child: Text('Admin Panel', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
              ]),
              const SizedBox(height: 12),
              GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: const [TopLogo(), Spacer(), Pill('ADMIN', selected: true)]),
                const SizedBox(height: 16),
                const Text('Push Notification Composer', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppColor.cyan)),
                const SizedBox(height: 12),
                AdminTextField(label: 'Notification title', controller: titleController, icon: Icons.title),
                const SizedBox(height: 10),
                AdminTextField(label: 'Message body', controller: bodyController, icon: Icons.message_outlined, maxLines: 3),
                const SizedBox(height: 14),
                Row(children: [
                  Expanded(child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: AppColor.cyan, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    onPressed: () => _show('Notification draft saved in admin panel'),
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('Save Draft'),
                  )),
                  const SizedBox(width: 10),
                  Expanded(child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: AppColor.text, side: const BorderSide(color: AppColor.cyan), padding: const EdgeInsets.symmetric(vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    onPressed: () => _show('Backend Cloud Function connect karne ke baad real push send hoga'),
                    icon: const Icon(Icons.send_outlined),
                    label: const Text('Send Push'),
                  )),
                ]),
              ])),
              const SizedBox(height: 12),
              AdminActionTile(icon: Icons.sports_cricket, title: 'Manage Live Match', subtitle: 'Score, over, batter, bowler update', onTap: () => _show('Live match editor ready')),
              AdminActionTile(icon: Icons.emoji_events_outlined, title: 'Manage Series', subtitle: 'Series name, schedule, points table', onTap: () => _show('Series manager ready')),
              AdminActionTile(icon: Icons.table_chart_outlined, title: 'Scorecard Control', subtitle: 'Batting and bowling score table', onTap: () => _show('Scorecard control ready')),
              AdminActionTile(icon: Icons.newspaper_outlined, title: 'Publish News', subtitle: 'News, match preview, result story', onTap: () => _show('News publisher ready')),
              AdminActionTile(icon: Icons.notifications_active_outlined, title: 'Notification Settings', subtitle: 'Topics: all users, live scores, news', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PushNotificationPage()))),
              AdminActionTile(icon: Icons.privacy_tip_outlined, title: 'Privacy & Terms', subtitle: 'Policy pages for Play Store', onTap: () => _show('Privacy/Terms editor ready')),
            ],
          ),
        ),
      ),
    );
  }
}

class AdminTextField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final IconData icon;
  final int maxLines;
  const AdminTextField({super.key, required this.label, required this.controller, required this.icon, this.maxLines = 1});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      style: const TextStyle(color: AppColor.text),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: AppColor.muted),
        filled: true,
        fillColor: AppColor.bg2,
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColor.line)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColor.cyan)),
      ),
    );
  }
}

class AdminActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const AdminActionTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(
        onTap: onTap,
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          Icon(icon, color: AppColor.cyan),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(color: AppColor.muted, fontSize: 12)),
          ])),
          const Icon(Icons.chevron_right, color: AppColor.muted),
        ]),
      ),
    );
  }
}

class PushNotificationPage extends StatefulWidget {
  const PushNotificationPage({super.key});

  @override
  State<PushNotificationPage> createState() => _PushNotificationPageState();
}

class _PushNotificationPageState extends State<PushNotificationPage> {
  String status = 'Notification permission pending';
  String token = 'Tap Enable Notifications to get device token';

  Future<void> _enable() async {
    try {
      final settings = await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
      final fcmToken = await FirebaseMessaging.instance.getToken();
      await FirebaseMessaging.instance.subscribeToTopic('all_users');
      await FirebaseMessaging.instance.subscribeToTopic('live_scores');
      if (!mounted) return;
      setState(() {
        status = 'Permission: ${settings.authorizationStatus.name} • Subscribed to all_users and live_scores';
        token = fcmToken ?? 'Token not available yet';
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Push notifications enabled')));
    } catch (e) {
      if (!mounted) return;
      setState(() => status = 'FCM setup error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              Row(children: [
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)),
                const Expanded(child: Text('Push Notifications', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
              ]),
              const SizedBox(height: 12),
              GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: const [TopLogo(), Spacer(), Icon(Icons.notifications_active_outlined, color: AppColor.cyan)]),
                const SizedBox(height: 16),
                const Text('Allrounder99 Alerts', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColor.cyan)),
                const SizedBox(height: 10),
                const Text('Live score, wicket, boundary, news aur match update ke push alerts yahan se enable honge.', style: TextStyle(color: AppColor.text, height: 1.45)),
                const SizedBox(height: 14),
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: AppColor.cyan, foregroundColor: Colors.white, minimumSize: const Size(double.infinity, 48), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  onPressed: _enable,
                  icon: const Icon(Icons.notifications_active_outlined),
                  label: const Text('Enable Notifications'),
                ),
                const SizedBox(height: 14),
                Text(status, style: const TextStyle(color: AppColor.text, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: AppColor.bg2, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColor.line)),
                  child: Text(token, style: const TextStyle(color: AppColor.muted, fontSize: 12)),
                ),
              ])),
              const SizedBox(height: 12),
              const GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Topics', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 12),
                Row(children: [Icon(Icons.check_circle, color: AppColor.cyan), SizedBox(width: 10), Expanded(child: Text('all_users • General app notifications'))]),
                SizedBox(height: 10),
                Row(children: [Icon(Icons.check_circle, color: AppColor.cyan), SizedBox(width: 10), Expanded(child: Text('live_scores • Match score alerts'))]),
                SizedBox(height: 10),
                Row(children: [Icon(Icons.info_outline, color: AppColor.orange), SizedBox(width: 10), Expanded(child: Text('Real push send karne ke liye Firebase Cloud Function / backend connect karna hoga.'))]),
              ])),
            ],
          ),
        ),
      ),
    );
  }
}
class FeatureContent extends StatelessWidget {
  final String title;
  const FeatureContent({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final rows = _rows(title);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Preview', style: TextStyle(color: AppColor.cyan, fontWeight: FontWeight.w900, fontSize: 16)),
        const SizedBox(height: 10),
        for (final row in rows) Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColor.bg2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColor.line),
            ),
            child: Row(
              children: [
                Icon(row.$1, color: AppColor.cyan, size: 20),
                const SizedBox(width: 10),
                Expanded(child: Text(row.$2, style: const TextStyle(fontWeight: FontWeight.w700))),
                if (row.$3.isNotEmpty) Text(row.$3, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  List<(IconData, String, String)> _rows(String t) {
    switch (t) {
      case 'Live Matches':
        return [
          (Icons.circle, 'CAMR vs VJS • Live', 'VJS 46-1'),
          (Icons.flash_on, 'Current ball TV update', '1 Run'),
          (Icons.speed, 'Run Rate / Balls Remaining', '8.9 / 89'),
        ];
      case 'Fixtures & Schedule':
        return [
          (Icons.today, 'Day wise fixtures', 'Today'),
          (Icons.emoji_events, 'Series wise fixtures', 'T20'),
          (Icons.groups, 'Team wise fixtures', 'India'),
        ];
      case 'Series & Leagues':
        return [
          (Icons.emoji_events, 'IPL / T20 League / Domestic', 'Live'),
          (Icons.calendar_month, 'Series dates and total matches', '33'),
          (Icons.table_chart, 'Points table and squads', 'Ready'),
        ];
      case 'Commentary':
        return [
          (Icons.sports_cricket, '5.1 FOUR! Beautiful square drive.', '46-1'),
          (Icons.sports_cricket, '5.0 Single, tucked away to mid-wicket.', '42-1'),
          (Icons.sports_cricket, 'Over summary with runs and wickets', '12 runs'),
        ];
      case 'Scorecards':
        return [
          (Icons.person, 'Ashwin Hebbar 16 (9)', 'SR 177.78'),
          (Icons.person, 'Harshavardhan 23 (15)', 'SR 153.34'),
          (Icons.sports_baseball, 'M Toshith Yadav 2.1-0-20-1', 'Eco 9.24'),
        ];
      case 'Points Table':
        return [
          (Icons.looks_one, 'CAMR', '12 pts'),
          (Icons.looks_two, 'VJS', '10 pts'),
          (Icons.trending_up, 'NRR and standings included', '+1.245'),
        ];
      case 'Squads':
        return [
          (Icons.groups, 'Playing XI', '11'),
          (Icons.person_add, 'Bench players', '7'),
          (Icons.sports_cricket, 'Captain / wicket keeper tags', 'Ready'),
        ];
      case 'Players':
        return [
          (Icons.person, 'Player profile', 'Stats'),
          (Icons.sports_cricket, 'Batting / Bowling records', 'Ready'),
          (Icons.timeline, 'Recent form and milestones', 'Ready'),
        ];
      case 'Teams':
        return [
          (Icons.groups, 'Team profile', 'Squad'),
          (Icons.calendar_month, 'Team schedule', 'Fixtures'),
          (Icons.history, 'Recent results', 'Form'),
        ];
      case 'Rankings':
        return [
          (Icons.leaderboard, 'Team ranking', 'India #1'),
          (Icons.person, 'Batter ranking', 'Top 10'),
          (Icons.sports_baseball, 'Bowler / all-rounder ranking', 'Top 10'),
        ];
      case 'Stats & Records':
        return [
          (Icons.bar_chart, 'Batting stats', 'Runs / SR'),
          (Icons.show_chart, 'Bowling stats', 'Wickets / Eco'),
          (Icons.star, 'Records and milestones', 'Ready'),
        ];
      case 'Match Insights':
        return [
          (Icons.percent, 'Win probability', 'VJS 76%'),
          (Icons.compare_arrows, 'Head to head', '12 matches'),
          (Icons.stadium, 'Venue performance', 'Good batting'),
        ];
      case 'Insights & Graphs':
        return [
          (Icons.show_chart, 'Run rate graph', 'Ready'),
          (Icons.timeline, 'Worm graph', 'Ready'),
          (Icons.handshake, 'Partnership graph', 'Ready'),
        ];
      case 'News':
        return [
          (Icons.newspaper, 'Latest cricket news', 'Updated'),
          (Icons.article, 'Match stories', 'Ready'),
          (Icons.notifications, 'News alerts', 'Ready'),
        ];
      case 'Voice Commentary':
        return [
          (Icons.volume_up, 'Hindi / English voice option', 'Ready'),
          (Icons.record_voice_over, 'Boundary and wicket voice', 'Ready'),
          (Icons.settings_voice, 'Voice settings', 'Ready'),
        ];
      default:
        return [
          (Icons.check_circle, '$title screen is connected', 'Working'),
          (Icons.storage, 'Sample data loaded', 'Ready'),
          (Icons.api, 'API/backend can be connected later', 'Next'),
        ];
    }
  }
}

class MatchDetailPage extends StatefulWidget {
  const MatchDetailPage({super.key});

  @override
  State<MatchDetailPage> createState() => _MatchDetailPageState();
}

class _MatchDetailPageState extends State<MatchDetailPage> {
  int tab = 1;
  final tabs = const ['Info', 'Live', 'Commentary', 'Scorecard', 'History', 'Points Table'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientPage(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Row(children: [
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)),
                  const Expanded(child: Column(children: [Text('CAMR vs VJS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), Text('25th Match', style: TextStyle(color: AppColor.muted))])),
                  const Icon(Icons.star_border), const SizedBox(width: 8), const Icon(Icons.more_vert),
                ]),
              ),
              SizedBox(
                height: 46,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemBuilder: (context, i) => GestureDetector(
                    onTap: () => setState(() => tab = i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tab == i ? AppColor.cyan : Colors.transparent, width: 2))),
                      child: Text(tabs[i], style: TextStyle(color: tab == i ? AppColor.text : AppColor.muted, fontWeight: FontWeight.w800)),
                    ),
                  ),
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemCount: tabs.length,
                ),
              ),
              Expanded(child: _body()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _body() {
    if (tab == 0) return const InfoTab();
    if (tab == 1) return const LiveTab();
    if (tab == 2) return const CommentaryTab();
    if (tab == 3) return const ScorecardTab();
    if (tab == 4) return const HistoryTab();
    return const PointsTableTab();
  }
}

class InfoTab extends StatelessWidget {
  const InfoTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(14), children: const [
      MatchMiniHeader(),
      SizedBox(height: 12),
      DetailRow(label: 'Match', value: '25th Match'),
      DetailRow(label: 'Series', value: 'Andhra Premier League 2026'),
      DetailRow(label: 'Venue', value: 'Amaravathi, India'),
      DetailRow(label: 'Toss', value: 'VJS won the toss and elected to bat'),
      DetailRow(label: 'Umpires', value: 'Nitin Menon, Richard Illingworth'),
      SizedBox(height: 12),
      GlassCard(child: Row(children: [Icon(Icons.sunny, color: Colors.orange), SizedBox(width: 10), Text('Weather 28°C • Clear'), Spacer(), Text('Pitch: Good for batting', style: TextStyle(color: AppColor.cyan))])),
    ]);
  }
}

class DetailRow extends StatelessWidget {
  final String label, value;
  const DetailRow({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassCard(padding: const EdgeInsets.all(12), child: Row(children: [SizedBox(width: 86, child: Text(label, style: const TextStyle(color: AppColor.muted))), Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w700)))])),
    );
  }
}

class MatchMiniHeader extends StatelessWidget {
  const MatchMiniHeader({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Row(children: const [CircleTeam(label: 'CAMR', color: Color(0xFFC51238)), SizedBox(width: 12), Expanded(child: Text('CAMR vs VJS\nVJS 46-1 (5.1)', style: TextStyle(fontWeight: FontWeight.w800))), Icon(Icons.flash_on, color: AppColor.cyan), Expanded(child: Text('Live\n25th Match', textAlign: TextAlign.right, style: TextStyle(color: AppColor.muted)))]));
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      children: const [
        TvLiveBox(),
        SizedBox(height: 10),
        BallStrip(),
        SizedBox(height: 10),
        QuickStatsRow(items: [('Run Rate', '8.9'), ('Balls Rem', '89')]),
        SizedBox(height: 10),
        WinProbability(),
        SizedBox(height: 10),
        BattingPanel(),
        SizedBox(height: 10),
        BowlingPanel(),
        SizedBox(height: 10),
        YetToBatPanel(),
        SizedBox(height: 10),
        ReviewPanel(),
        SizedBox(height: 10),
        GlassCard(child: Text('Settings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
      ],
    );
  }
}

class TvLiveBox extends StatelessWidget {
  const TvLiveBox({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 205,
      decoration: BoxDecoration(color: Colors.black, border: Border.all(color: AppColor.line, width: 5)),
      child: Column(children: [
        Expanded(child: Stack(children: const [
          Positioned(left: 14, top: 14, child: Icon(Icons.volume_off, color: Colors.white)),
          Positioned(right: 14, top: 14, child: Row(children: [CircleAvatar(radius: 4, backgroundColor: Colors.red), SizedBox(width: 4), Text('Live')])),
          Center(child: Text('1 Run', style: TextStyle(fontSize: 33, fontWeight: FontWeight.w900))),
        ])),
        Container(height: 50, color: AppColor.card2, padding: const EdgeInsets.symmetric(horizontal: 12), child: const Row(children: [Text('VJS 46-1 (5.1)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), SizedBox(width: 8), Pill('P', selected: true, color: Color(0xFF606C38)), Spacer(), Text('CAMR', style: TextStyle(color: AppColor.muted))])),
      ]),
    );
  }
}

class BallStrip extends StatelessWidget {
  const BallStrip({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
      child: Row(children: [
        const Ball('1', color: AppColor.green), const Ball('1', color: AppColor.green), const Ball('4', color: AppColor.blue), const Text(' = 9', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(width: 14), Container(height: 28, width: 1, color: AppColor.line), const SizedBox(width: 14), const Text('Over 6', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(width: 8), const Ball('1', color: AppColor.green), const Ball('', outlined: true), const Ball('', outlined: true), const Ball('', outlined: true), const Ball('', outlined: true), const Text(' = 1', style: TextStyle(fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class Ball extends StatelessWidget {
  final String text;
  final Color? color;
  final bool outlined;
  const Ball(this.text, {super.key, this.color, this.outlined = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 31,
      height: 31,
      margin: const EdgeInsets.only(right: 6),
      decoration: BoxDecoration(shape: BoxShape.circle, color: outlined ? Colors.transparent : (color ?? AppColor.card2), border: Border.all(color: outlined ? AppColor.muted : Colors.transparent, width: 0.8)),
      child: Center(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900))),
    );
  }
}

class QuickStatsRow extends StatelessWidget {
  final List<(String, String)> items;
  const QuickStatsRow({super.key, required this.items});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Row(children: [for (final item in items) Expanded(child: Text('${item.$1}: ${item.$2}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700), textAlign: item == items.last ? TextAlign.right : TextAlign.left))]));
  }
}

class WinProbability extends StatelessWidget {
  const WinProbability({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Row(children: const [Text('Win Probability  ⓘ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)), Spacer(), Text('VJS:'), SizedBox(width: 10), Pill('75', selected: true, color: AppColor.red), SizedBox(width: 6), Pill('76', selected: true, color: AppColor.green)]));
  }
}

class BattingPanel extends StatelessWidget {
  const BattingPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(children: const [
      TableHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']),
      ScoreRow(cols: ['Ashwin Hebbar 🏏', '16', '9', '1', '1', '177.78']),
      ScoreRow(cols: ['Harshavardhan Maddi...', '23', '15', '2', '1', '153.34']),
      Divider(color: AppColor.line),
      Row(children: [Text("P'ship: 39(22)", style: TextStyle(color: AppColor.muted)), Spacer(), Text("L' Wkt: M. Abhinav 5(7)", style: TextStyle(color: AppColor.muted))]),
    ]));
  }
}

class BowlingPanel extends StatelessWidget {
  const BowlingPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(children: const [
      TableHeader(cols: ['Bowler', 'O', 'R', 'Wkt', 'Eco']),
      ScoreRow(cols: ['M Toshith Yadav 🏏', '2.1', '20', '1', '9.24']),
    ]));
  }
}

class YetToBatPanel extends StatelessWidget {
  const YetToBatPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('Yet to bat', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)), Divider(color: AppColor.line),
      Text('S Zaheer Abbas, Harsha Vardhan Myla, Penmetsa Panduranga Raju, B Pranav Reddy, Db Prasanth Kumar, Ch Siddhardha, Lalith Mohan, Gollapudi Sai Venkata Sumith', style: TextStyle(height: 1.35, fontWeight: FontWeight.w700)),
    ]));
  }
}

class ReviewPanel extends StatelessWidget {
  const ReviewPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return GlassCard(child: Column(children: const [
      Row(children: [Text('Team Review - UDRS ⓘ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)), Spacer(), Text('Left'), SizedBox(width: 32), Icon(Icons.check, color: AppColor.green), SizedBox(width: 32), Icon(Icons.close, color: AppColor.red)]),
      Divider(color: AppColor.line),
      Row(children: [Expanded(child: Text('CAMR')), Text('2        0        0')]), SizedBox(height: 8), Row(children: [Expanded(child: Text('VJS')), Text('2        0        0')]),
    ]));
  }
}

class TableHeader extends StatelessWidget {
  final List<String> cols;
  const TableHeader({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [for (int i = 0; i < cols.length; i++) Expanded(flex: i == 0 ? 5 : 1, child: Text(cols[i], textAlign: i == 0 ? TextAlign.left : TextAlign.right, style: const TextStyle(color: AppColor.muted, fontWeight: FontWeight.w800)))]),
    );
  }
}

class ScoreRow extends StatelessWidget {
  final List<String> cols;
  const ScoreRow({super.key, required this.cols});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(children: [for (int i = 0; i < cols.length; i++) Expanded(flex: i == 0 ? 5 : 1, child: Text(cols[i], textAlign: i == 0 ? TextAlign.left : TextAlign.right, style: TextStyle(fontWeight: i == 0 ? FontWeight.w800 : FontWeight.w600)))]),
    );
  }
}

class CommentaryTab extends StatelessWidget {
  const CommentaryTab({super.key});
  @override
  Widget build(BuildContext context) {
    final data = ['5.1  FOUR! Beautifully timed by Harshavardhan Maddi.', '5.0  Full toss on middle, tucked away to mid-wicket.', '4.6  Pushed to long on for a single.', '4.5  Good length ball, defended solidly.', '4.4  Short and wide, cut away to point.', '4.3  FOUR! Crunched through point.'];
    return ListView(padding: const EdgeInsets.all(14), children: [
      const Row(children: [Pill('All', selected: true), SizedBox(width: 8), Pill('This Over'), SizedBox(width: 8), Pill('CAMR'), SizedBox(width: 8), Pill('VJS')]),
      const SizedBox(height: 12),
      for (final item in data) Padding(padding: const EdgeInsets.only(bottom: 8), child: GlassCard(padding: const EdgeInsets.all(12), child: Text(item, style: const TextStyle(fontWeight: FontWeight.w700)))),
    ]);
  }
}

class ScorecardTab extends StatelessWidget {
  const ScorecardTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(14), children: const [
      Row(children: [Expanded(child: Pill('CAMR')), SizedBox(width: 8), Expanded(child: Pill('VJS', selected: true))]),
      SizedBox(height: 12),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Text('VJS Innings', style: TextStyle(fontWeight: FontWeight.w900, color: AppColor.cyan)), Spacer(), Text('46-1 (5.1 Overs)', style: TextStyle(fontWeight: FontWeight.w900))]),
        Divider(color: AppColor.line), TableHeader(cols: ['Batter', 'R', 'B', '4s', '6s', 'SR']), ScoreRow(cols: ['Ashwin Hebbar 🏏', '16', '9', '1', '1', '177.78']), ScoreRow(cols: ['Harshavardhan Maddi...', '23', '15', '2', '1', '153.34']), ScoreRow(cols: ['M. Abhinav (wk)', '5', '7', '0', '0', '71.43']), Divider(color: AppColor.line), Text('Extras    2 (b 1, wd 1)'), SizedBox(height: 4), Text('Total     46-1 (5.1 Overs)', style: TextStyle(fontWeight: FontWeight.w900)),
      ])),
      SizedBox(height: 10),
      BowlingPanel(),
      SizedBox(height: 10),
      GlassCard(child: Text('Fall of Wickets\n1-7 (M. Abhinav, 1.2 Ov)', style: TextStyle(height: 1.5))),
    ]);
  }
}

class HistoryTab extends StatelessWidget {
  const HistoryTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(14), children: const [
      MatchMiniHeader(),
      SizedBox(height: 12),
      GlassCard(child: Column(children: [
        Text('Last 5 Matches', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), Divider(color: AppColor.line),
        DetailLine('26 Jun 2026', 'Orcas won by 88 runs', 'W'), DetailLine('15 Jun 2026', 'Orcas won by 32 runs', 'W'), DetailLine('05 Jun 2026', 'Freedom won by 6 wkts', 'L'), DetailLine('29 May 2026', 'Orcas won by 45 runs', 'W'), DetailLine('20 May 2026', 'Freedom won by 3 wkts', 'L'),
      ])),
      SizedBox(height: 12),
      GlassCard(child: Row(children: [Expanded(child: Text('Head to Head\nTotal Matches\n12')), Expanded(child: Text('Orcas Won\n8')), Expanded(child: Text('Freedom Won\n4'))])),
    ]);
  }
}

class DetailLine extends StatelessWidget {
  final String a, b, c;
  const DetailLine(this.a, this.b, this.c, {super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [SizedBox(width: 86, child: Text(a, style: const TextStyle(color: AppColor.muted))), Expanded(child: Text(b)), Pill(c, selected: true, color: c == 'W' ? AppColor.green : AppColor.red)]));
  }
}

class PointsTableTab extends StatelessWidget {
  const PointsTableTab({super.key});
  @override
  Widget build(BuildContext context) {
    final rows = [
      ['1', 'Seattle Orcas', '4', '3', '1', '+1.223', '6'], ['2', 'Texas Titans', '4', '3', '1', '+0.857', '6'], ['3', 'New York Strikers', '4', '2', '2', '+0.216', '4'], ['4', 'Freedom', '4', '2', '2', '-0.132', '4'], ['5', 'LA Knights', '4', '1', '3', '-0.645', '2']
    ];
    return ListView(padding: const EdgeInsets.all(14), children: [
      const Row(children: [Expanded(child: Pill('League Table', selected: true)), SizedBox(width: 8), Expanded(child: Pill('Team Form'))]),
      const SizedBox(height: 12),
      GlassCard(child: Column(children: [
        const TableHeader(cols: ['Team', 'P', 'W', 'L', 'NRR', 'Pts']),
        for (final r in rows) ScoreRow(cols: ['${r[0]}  ${r[1]}', r[2], r[3], r[4], r[5], r[6]]),
        const Divider(color: AppColor.line), const Text('Top 4 teams qualify for the Playoffs.', style: TextStyle(color: AppColor.cyan)),
      ])),
    ]);
  }
}
