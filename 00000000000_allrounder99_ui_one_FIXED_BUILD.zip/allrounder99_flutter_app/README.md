# Allrounder99 UI One Fixed
Premium dark blue cricket scoring app UI with manual scoring and match detail tabs.
