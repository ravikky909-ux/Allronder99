import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: AppColors.bg,
    systemNavigationBarColor: AppColors.bg,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const Allrounder99App());
}

class AppColors {
  static const bg = Color(0xFF05070B);
  static const card = Color(0xFF0B1520);
  static const card2 = Color(0xFF101C29);
  static const line = Color(0xFF213246);
  static const cyan = Color(0xFF00D9FF);
  static const blue = Color(0xFF0C78FF);
  static const green = Color(0xFF29C56D);
  static const orange = Color(0xFFCE862E);
  static const red = Color(0xFFE84E57);
  static const purple = Color(0xFF7C4DFF);
  static const muted = Color(0xFFA6B0BB);
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Allrounder99',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.cyan,
          brightness: Brightness.dark,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 4500), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute<void>(builder: (_) => const RootScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.15,
            colors: <Color>[Color(0xFF073846), AppColors.bg],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 210,
                height: 210,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: <BoxShadow>[
                    BoxShadow(color: AppColors.cyan.withOpacity(0.32), blurRadius: 70, spreadRadius: 8),
                  ],
                ),
                child: Image.asset('assets/logo.png', fit: BoxFit.contain),
              ),
              const SizedBox(height: 14),
              const Text(
                'ALLROUNDER99',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 1.2),
              ),
              const SizedBox(height: 8),
              const Text(
                'LIVE CRICKET  |  FAST SCORES  |  REAL TIME',
                style: TextStyle(color: AppColors.cyan, fontSize: 12, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 34),
              const SizedBox(
                width: 160,
                child: LinearProgressIndicator(
                  minHeight: 4,
                  color: AppColors.cyan,
                  backgroundColor: Color(0x2224D8FF),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int selectedIndex = 0;

  final List<Widget> pages = const <Widget>[
    HomeScreen(),
    ShortsScreen(),
    FixturesScreen(),
    SeriesScreen(),
    MoreScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xEE06101A),
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08))),
          boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.45), blurRadius: 18)],
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 76,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                navButton(0, Icons.home_rounded, 'Home'),
                navButton(1, Icons.play_circle_outline_rounded, 'Shorts'),
                navButton(2, Icons.calendar_month_rounded, 'Fixtures'),
                navButton(3, Icons.emoji_events_rounded, 'Series'),
                navButton(4, Icons.more_horiz_rounded, 'More'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget navButton(int index, IconData icon, String label) {
    final bool active = index == selectedIndex;
    return InkWell(
      onTap: () => setState(() => selectedIndex = index),
      borderRadius: BorderRadius.circular(16),
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: active ? AppColors.cyan : Colors.white70, size: 26),
            const SizedBox(height: 5),
            Text(
              label,
              style: TextStyle(
                color: active ? AppColors.cyan : Colors.white70,
                fontSize: 12,
                fontWeight: active ? FontWeight.w900 : FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  const AppHeader({super.key, this.title});
  final String? title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: <Widget>[
          if (title == null) ...<Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset('assets/logo.png', width: 48, height: 48, fit: BoxFit.cover),
            ),
            const SizedBox(width: 8),
            const Expanded(
              child: Text(
                'ALLROUNDER99',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic),
              ),
            ),
          ] else ...<Widget>[
            Expanded(
              child: Text(
                title!,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
            ),
          ],
          iconSquare(Icons.search_rounded),
          const SizedBox(width: 10),
          iconSquare(Icons.notifications_none_rounded),
        ],
      ),
    );
  }
}

Widget iconSquare(IconData icon) {
  return Container(
    width: 44,
    height: 44,
    decoration: BoxDecoration(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.white.withOpacity(0.12)),
    ),
    child: Icon(icon, color: Colors.white, size: 23),
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const AppHeader(),
            topTabs(<String>['Featured', 'Live', 'WT20 WC'], 0),
            Padding(
              padding: const EdgeInsets.all(16),
              child: HeroMatchCard(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => const MatchDetailScreen()),
                ),
              ),
            ),
            filterChips(<String>['All', 'T20', 'ODI', 'Test', 'Leagues']),
            sectionHeader('Trending Series', 'View all'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: seriesWideCard('Women’s T20 World Cup 2026', '12 Jun – 05 Jul  •  33 Matches', 'Top teams. Epic battles. One dream.'),
            ),
            sectionHeader('Popular Shorts', 'View all'),
            const ShortsRow(big: false),
            sectionHeader('Manual Scoring', 'Start'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: PremiumCard(
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    backgroundColor: Color(0x3322D9FF),
                    child: Icon(Icons.sports_cricket, color: AppColors.cyan),
                  ),
                  title: const Text('Create Local Match', style: TextStyle(fontWeight: FontWeight.w900)),
                  subtitle: const Text('Score 0, 1, 2, 3, 4, 6, W, WD, NB, B, LB', style: TextStyle(color: AppColors.muted)),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const ManualScoringScreen())),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HeroMatchCard extends StatelessWidget {
  const HeroMatchCard({super.key, this.onTap});
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: cardDecoration(glow: true, borderColor: AppColors.cyan.withOpacity(0.70)),
        child: Column(
          children: <Widget>[
            statusPill('FINISHED', AppColors.cyan),
            const SizedBox(height: 10),
            const Text('Major League Cricket 2026 • 9th Match', style: TextStyle(color: Colors.white70, fontSize: 14)),
            const SizedBox(height: 18),
            Row(
              children: <Widget>[
                Expanded(child: teamScoreCircle('ORC', 'Orcas', '227-6', '(20.0)', const Color(0xFFE34C50))),
                const Icon(Icons.flash_on_rounded, color: AppColors.cyan, size: 38),
                Expanded(child: teamScoreCircle('FRE', 'Freedom', '139-10', '(16.2)', const Color(0xFFECA2AA))),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0x9907131C),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.cyan.withOpacity(0.24)),
              ),
              child: const Text(
                'Seattle Orcas won by 88 runs',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget teamScoreCircle(String short, String name, String score, String overs, Color color) {
  return Column(
    children: <Widget>[
      CircleAvatar(radius: 34, backgroundColor: color, child: Text(short, style: const TextStyle(fontWeight: FontWeight.w900))),
      const SizedBox(height: 10),
      Text(score, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      Text(overs, style: const TextStyle(color: Colors.white70, fontSize: 15)),
      const SizedBox(height: 8),
      Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
    ],
  );
}

class FixturesScreen extends StatelessWidget {
  const FixturesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const AppHeader(title: 'Fixtures'),
            topTabs(<String>['Day wise', 'Series wise', 'Team wise'], 0),
            filterChips(<String>['All', 'T20', 'ODI', 'Test', 'Hundred']),
            const Padding(
              padding: EdgeInsets.fromLTRB(18, 16, 18, 8),
              child: Row(
                children: <Widget>[
                  Icon(Icons.calendar_today_rounded, color: Colors.white70, size: 18),
                  SizedBox(width: 10),
                  Text('Fri, 26 Jun 2026', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            MatchListCard(
              title: 'Major League Cricket 2026',
              match: '9th Match • 07:00 AM',
              left: 'Freedom',
              right: 'Orcas',
              leftScore: '139-10\n(16.2)',
              rightScore: '227-6\n(20.0)',
              status: 'Finished',
              statusColor: AppColors.green,
              result: 'Seattle Orcas won by 88 runs',
            ),
            MatchListCard(
              title: 'Andhra Premier League 2026',
              match: '25th Match • 02:00 PM',
              left: 'Capital Amaravati\nRoyals',
              right: 'Vijayawada\nSunshiners',
              status: 'Upcoming',
              statusColor: AppColors.orange,
              venue: 'Venue – Amaravathi, India',
            ),
            MatchListCard(
              title: 'Women T20 Blast 2026',
              match: '28th Match • 03:30 PM',
              left: 'Warwickshire\nWomen',
              right: 'Surrey Women',
              status: 'Upcoming',
              statusColor: AppColors.orange,
              venue: 'Venue – Birmingham, England',
            ),
          ],
        ),
      ),
    );
  }
}

class MatchListCard extends StatelessWidget {
  const MatchListCard({
    super.key,
    required this.title,
    required this.match,
    required this.left,
    required this.right,
    required this.status,
    required this.statusColor,
    this.leftScore,
    this.rightScore,
    this.result,
    this.venue,
  });

  final String title;
  final String match;
  final String left;
  final String right;
  final String status;
  final Color statusColor;
  final String? leftScore;
  final String? rightScore;
  final String? result;
  final String? venue;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const MatchDetailScreen())),
        borderRadius: BorderRadius.circular(18),
        child: PremiumCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                        Text(match, style: const TextStyle(color: AppColors.muted)),
                      ],
                    ),
                  ),
                  statusPill(status, statusColor),
                ],
              ),
              const Divider(color: Colors.white12, height: 24),
              Row(
                children: <Widget>[
                  teamSmall(left, 'A', leftScore, false),
                  const Expanded(child: Center(child: Icon(Icons.flash_on_rounded, color: AppColors.cyan, size: 28))),
                  teamSmall(right, 'B', rightScore, true),
                ],
              ),
              if (result != null)
                Padding(
                  padding: const EdgeInsets.only(top: 14),
                  child: Center(child: Text(result!, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900))),
                ),
              if (venue != null)
                Padding(
                  padding: const EdgeInsets.only(top: 14),
                  child: Row(
                    children: <Widget>[
                      const Icon(Icons.location_on_outlined, color: AppColors.muted, size: 18),
                      const SizedBox(width: 6),
                      Expanded(child: Text(venue!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget teamSmall(String name, String short, String? score, bool alignRight) {
  return SizedBox(
    width: 132,
    child: Column(
      crossAxisAlignment: alignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: <Widget>[
        CircleAvatar(
          radius: 28,
          backgroundColor: alignRight ? const Color(0xFF115A9D) : const Color(0xFF92384B),
          child: Text(short, style: const TextStyle(fontWeight: FontWeight.w900)),
        ),
        const SizedBox(height: 8),
        if (score != null)
          Text(score, textAlign: alignRight ? TextAlign.right : TextAlign.left, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(name, textAlign: alignRight ? TextAlign.right : TextAlign.left, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
      ],
    ),
  );
}

class SeriesScreen extends StatelessWidget {
  const SeriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<SeriesItem> items = <SeriesItem>[
      const SeriesItem('Vidarbha Premier League 2026', '01 Jun – 14 Jun', '25 Matches', 'Finished', 'VPL'),
      const SeriesItem('T20 Mumbai 2026', '01 Jun – 13 Jun', '23 Matches', 'Finished', 'T20'),
      const SeriesItem('Asian Legends League 2026', '02 Jun – 14 Jun', '19 Matches', 'Postponed', 'AS'),
      const SeriesItem('Ireland Inter-Provincial T20 Trophy 2026', '02 Jun – 17 Jun', '9 Matches', 'Finished', 'IR'),
      const SeriesItem('Madhya Pradesh T20 League 2026', '03 Jun – 26 Jun', '48 Matches', 'Ongoing', 'MP'),
      const SeriesItem('Sri Lanka tour of West Indies 2026', '04 Jun – 18 Jun', '5 Matches', 'Ongoing', 'SL'),
    ];

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const AppHeader(title: 'Series'),
            topTabs(<String>['Day wise', 'Series wise', 'Team wise'], 1),
            filterChips(<String>['All', 'International', 'T20 Leagues', 'Domestic']),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                readOnly: true,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search_rounded),
                  hintText: 'Search Series',
                  filled: true,
                  fillColor: AppColors.card,
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: AppColors.cyan.withOpacity(0.38)),
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(18, 22, 18, 8),
              child: Text('June 2026', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            ),
            for (final SeriesItem item in items) seriesCard(item),
          ],
        ),
      ),
    );
  }
}

class SeriesItem {
  const SeriesItem(this.name, this.dates, this.matches, this.status, this.badge);
  final String name;
  final String dates;
  final String matches;
  final String status;
  final String badge;
}

Widget seriesCard(SeriesItem item) {
  final Color color = item.status == 'Finished'
      ? AppColors.green
      : item.status == 'Postponed'
          ? Colors.grey
          : AppColors.red;
  return Padding(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
    child: PremiumCard(
      child: Row(
        children: <Widget>[
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: const LinearGradient(colors: <Color>[Color(0xFF102B4A), Color(0xFF06121D)]),
              border: Border.all(color: Colors.white12),
            ),
            child: Center(child: Text(item.badge, style: const TextStyle(fontSize: 20, color: AppColors.cyan, fontWeight: FontWeight.w900))),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(item.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text(item.dates, style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 4),
                Text(item.matches, style: const TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          statusPill(item.status, color),
        ],
      ),
    ),
  );
}

class ShortsScreen extends StatelessWidget {
  const ShortsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const AppHeader(title: 'Shorts'),
            filterChips(<String>['Trending', 'Popular', 'Recent']),
            sectionHeader('Popular Shorts', 'Upload'),
            const ShortsGrid(),
          ],
        ),
      ),
    );
  }
}

class ShortsGrid extends StatelessWidget {
  const ShortsGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> titles = <String>['RCB Last Over Thriller', 'Top 10 Catches', 'MS Dhoni Six', 'Best Yorkers', 'Match Preview', 'Top Wickets'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: titles.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.78,
        ),
        itemBuilder: (BuildContext context, int index) {
          return videoCard(titles[index], index, true);
        },
      ),
    );
  }
}

class ShortsRow extends StatelessWidget {
  const ShortsRow({super.key, required this.big});
  final bool big;

  @override
  Widget build(BuildContext context) {
    final List<String> titles = <String>['First hurdle on fire! 🔥', '12 record wickets 🚀', 'Sanju Samson 👑', 'Top shot replay'];
    return SizedBox(
      height: big ? 240 : 190,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: titles.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (BuildContext context, int index) => SizedBox(width: big ? 170 : 150, child: videoCard(titles[index], index, false)),
      ),
    );
  }
}

Widget videoCard(String title, int index, bool fullHeight) {
  final Color startColor = Color.lerp(AppColors.blue, AppColors.red, index / 6) ?? AppColors.blue;
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      gradient: LinearGradient(colors: <Color>[startColor, const Color(0xFF07111B)]),
      border: Border.all(color: Colors.white24),
    ),
    child: Stack(
      children: <Widget>[
        Positioned.fill(child: Icon(Icons.sports_cricket, size: 88, color: Colors.white.withOpacity(0.16))),
        const Positioned(left: 12, bottom: 44, child: CircleAvatar(backgroundColor: Colors.black54, child: Icon(Icons.play_arrow_rounded, color: Colors.white))),
        Positioned(
          left: 12,
          bottom: 12,
          right: 8,
          child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        ),
      ],
    ),
  );
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 20),
        child: Column(
          children: <Widget>[
            const AppHeader(title: 'More'),
            Padding(
              padding: const EdgeInsets.all(16),
              child: PremiumCard(
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.asset('assets/logo.png', width: 58, height: 58, fit: BoxFit.cover),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text('ALLROUNDER99', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                              Text('Version 1.0.0', style: TextStyle(color: AppColors.muted)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Divider(color: Colors.white12, height: 28),
                    menuRow(context, Icons.sports_cricket, 'Manual Scoring', const ManualScoringScreen()),
                    menuDivider(),
                    menuTextRow(Icons.favorite_border_rounded, 'My Matches'),
                    menuDivider(),
                    menuTextRow(Icons.emoji_events_outlined, 'My Series'),
                    menuDivider(),
                    menuTextRow(Icons.notifications_active_outlined, 'Live Score Alerts'),
                    menuDivider(),
                    menuTextRow(Icons.link_rounded, 'WhatsApp Link'),
                    menuDivider(),
                    menuTextRow(Icons.language_rounded, 'Website Link'),
                    menuDivider(),
                    menuTextRow(Icons.info_outline_rounded, 'About Allrounder99'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget menuDivider() => const Divider(color: Colors.white12, height: 1);

Widget menuRow(BuildContext context, IconData icon, String text, Widget page) {
  return ListTile(
    contentPadding: EdgeInsets.zero,
    leading: Icon(icon, color: Colors.white70),
    title: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
    trailing: const Icon(Icons.chevron_right_rounded),
    onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page)),
  );
}

Widget menuTextRow(IconData icon, String text) {
  return ListTile(
    contentPadding: EdgeInsets.zero,
    leading: Icon(icon, color: Colors.white70),
    title: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
    trailing: const Icon(Icons.chevron_right_rounded),
  );
}

class MatchDetailScreen extends StatelessWidget {
  const MatchDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 8, 4, 0),
                child: Row(
                  children: <Widget>[
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
                    const Expanded(
                      child: Column(
                        children: <Widget>[
                          Text('Freedom vs Orcas', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                          Text('9th Match', style: TextStyle(color: AppColors.muted)),
                        ],
                      ),
                    ),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert_rounded)),
                  ],
                ),
              ),
              const TabBar(
                isScrollable: true,
                indicatorColor: AppColors.cyan,
                labelColor: AppColors.cyan,
                unselectedLabelColor: Colors.white60,
                tabs: <Widget>[
                  Tab(text: 'Info'),
                  Tab(text: 'Live'),
                  Tab(text: 'Commentary'),
                  Tab(text: 'Scorecard'),
                  Tab(text: 'History'),
                  Tab(text: 'Points Table'),
                ],
              ),
              const Expanded(
                child: TabBarView(
                  children: <Widget>[
                    InfoTab(),
                    LiveTab(),
                    CommentaryTab(),
                    ScorecardTab(),
                    HistoryTab(),
                    PointsTableTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class InfoTab extends StatelessWidget {
  const InfoTab({super.key});

  @override
  Widget build(BuildContext context) {
    return detailList('Match Info', <InfoRow>[
      const InfoRow('Series', 'Major League Cricket 2026'),
      const InfoRow('Venue', 'Dallas, USA'),
      const InfoRow('Date', 'Fri, 26 Jun 2026'),
      const InfoRow('Toss', 'Orcas won toss and bat first'),
      const InfoRow('Match Type', 'T20'),
      const InfoRow('Umpires', 'Official Match Umpires'),
    ]);
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: <Widget>[
          const HeroMatchCard(),
          const SizedBox(height: 12),
          const BallStrip(label: 'Over 17', balls: <String>['0', '4', '6', 'W', '', '', ''], total: '6'),
          const SizedBox(height: 12),
          PremiumCard(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const <Widget>[
                StatBox('Runs Needed', '89'),
                StatBox('Balls Rem.', '22'),
                StatBox('CRR', '8.51'),
                StatBox('RRR', '24.27'),
                StatBox('Target', '228'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          scoreTable('BATTING • Freedom', <String>['Batter', 'R', 'B', '4s', '6s', 'SR'], <List<String>>[
            <String>['Amila Aponso', '31', '13', '2', '2', '238.47'],
            <String>['S. Netravalkar', '0', '0', '0', '0', '0.00'],
          ]),
          const SizedBox(height: 12),
          scoreTable('BOWLING • Orcas', <String>['Bowler', 'O', 'R', 'Wkt', 'Eco'], <List<String>>[
            <String>['Cameron Gannon', '2.2', '16', '2', '6.86'],
          ]),
        ],
      ),
    );
  }
}

class CommentaryTab extends StatelessWidget {
  const CommentaryTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        commentCard('16.2', 'W', 'K. Ramharack b Gannon. Orcas win by 88 runs.'),
        commentCard('16.1', '1', 'Single to deep cover.'),
        commentCard('15.6', '0', 'Dot ball. Excellent yorker.'),
        commentCard('15.5', 'W', 'S. Netravalkar b Gannon.'),
        commentCard('15.4', '1', 'Pushed to long on.'),
      ],
    );
  }
}

class ScorecardTab extends StatelessWidget {
  const ScorecardTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: <Widget>[
          scoreTable('Freedom Batting', <String>['Batter', 'R', 'B', '4s', '6s', 'SR'], <List<String>>[
            <String>['K. Nair', '7', '5', '1', '0', '140'],
            <String>['M. John', '12', '10', '2', '0', '120'],
            <String>['A. Aponso', '31', '13', '2', '2', '238.47'],
          ]),
          const SizedBox(height: 12),
          scoreTable('Orcas Bowling', <String>['Bowler', 'O', 'M', 'R', 'W'], <List<String>>[
            <String>['C. Gannon', '2.2', '0', '16', '2'],
            <String>['S. Netravalkar', '4', '0', '22', '1'],
          ]),
          const SizedBox(height: 12),
          detailList('Extras / Fall of Wickets', <InfoRow>[
            const InfoRow('Extras', '11 (4b, 6lb, 1nb, 0w)'),
            const InfoRow('FOW', '1-14, 2-20, 3-42, 4-78, 10-129'),
          ]),
        ],
      ),
    );
  }
}

class HistoryTab extends StatelessWidget {
  const HistoryTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        PremiumCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text('Over by Over – Freedom Innings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              overRow('1', <String>['0', '1', '0', '4', '0', '1'], '11 runs', '11/0'),
              overRow('2', <String>['0', '0', 'W', '1', '0', '2'], 'K. Nair c Miller b Gannon', '14/1'),
              overRow('3', <String>['4', '0', '1', 'W', '0', '0'], 'M. John b Gannon', '20/2'),
              overRow('4', <String>['1', '1', '0', '6', '0', '1'], '17 runs', '37/2'),
              overRow('17', <String>['0', '0', '0', '0', '1', 'W'], 'K. Ramharack b Gannon', '129/10'),
            ],
          ),
        ),
      ],
    );
  }
}

class PointsTableTab extends StatelessWidget {
  const PointsTableTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: scoreTable('Points Table', <String>['Team', 'M', 'W', 'L', 'Pts', 'NRR'], <List<String>>[
        <String>['Orcas', '9', '7', '2', '14', '+1.12'],
        <String>['Freedom', '9', '4', '5', '8', '-0.33'],
        <String>['Royals', '8', '3', '5', '6', '-0.42'],
      ]),
    );
  }
}

class InfoRow {
  const InfoRow(this.label, this.value);
  final String label;
  final String value;
}

Widget detailList(String title, List<InfoRow> rows) {
  return SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: PremiumCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppColors.cyan)),
          const SizedBox(height: 10),
          for (final InfoRow row in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: <Widget>[
                  Expanded(child: Text(row.label, style: const TextStyle(color: AppColors.muted))),
                  Expanded(flex: 2, child: Text(row.value, style: const TextStyle(fontWeight: FontWeight.w700))),
                ],
              ),
            ),
        ],
      ),
    ),
  );
}

class ManualScoringScreen extends StatefulWidget {
  const ManualScoringScreen({super.key});

  @override
  State<ManualScoringScreen> createState() => _ManualScoringScreenState();
}

class _ManualScoringScreenState extends State<ManualScoringScreen> {
  int runs = 0;
  int wickets = 0;
  int legalBalls = 0;
  final List<String> events = <String>[];

  void addBall(String event) {
    setState(() {
      events.insert(0, event);
      if (event == 'W') {
        wickets += 1;
        legalBalls += 1;
      } else if (event == 'WD' || event == 'NB') {
        runs += 1;
      } else if (event == 'B' || event == 'LB') {
        runs += 1;
        legalBalls += 1;
      } else {
        runs += int.tryParse(event) ?? 0;
        legalBalls += 1;
      }
    });
  }

  void undo() {
    if (events.isEmpty) {
      return;
    }
    setState(() {
      final String event = events.removeAt(0);
      if (event == 'W') {
        wickets -= 1;
        legalBalls -= 1;
      } else if (event == 'WD' || event == 'NB') {
        runs -= 1;
      } else if (event == 'B' || event == 'LB') {
        runs -= 1;
        legalBalls -= 1;
      } else {
        runs -= int.tryParse(event) ?? 0;
        legalBalls -= 1;
      }
    });
  }

  String oversText() {
    return '${legalBalls ~/ 6}.${legalBalls % 6}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Manual Scoring'), backgroundColor: AppColors.bg),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: <Widget>[
            PremiumCard(
              child: Column(
                children: <Widget>[
                  const Text('Allrounder99 Local Match', style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text('$runs-$wickets', style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w900)),
                  Text('${oversText()} Overs', style: const TextStyle(color: AppColors.muted)),
                  const SizedBox(height: 12),
                  BallStrip(label: 'Recent Balls', balls: events.take(8).toList().reversed.toList(), total: '${events.take(6).length}'),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: <Widget>[
                for (final String event in <String>['0', '1', '2', '3', '4', '6', 'W', 'WD', 'NB', 'B', 'LB']) scoringButton(event, () => addBall(event)),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                Expanded(child: ElevatedButton.icon(onPressed: undo, icon: const Icon(Icons.undo), label: const Text('Undo'))),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: 'Allrounder99 Score: $runs-$wickets (${oversText()})'));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Score copied')));
                    },
                    icon: const Icon(Icons.share),
                    label: const Text('Share'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            PremiumCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text('Ball History', style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text(events.isEmpty ? 'No balls yet' : events.join('  '), style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget scoringButton(String text, VoidCallback onTap) {
  return SizedBox(
    width: 84,
    height: 54,
    child: ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: text == 'W' ? AppColors.red : (text == '4' || text == '6') ? AppColors.blue : AppColors.card2,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: AppColors.cyan.withOpacity(0.25)),
        ),
      ),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900)),
    ),
  );
}

class PremiumCard extends StatelessWidget {
  const PremiumCard({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(),
      child: child,
    );
  }
}

BoxDecoration cardDecoration({Color? borderColor, bool glow = false}) {
  return BoxDecoration(
    color: AppColors.card.withOpacity(0.94),
    borderRadius: BorderRadius.circular(20),
    border: Border.all(color: borderColor ?? Colors.white.withOpacity(0.12)),
    gradient: const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: <Color>[Color(0xFF111D28), Color(0xFF07111A)],
    ),
    boxShadow: glow ? <BoxShadow>[BoxShadow(color: AppColors.cyan.withOpacity(0.18), blurRadius: 24)] : null,
  );
}

Widget topTabs(List<String> items, int activeIndex) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    child: Row(
      children: <Widget>[
        for (int i = 0; i < items.length; i += 1)
          Expanded(
            child: Container(
              padding: const EdgeInsets.only(top: 10, bottom: 12),
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: i == activeIndex ? AppColors.cyan : Colors.white12, width: i == activeIndex ? 3 : 1)),
              ),
              child: Center(
                child: Text(
                  items[i],
                  style: TextStyle(color: i == activeIndex ? AppColors.cyan : Colors.white54, fontWeight: FontWeight.w900, fontSize: 16),
                ),
              ),
            ),
          ),
      ],
    ),
  );
}

Widget filterChips(List<String> items) {
  return SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
    child: Row(
      children: <Widget>[
        for (int i = 0; i < items.length; i += 1)
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
              decoration: BoxDecoration(
                color: i == 0 ? const Color(0x5520D7FF) : AppColors.card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: i == 0 ? AppColors.cyan : Colors.white24),
              ),
              child: Text(
                items[i],
                style: TextStyle(fontWeight: FontWeight.w800, color: i == 0 ? Colors.white : Colors.white70),
              ),
            ),
          ),
      ],
    ),
  );
}

Widget sectionHeader(String left, String right) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(18, 22, 18, 10),
    child: Row(
      children: <Widget>[
        Expanded(child: Text(left, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
        Text(right, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900)),
        const Icon(Icons.chevron_right_rounded, color: AppColors.cyan),
      ],
    ),
  );
}

Widget statusPill(String text, Color color) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(
      color: color.withOpacity(0.18),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: color),
    ),
    child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
  );
}

Widget seriesWideCard(String title, String subtitle, String desc) {
  return PremiumCard(
    child: Row(
      children: <Widget>[
        Container(
          width: 88,
          height: 88,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(colors: <Color>[AppColors.cyan, Color(0xFFFF4BCD)]),
          ),
          child: const Center(child: Text('T20', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 8),
              Text(subtitle, style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 8),
              Text(desc, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w800)),
            ],
          ),
        ),
        const Icon(Icons.chevron_right_rounded),
      ],
    ),
  );
}

class BallStrip extends StatelessWidget {
  const BallStrip({super.key, required this.label, required this.balls, required this.total});
  final String label;
  final List<String> balls;
  final String total;

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      child: Row(
        children: <Widget>[
          Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(width: 8),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: <Widget>[for (final String ball in balls) ballCircle(ball)]),
            ),
          ),
          Text('= $total', style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

Widget ballCircle(String text) {
  Color color = Colors.white24;
  if (text == 'W') {
    color = AppColors.red;
  } else if (text == '6') {
    color = AppColors.purple;
  } else if (text == '4' || text == '1' || text == '2' || text == '3') {
    color = AppColors.blue;
  } else if (text == 'WD' || text == 'NB') {
    color = AppColors.orange;
  }

  return Container(
    width: 32,
    height: 32,
    margin: const EdgeInsets.only(left: 6),
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: text.isEmpty ? Colors.transparent : color,
      border: Border.all(color: Colors.white24),
    ),
    child: Center(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12))),
  );
}

class StatBox extends StatelessWidget {
  const StatBox(this.label, this.value, {super.key});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
        const SizedBox(height: 6),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
      ],
    );
  }
}

Widget scoreTable(String title, List<String> headers, List<List<String>> rows) {
  return PremiumCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(title, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900, fontSize: 16)),
        const Divider(color: Colors.white12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            headingTextStyle: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w900),
            dataTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
            columns: <DataColumn>[for (final String h in headers) DataColumn(label: Text(h))],
            rows: <DataRow>[
              for (final List<String> row in rows)
                DataRow(cells: <DataCell>[for (final String value in row) DataCell(Text(value))]),
            ],
          ),
        ),
      ],
    ),
  );
}

Widget commentCard(String over, String tag, String text) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: PremiumCard(
      child: Row(
        children: <Widget>[
          ballCircle(tag),
          const SizedBox(width: 12),
          Text(over, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900)),
          const SizedBox(width: 12),
          Expanded(child: Text(text)),
        ],
      ),
    ),
  );
}

Widget overRow(String over, List<String> balls, String note, String score) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(
      children: <Widget>[
        SizedBox(width: 24, child: Text(over, style: const TextStyle(fontWeight: FontWeight.w900))),
        for (final String ball in balls) ballCircle(ball),
        const SizedBox(width: 8),
        Expanded(child: Text(note, style: const TextStyle(color: Colors.white70))),
        Text(score, style: const TextStyle(fontWeight: FontWeight.w900)),
      ],
    ),
  );
}
