import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const Allrounder99App());

class AppColors {
  static const bg = Color(0xFF05070B);
  static const card = Color(0xFF0B1520);
  static const card2 = Color(0xFF101D2A);
  static const cyan = Color(0xFF00D9FF);
  static const green = Color(0xFF32C66B);
  static const orange = Color(0xFFCE862E);
  static const red = Color(0xFFE84E57);
  static const muted = Color(0xFFA7B0BA);
}

class Allrounder99App extends StatelessWidget {
  const Allrounder99App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Allrounder99',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.cyan, brightness: Brightness.dark),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 4500), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const RootScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(center: Alignment.center, radius: 1.2, colors: [Color(0xFF073645), AppColors.bg]),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.cyan, width: 3),
                  boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.35), blurRadius: 60)],
                ),
                alignment: Alignment.center,
                child: const Text('A99', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: Colors.white, fontStyle: FontStyle.italic)),
              ),
              const SizedBox(height: 20),
              const Text('ALLROUNDER99', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.2)),
              const SizedBox(height: 8),
              const Text('Cricket Scoring App', style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const HomeScreen(),
      const FixturesScreen(),
      const SeriesScreen(),
      const ScoringScreen(),
      const MoreScreen(),
    ];
    return Scaffold(
      body: Stack(
        children: [
          pages[index],
          Align(alignment: Alignment.bottomCenter, child: AppBottomNav(current: index, onChanged: (value) => setState(() => index = value))),
        ],
      ),
    );
  }
}

class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF06151E), AppColors.bg]),
      ),
      child: SafeArea(child: child),
    );
  }
}

class Header extends StatelessWidget {
  const Header({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.cyan, width: 2)),
            alignment: Alignment.center,
            child: const Text('A99', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Colors.white)),
          ),
          const SizedBox(width: 10),
          const Text('ALLROUNDER99', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Colors.white, fontStyle: FontStyle.italic)),
          const Spacer(),
          _iconButton(Icons.search),
          const SizedBox(width: 8),
          _iconButton(Icons.settings_outlined),
        ],
      ),
    );
  }

  Widget _iconButton(IconData icon) {
    return Container(
      width: 44,
      height: 44,
      decoration: boxDecoration(radius: 14),
      child: Icon(icon, color: Colors.white),
    );
  }
}

BoxDecoration boxDecoration({double radius = 18, bool active = false}) {
  return BoxDecoration(
    color: active ? const Color(0xFF07313D) : AppColors.card,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: active ? AppColors.cyan : const Color(0xFF203545)),
    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 8))],
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 118),
        children: [
          const Header(),
          const TabRow(labels: ['Featured', 'Live', 'WT20 WC'], active: 0),
          Padding(
            padding: const EdgeInsets.all(16),
            child: MatchCard(
              title: 'Major League Cricket 2026 • 9th Match',
              status: 'FINISHED',
              teamA: 'Orcas',
              scoreA: '227-6',
              overA: '20.0',
              teamB: 'Freedom',
              scoreB: '139-10',
              overB: '16.2',
              result: 'Seattle Orcas won by 88 runs',
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 10, runSpacing: 10, children: [ChipItem('All', true), ChipItem('T20', false), ChipItem('ODI', false), ChipItem('Test', false), ChipItem('Leagues', false)]),
          ),
          const SizedBox(height: 18),
          const SectionTitle('Trending Series'),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: SeriesCard(title: 'Women T20 World Cup 2026', subtitle: '12 Jun - 05 Jul 2026 • 33 Matches', status: 'Ongoing')),
          const SizedBox(height: 18),
          const SectionTitle('Popular Shorts'),
          SizedBox(
            height: 140,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: const [ShortCard('First hurdle on fire'), ShortCard('12 record wickets'), ShortCard('Top cricket moments')],
            ),
          ),
        ],
      ),
    );
  }
}

class FixturesScreen extends StatelessWidget {
  const FixturesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 118),
        children: const [
          Header(),
          TabRow(labels: ['Day wise', 'Series wise', 'Team wise'], active: 0),
          Padding(padding: EdgeInsets.fromLTRB(16, 12, 16, 8), child: Wrap(spacing: 10, children: [ChipItem('All', true), ChipItem('T20', false), ChipItem('ODI', false), ChipItem('Test', false)])),
          Padding(padding: EdgeInsets.fromLTRB(16, 18, 16, 10), child: Text('Fri, 26 Jun 2026', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
          Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 12), child: FixtureCard(title: 'Major League Cricket 2026', sub: '9th Match • 07:00 AM', status: 'Finished', teams: 'Freedom 139-10  ⚡  Orcas 227-6', note: 'Seattle Orcas won by 88 runs')),
          Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 12), child: FixtureCard(title: 'Andhra Premier League 2026', sub: '25th Match • 02:00 PM', status: 'Upcoming', teams: 'Capital Amaravati Royals  ⚡  Vijayawada Sunshiners', note: 'Venue - Amaravathi, India')),
          Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 12), child: FixtureCard(title: 'Women T20 Blast 2026', sub: '28th Match • 03:30 PM', status: 'Upcoming', teams: 'Warwickshire Women  ⚡  Surrey Women', note: 'Venue - Birmingham, England')),
        ],
      ),
    );
  }
}

class SeriesScreen extends StatelessWidget {
  const SeriesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 118),
        children: const [
          Header(),
          TabRow(labels: ['Day wise', 'Series wise', 'Team wise'], active: 1),
          Padding(padding: EdgeInsets.fromLTRB(16, 12, 16, 8), child: Wrap(spacing: 10, runSpacing: 10, children: [ChipItem('All', true), ChipItem('International', false), ChipItem('T20 Leagues', false), ChipItem('Domestic', false)])),
          Padding(padding: EdgeInsets.all(16), child: SearchBox()),
          Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('June 2026', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
          SizedBox(height: 12),
          Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 12), child: SeriesCard(title: 'Vidarbha Premier League 2026', subtitle: '01 Jun - 14 Jun • 25 Matches', status: 'Finished')),
          Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 12), child: SeriesCard(title: 'T20 Mumbai 2026', subtitle: '01 Jun - 13 Jun • 23 Matches', status: 'Finished')),
          Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 12), child: SeriesCard(title: 'Madhya Pradesh T20 League 2026', subtitle: '03 Jun - 26 Jun • 48 Matches', status: 'Ongoing')),
        ],
      ),
    );
  }
}

class ScoringScreen extends StatefulWidget {
  const ScoringScreen({super.key});
  @override
  State<ScoringScreen> createState() => _ScoringScreenState();
}

class _ScoringScreenState extends State<ScoringScreen> {
  int runs = 0;
  int wickets = 0;
  int balls = 0;
  final List<String> timeline = <String>[];
  final List<List<Object>> history = <List<Object>>[];

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 118),
        children: [
          const Header(),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: boxDecoration(active: true),
            child: Column(
              children: [
                const Text('MANUAL SCORING', style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                Text('$runs-$wickets', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900)),
                Text('${balls ~/ 6}.${balls % 6} Overs', style: const TextStyle(fontSize: 20, color: AppColors.muted, fontWeight: FontWeight.w800)),
                const SizedBox(height: 14),
                Wrap(spacing: 8, runSpacing: 8, children: timeline.isEmpty ? const [Text('No ball scored yet', style: TextStyle(color: AppColors.muted))] : timeline.map((item) => BallItem(item)).toList()),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text('Scoring Panel', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 2.2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            children: ['0', '1', '2', '3', '4', '6', 'W', 'Wide', 'No Ball', 'Bye', 'Leg Bye', 'Undo'].map(scoreButton).toList(),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(onPressed: copyScore, icon: const Icon(Icons.share), label: const Text('Copy / Share Score')),
        ],
      ),
    );
  }

  Widget scoreButton(String label) {
    final bool danger = label == 'W';
    return InkWell(
      onTap: () => onScore(label),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: danger ? AppColors.red.withOpacity(0.16) : AppColors.cyan.withOpacity(0.12),
          border: Border.all(color: danger ? AppColors.red : AppColors.cyan),
        ),
        alignment: Alignment.center,
        child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: danger ? AppColors.red : Colors.white)),
      ),
    );
  }

  void save() {
    history.add(<Object>[runs, wickets, balls, List<String>.from(timeline)]);
  }

  void onScore(String label) {
    if (label == 'Undo') {
      if (history.isNotEmpty) {
        final last = history.removeLast();
        setState(() {
          runs = last[0] as int;
          wickets = last[1] as int;
          balls = last[2] as int;
          timeline.clear();
          timeline.addAll(last[3] as List<String>);
        });
      }
      return;
    }

    save();
    setState(() {
      if (label == 'W') {
        wickets += 1;
        balls += 1;
        timeline.add('W');
      } else if (label == 'Wide') {
        runs += 1;
        timeline.add('Wd');
      } else if (label == 'No Ball') {
        runs += 1;
        timeline.add('Nb');
      } else if (label == 'Bye') {
        runs += 1;
        balls += 1;
        timeline.add('B');
      } else if (label == 'Leg Bye') {
        runs += 1;
        balls += 1;
        timeline.add('LB');
      } else {
        runs += int.parse(label);
        balls += 1;
        timeline.add(label);
      }
    });
  }

  Future<void> copyScore() async {
    final text = 'Allrounder99 Live Score\nTeam A $runs-$wickets (${balls ~/ 6}.${balls % 6})\nPowered by Allrounder99';
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Score copied. Paste on WhatsApp.')));
    }
  }
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 118),
        children: const [
          Header(),
          InfoCard(title: 'WhatsApp Link', text: 'https://go.wa.link/allrounder99'),
          InfoCard(title: 'Website Link', text: 'https://Gamerush99.com'),
          InfoCard(title: 'About App', text: 'Allrounder99 cricket scoring app with fixtures, series, live score and manual scoring.'),
        ],
      ),
    );
  }
}

class TabRow extends StatelessWidget {
  final List<String> labels;
  final int active;
  const TabRow({super.key, required this.labels, required this.active});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: List.generate(labels.length, (index) {
          final bool selected = index == active;
          return Expanded(
            child: Column(
              children: [
                Text(labels[index], style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: selected ? AppColors.cyan : Colors.white60)),
                const SizedBox(height: 10),
                Container(height: 3, width: selected ? 92 : 0, decoration: BoxDecoration(color: AppColors.cyan, borderRadius: BorderRadius.circular(4))),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class ChipItem extends StatelessWidget {
  final String label;
  final bool active;
  const ChipItem(this.label, this.active, {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
      decoration: boxDecoration(radius: 14, active: active),
      child: Text(label, style: TextStyle(fontWeight: FontWeight.w900, color: active ? Colors.white : Colors.white70)),
    );
  }
}

class MatchCard extends StatelessWidget {
  final String title;
  final String status;
  final String teamA;
  final String scoreA;
  final String overA;
  final String teamB;
  final String scoreB;
  final String overB;
  final String result;
  const MatchCard({super.key, required this.title, required this.status, required this.teamA, required this.scoreA, required this.overA, required this.teamB, required this.scoreB, required this.overB, required this.result});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: boxDecoration(active: true),
      child: Column(
        children: [
          StatusBadge(status),
          const SizedBox(height: 10),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w700)),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: _team(teamA, scoreA, overA, AppColors.red, CrossAxisAlignment.start)),
              const Icon(Icons.bolt, color: AppColors.cyan, size: 42),
              Expanded(child: _team(teamB, scoreB, overB, AppColors.cyan, CrossAxisAlignment.end)),
            ],
          ),
          const SizedBox(height: 16),
          Text(result, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }

  Widget _team(String name, String score, String over, Color color, CrossAxisAlignment align) {
    return Column(
      crossAxisAlignment: align,
      children: [
        CircleAvatar(radius: 28, backgroundColor: color, child: Text(name.substring(0, 1), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
        const SizedBox(height: 8),
        Text(score, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        Text('($over)', style: const TextStyle(color: AppColors.muted)),
        Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class FixtureCard extends StatelessWidget {
  final String title;
  final String sub;
  final String status;
  final String teams;
  final String note;
  const FixtureCard({super.key, required this.title, required this.sub, required this.status, required this.teams, required this.note});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: boxDecoration(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))), StatusBadge(status)]),
        const SizedBox(height: 4),
        Text(sub, style: const TextStyle(color: AppColors.muted)),
        const SizedBox(height: 16),
        Text(teams, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        const Divider(color: Color(0xFF203545)),
        Text(note, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w800)),
      ]),
    );
  }
}

class SeriesCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String status;
  const SeriesCard({super.key, required this.title, required this.subtitle, required this.status});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: boxDecoration(),
      child: Row(children: [
        Container(width: 62, height: 62, decoration: BoxDecoration(color: AppColors.cyan.withOpacity(0.16), borderRadius: BorderRadius.circular(14)), alignment: Alignment.center, child: const Icon(Icons.emoji_events, color: AppColors.cyan, size: 32)),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(color: AppColors.muted))])),
        StatusBadge(status),
      ]),
    );
  }
}

class StatusBadge extends StatelessWidget {
  final String text;
  const StatusBadge(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    Color color = AppColors.cyan;
    final lower = text.toLowerCase();
    if (lower.contains('finish')) color = AppColors.green;
    if (lower.contains('upcoming')) color = AppColors.orange;
    if (lower.contains('live')) color = AppColors.red;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
      decoration: BoxDecoration(color: color.withOpacity(0.14), border: Border.all(color: color), borderRadius: BorderRadius.circular(10)),
      child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
    );
  }
}

class SearchBox extends StatelessWidget {
  const SearchBox({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: boxDecoration(radius: 14),
      child: const Row(children: [Icon(Icons.search, color: Colors.white54), SizedBox(width: 10), Text('Search Series', style: TextStyle(color: AppColors.muted, fontSize: 16))]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: Row(children: [Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const Spacer(), const Text('View all', style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w800))]),
    );
  }
}

class ShortCard extends StatelessWidget {
  final String title;
  const ShortCard(this.title, {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      margin: const EdgeInsets.only(right: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Container(decoration: BoxDecoration(color: AppColors.card2, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white24)), child: const Center(child: Icon(Icons.play_arrow, size: 44)))),
        const SizedBox(height: 7),
        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
      ]),
    );
  }
}

class BallItem extends StatelessWidget {
  final String text;
  const BallItem(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    Color color = Colors.white70;
    if (text == '4') color = AppColors.cyan;
    if (text == '6') color = Colors.deepPurpleAccent;
    if (text == 'W') color = AppColors.red;
    if (text == 'Wd' || text == 'Nb') color = AppColors.orange;
    return Container(
      width: 36,
      height: 36,
      alignment: Alignment.center,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      child: Text(text, style: TextStyle(color: color == Colors.white70 ? Colors.black : Colors.white, fontWeight: FontWeight.w900, fontSize: 12)),
    );
  }
}

class InfoCard extends StatelessWidget {
  final String title;
  final String text;
  const InfoCard({super.key, required this.title, required this.text});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: boxDecoration(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 8), SelectableText(text, style: const TextStyle(color: AppColors.muted))]),
    );
  }
}

class AppBottomNav extends StatelessWidget {
  final int current;
  final ValueChanged<int> onChanged;
  const AppBottomNav({super.key, required this.current, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final items = <_NavItem>[
      _NavItem(Icons.home, 'Home'),
      _NavItem(Icons.calendar_today, 'Fixtures'),
      _NavItem(Icons.emoji_events, 'Series'),
      _NavItem(Icons.sports_cricket, 'Score'),
      _NavItem(Icons.more_horiz, 'More'),
    ];
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: const Color(0xFF07131D), borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFF203545))),
        child: Row(
          children: List.generate(items.length, (index) {
            final item = items[index];
            final bool selected = current == index;
            return Expanded(
              child: InkWell(
                onTap: () => onChanged(index),
                child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(item.icon, color: selected ? AppColors.cyan : Colors.white70), const SizedBox(height: 4), Text(item.label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: selected ? AppColors.cyan : Colors.white70))]),
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  _NavItem(this.icon, this.label);
}
