Allrounder99 Play Store AAB Build Pack

1) Upload 0.zip in your GitHub repo root.
2) Put build-aab.yml in .github/workflows/build-aab.yml.
3) GitHub Actions -> Build Allrounder99 PlayStore AAB -> Run workflow.
4) Download artifact: Allrounder99-PlayStore-AAB.
5) Upload app-release.aab to Play Console.

First release version:
- build-name: 1.0.0
- build-number: 1

Future API update:
- change build-number to 2 or higher before uploading update.
